
# TaskSpecPlacementSpread

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**spreadDescriptor** | **String** | label descriptor, such as engine.labels.az |  [optional]



