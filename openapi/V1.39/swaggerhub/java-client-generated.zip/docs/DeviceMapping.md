
# DeviceMapping

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pathOnHost** | **String** |  |  [optional]
**pathInContainer** | **String** |  |  [optional]
**cgroupPermissions** | **String** |  |  [optional]



