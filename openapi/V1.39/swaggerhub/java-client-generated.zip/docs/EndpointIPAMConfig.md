
# EndpointIPAMConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ipv4Address** | **String** |  |  [optional]
**ipv6Address** | **String** |  |  [optional]
**linkLocalIPs** | **List&lt;String&gt;** |  |  [optional]



