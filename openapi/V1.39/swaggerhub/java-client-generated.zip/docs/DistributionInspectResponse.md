
# DistributionInspectResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**descriptor** | [**DistributionInspectResponseDescriptor**](DistributionInspectResponseDescriptor.md) |  | 
**platforms** | [**List&lt;DistributionInspectResponsePlatforms&gt;**](DistributionInspectResponsePlatforms.md) | An array containing all platforms supported by the image | 



