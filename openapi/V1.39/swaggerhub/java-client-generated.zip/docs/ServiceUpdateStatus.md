
# ServiceUpdateStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**state** | [**StateEnum**](#StateEnum) |  |  [optional]
**startedAt** | **String** |  |  [optional]
**completedAt** | **String** |  |  [optional]
**message** | **String** |  |  [optional]


<a name="StateEnum"></a>
## Enum: StateEnum
Name | Value
---- | -----
UPDATING | &quot;updating&quot;
PAUSED | &quot;paused&quot;
COMPLETED | &quot;completed&quot;



