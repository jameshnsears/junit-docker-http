
# Driver

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Name of the driver. | 
**options** | **Map&lt;String, String&gt;** | Key/value map of driver-specific options. |  [optional]



