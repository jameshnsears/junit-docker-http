
# ImageMetadata

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lastTagTime** | **String** |  |  [optional]



