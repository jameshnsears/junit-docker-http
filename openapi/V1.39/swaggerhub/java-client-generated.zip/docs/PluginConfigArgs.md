
# PluginConfigArgs

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**description** | **String** |  | 
**settable** | **List&lt;String&gt;** |  | 
**value** | **List&lt;String&gt;** |  | 



