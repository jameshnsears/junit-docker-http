
# SwarmSpecEncryptionConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**autoLockManagers** | **Boolean** | If set, generate a key and use it to lock data stored on the managers. |  [optional]



