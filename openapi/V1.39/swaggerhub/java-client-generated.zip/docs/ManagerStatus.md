
# ManagerStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**leader** | **Boolean** |  |  [optional]
**reachability** | [**Reachability**](Reachability.md) |  |  [optional]
**addr** | **String** | The IP address and port at which the manager is reachable.  |  [optional]



