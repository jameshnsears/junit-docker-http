
# ContainerChangeResponseItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**path** | **String** | Path to file that has changed | 
**kind** | **Integer** | Kind of change | 



