
# PluginConfigLinux

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**capabilities** | **List&lt;String&gt;** |  | 
**allowAllDevices** | **Boolean** |  | 
**devices** | [**List&lt;PluginDevice&gt;**](PluginDevice.md) |  | 



