
# TaskSpecResources

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**limits** | [**ResourceObject**](ResourceObject.md) | Define resources limits. |  [optional]
**reservation** | [**ResourceObject**](ResourceObject.md) | Define resources reservation. |  [optional]



