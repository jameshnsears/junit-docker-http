
# DistributionInspectResponseDescriptor

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mediaType** | **String** |  |  [optional]
**size** | **Long** |  |  [optional]
**digest** | **String** |  |  [optional]
**urLs** | **List&lt;String&gt;** |  |  [optional]



