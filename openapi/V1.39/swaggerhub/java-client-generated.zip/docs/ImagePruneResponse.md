
# ImagePruneResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**imagesDeleted** | [**List&lt;ImageDeleteResponseItem&gt;**](ImageDeleteResponseItem.md) | Images that were deleted |  [optional]
**spaceReclaimed** | **Long** | Disk space reclaimed in bytes |  [optional]



