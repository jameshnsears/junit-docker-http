
# SystemDataUsageResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**layersSize** | **Long** |  |  [optional]
**images** | [**List&lt;ImageSummary&gt;**](ImageSummary.md) |  |  [optional]
**containers** | [**List&lt;ContainerSummary&gt;**](ContainerSummary.md) |  |  [optional]
**volumes** | [**List&lt;Volume&gt;**](Volume.md) |  |  [optional]
**buildCache** | [**List&lt;BuildCache&gt;**](BuildCache.md) |  |  [optional]



