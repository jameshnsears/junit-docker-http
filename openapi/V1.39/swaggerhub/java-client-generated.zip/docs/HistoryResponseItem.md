
# HistoryResponseItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | 
**created** | **Long** |  | 
**createdBy** | **String** |  | 
**tags** | **List&lt;String&gt;** |  | 
**size** | **Long** |  | 
**comment** | **String** |  | 



