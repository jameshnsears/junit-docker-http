
# BuildCache

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ID** | **String** |  |  [optional]
**parent** | **String** |  |  [optional]
**type** | **String** |  |  [optional]
**description** | **String** |  |  [optional]
**inUse** | **Boolean** |  |  [optional]
**shared** | **Boolean** |  |  [optional]
**size** | **Integer** |  |  [optional]
**createdAt** | **Integer** |  |  [optional]
**lastUsedAt** | **Integer** |  |  [optional]
**usageCount** | **Integer** |  |  [optional]



