
# MountVolumeOptionsDriverConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Name of the driver to use to create the volume. |  [optional]
**options** | **Map&lt;String, String&gt;** | key/value map of driver specific options. |  [optional]



