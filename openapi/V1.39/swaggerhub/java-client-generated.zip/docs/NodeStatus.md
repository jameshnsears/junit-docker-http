
# NodeStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**state** | [**NodeState**](NodeState.md) |  |  [optional]
**message** | **String** |  |  [optional]
**addr** | **String** | IP address of the node. |  [optional]



