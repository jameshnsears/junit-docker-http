
# ServiceUpdateResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**warnings** | **List&lt;String&gt;** | Optional warning messages |  [optional]



