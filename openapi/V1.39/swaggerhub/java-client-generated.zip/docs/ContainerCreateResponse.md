
# ContainerCreateResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | The ID of the created container | 
**warnings** | **List&lt;String&gt;** | Warnings encountered when creating the container | 



