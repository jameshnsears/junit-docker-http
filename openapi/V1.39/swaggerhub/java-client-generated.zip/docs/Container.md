
# Container

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**container** | **String** | The ID or name of the container to connect to the network. |  [optional]
**endpointConfig** | [**EndpointSettings**](EndpointSettings.md) |  |  [optional]



