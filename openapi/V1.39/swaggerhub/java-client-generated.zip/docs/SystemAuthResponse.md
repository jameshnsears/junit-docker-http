
# SystemAuthResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **String** | The status of the authentication | 
**identityToken** | **String** | An opaque token used to authenticate a user after a successful login |  [optional]



