
# AuthConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **String** |  |  [optional]
**password** | **String** |  |  [optional]
**email** | **String** |  |  [optional]
**serveraddress** | **String** |  |  [optional]



