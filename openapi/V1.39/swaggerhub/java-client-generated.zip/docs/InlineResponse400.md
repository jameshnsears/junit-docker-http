
# InlineResponse400

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**errorResponse** | [**ErrorResponse**](ErrorResponse.md) |  |  [optional]
**message** | **String** | The error message. Either \&quot;must specify path parameter\&quot; (path cannot be empty) or \&quot;not a directory\&quot; (path was asserted to be a directory but exists as a file). |  [optional]



