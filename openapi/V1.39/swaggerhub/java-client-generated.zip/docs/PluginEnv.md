
# PluginEnv

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**description** | **String** |  | 
**settable** | **List&lt;String&gt;** |  | 
**value** | **String** |  | 



