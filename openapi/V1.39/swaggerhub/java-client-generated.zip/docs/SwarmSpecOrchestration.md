
# SwarmSpecOrchestration

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**taskHistoryRetentionLimit** | **Long** | The number of historic tasks to keep per instance or node. If negative, never remove completed or failed tasks. |  [optional]



