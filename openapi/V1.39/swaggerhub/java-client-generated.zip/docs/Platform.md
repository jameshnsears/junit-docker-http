
# Platform

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**architecture** | **String** | Architecture represents the hardware architecture (for example, &#x60;x86_64&#x60;).  |  [optional]
**OS** | **String** | OS represents the Operating System (for example, &#x60;linux&#x60; or &#x60;windows&#x60;).  |  [optional]



