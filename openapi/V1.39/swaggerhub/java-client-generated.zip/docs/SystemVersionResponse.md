
# SystemVersionResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**platform** | [**SystemVersionResponsePlatform**](SystemVersionResponsePlatform.md) |  |  [optional]
**components** | [**List&lt;SystemVersionResponseComponents&gt;**](SystemVersionResponseComponents.md) |  |  [optional]
**version** | **String** |  |  [optional]
**apiVersion** | **String** |  |  [optional]
**minAPIVersion** | **String** |  |  [optional]
**gitCommit** | **String** |  |  [optional]
**goVersion** | **String** |  |  [optional]
**os** | **String** |  |  [optional]
**arch** | **String** |  |  [optional]
**kernelVersion** | **String** |  |  [optional]
**experimental** | **Boolean** |  |  [optional]
**buildTime** | **String** |  |  [optional]



