
# Reachability

## Enum


* `UNKNOWN` (value: `"unknown"`)

* `UNREACHABLE` (value: `"unreachable"`)

* `REACHABLE` (value: `"reachable"`)



