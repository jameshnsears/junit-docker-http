
# TaskSpecContainerSpecPrivileges

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**credentialSpec** | [**TaskSpecContainerSpecPrivilegesCredentialSpec**](TaskSpecContainerSpecPrivilegesCredentialSpec.md) |  |  [optional]
**seLinuxContext** | [**TaskSpecContainerSpecPrivilegesSELinuxContext**](TaskSpecContainerSpecPrivilegesSELinuxContext.md) |  |  [optional]



