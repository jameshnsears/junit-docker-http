
# Swarm

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**joinTokens** | [**JoinTokens**](JoinTokens.md) |  |  [optional]



