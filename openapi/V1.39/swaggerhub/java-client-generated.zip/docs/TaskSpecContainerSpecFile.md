
# TaskSpecContainerSpecFile

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Name represents the final filename in the filesystem. |  [optional]
**UID** | **String** | UID represents the file UID. |  [optional]
**GID** | **String** | GID represents the file GID. |  [optional]
**mode** | **Integer** | Mode represents the FileMode of the file. |  [optional]



