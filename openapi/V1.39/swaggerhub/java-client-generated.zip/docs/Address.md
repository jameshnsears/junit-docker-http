
# Address

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**addr** | **String** | IP address. |  [optional]
**prefixLen** | **Integer** | Mask length of the IP address. |  [optional]



