
# GenericResourcesInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**namedResourceSpec** | [**GenericResourcesInnerNamedResourceSpec**](GenericResourcesInnerNamedResourceSpec.md) |  |  [optional]
**discreteResourceSpec** | [**GenericResourcesInnerDiscreteResourceSpec**](GenericResourcesInnerDiscreteResourceSpec.md) |  |  [optional]



