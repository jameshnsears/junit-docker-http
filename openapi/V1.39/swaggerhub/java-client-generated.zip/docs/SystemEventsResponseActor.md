
# SystemEventsResponseActor

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ID** | **String** | The ID of the object emitting the event |  [optional]
**attributes** | **Map&lt;String, String&gt;** | Various key/value attributes of the object, depending on its type |  [optional]



