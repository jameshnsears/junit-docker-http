
# ContainerWaitResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**statusCode** | **Integer** | Exit code of the container | 
**error** | [**ContainerWaitResponseError**](ContainerWaitResponseError.md) |  |  [optional]



