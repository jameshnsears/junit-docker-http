
# PortBinding

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hostIp** | **String** | Host IP address that the container&#39;s port is mapped to. |  [optional]
**hostPort** | **String** | Host port number that the container&#39;s port is mapped to. |  [optional]



