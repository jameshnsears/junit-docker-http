
# ResourceObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nanoCPUs** | **Long** |  |  [optional]
**memoryBytes** | **Long** |  |  [optional]
**genericResources** | [**GenericResources**](GenericResources.md) |  |  [optional]



