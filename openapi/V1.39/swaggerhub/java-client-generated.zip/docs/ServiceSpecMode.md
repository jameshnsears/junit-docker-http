
# ServiceSpecMode

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**replicated** | [**ServiceSpecModeReplicated**](ServiceSpecModeReplicated.md) |  |  [optional]
**global** | **Object** |  |  [optional]



