
# SwarmSpecTaskDefaultsLogDriver

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | The log driver to use as a default for new tasks.  |  [optional]
**options** | **Map&lt;String, String&gt;** | Driver-specific options for the selectd log driver, specified as key/value pairs.  |  [optional]



