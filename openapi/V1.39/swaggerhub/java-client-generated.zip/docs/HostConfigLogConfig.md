
# HostConfigLogConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | [**TypeEnum**](#TypeEnum) |  |  [optional]
**config** | **Map&lt;String, String&gt;** |  |  [optional]


<a name="TypeEnum"></a>
## Enum: TypeEnum
Name | Value
---- | -----
JSON_FILE | &quot;json-file&quot;
SYSLOG | &quot;syslog&quot;
JOURNALD | &quot;journald&quot;
GELF | &quot;gelf&quot;
FLUENTD | &quot;fluentd&quot;
AWSLOGS | &quot;awslogs&quot;
SPLUNK | &quot;splunk&quot;
ETWLOGS | &quot;etwlogs&quot;
NONE | &quot;none&quot;



