
# PushImageInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | **String** |  |  [optional]
**status** | **String** |  |  [optional]
**progress** | **String** |  |  [optional]
**progressDetail** | [**ProgressDetail**](ProgressDetail.md) |  |  [optional]



