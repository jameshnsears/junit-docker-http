
# MountPoint

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** |  |  [optional]
**name** | **String** |  |  [optional]
**source** | **String** |  |  [optional]
**destination** | **String** |  |  [optional]
**driver** | **String** |  |  [optional]
**mode** | **String** |  |  [optional]
**RW** | **Boolean** |  |  [optional]
**propagation** | **String** |  |  [optional]



