
# ServiceEndpoint

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**spec** | [**EndpointSpec**](EndpointSpec.md) |  |  [optional]
**ports** | [**List&lt;EndpointPortConfig&gt;**](EndpointPortConfig.md) |  |  [optional]
**virtualIPs** | [**List&lt;ServiceEndpointVirtualIPs&gt;**](ServiceEndpointVirtualIPs.md) |  |  [optional]



