
# ThrottleDevice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**path** | **String** | Device path |  [optional]
**rate** | **Long** | Rate |  [optional]



