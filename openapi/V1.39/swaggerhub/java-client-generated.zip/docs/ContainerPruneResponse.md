
# ContainerPruneResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**containersDeleted** | **List&lt;String&gt;** | Container IDs that were deleted |  [optional]
**spaceReclaimed** | **Long** | Disk space reclaimed in bytes |  [optional]



