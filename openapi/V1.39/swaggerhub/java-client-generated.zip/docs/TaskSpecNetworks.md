
# TaskSpecNetworks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**target** | **String** |  |  [optional]
**aliases** | **List&lt;String&gt;** |  |  [optional]



