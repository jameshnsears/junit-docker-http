
# TaskStatusContainerStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**containerID** | **String** |  |  [optional]
**PID** | **Integer** |  |  [optional]
**exitCode** | **Integer** |  |  [optional]



