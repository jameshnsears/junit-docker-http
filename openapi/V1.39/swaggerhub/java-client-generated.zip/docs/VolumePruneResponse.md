
# VolumePruneResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**volumesDeleted** | **List&lt;String&gt;** | Volumes that were deleted |  [optional]
**spaceReclaimed** | **Long** | Disk space reclaimed in bytes |  [optional]



