
# TaskSpecContainerSpecDNSConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nameservers** | **List&lt;String&gt;** | The IP addresses of the name servers. |  [optional]
**search** | **List&lt;String&gt;** | A search list for host-name lookup. |  [optional]
**options** | **List&lt;String&gt;** | A list of internal resolver variables to be modified (e.g., &#x60;debug&#x60;, &#x60;ndots:3&#x60;, etc.). |  [optional]



