
# ServiceEndpointVirtualIPs

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**networkID** | **String** |  |  [optional]
**addr** | **String** |  |  [optional]



