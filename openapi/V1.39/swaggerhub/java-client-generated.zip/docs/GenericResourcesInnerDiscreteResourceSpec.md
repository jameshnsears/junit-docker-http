
# GenericResourcesInnerDiscreteResourceSpec

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**kind** | **String** |  |  [optional]
**value** | **Long** |  |  [optional]



