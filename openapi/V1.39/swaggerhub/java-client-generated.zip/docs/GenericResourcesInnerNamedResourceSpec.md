
# GenericResourcesInnerNamedResourceSpec

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**kind** | **String** |  |  [optional]
**value** | **String** |  |  [optional]



