
# PeerNode

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nodeID** | **String** | Unique identifier of for this node in the swarm. |  [optional]
**addr** | **String** | IP address and ports at which this node can be reached.  |  [optional]



