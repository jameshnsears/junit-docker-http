
# DistributionInspectResponsePlatforms

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**architecture** | **String** |  |  [optional]
**OS** | **String** |  |  [optional]
**osVersion** | **String** |  |  [optional]
**osFeatures** | **List&lt;String&gt;** |  |  [optional]
**variant** | **String** |  |  [optional]
**features** | **List&lt;String&gt;** |  |  [optional]



