
# ImageSearchResponseItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **String** |  |  [optional]
**isOfficial** | **Boolean** |  |  [optional]
**isAutomated** | **Boolean** |  |  [optional]
**name** | **String** |  |  [optional]
**starCount** | **Integer** |  |  [optional]



