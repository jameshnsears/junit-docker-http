
# NodeDescription

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hostname** | **String** |  |  [optional]
**platform** | [**Platform**](Platform.md) |  |  [optional]
**resources** | [**ResourceObject**](ResourceObject.md) |  |  [optional]
**engine** | [**EngineDescription**](EngineDescription.md) |  |  [optional]
**tlSInfo** | [**TLSInfo**](TLSInfo.md) |  |  [optional]



