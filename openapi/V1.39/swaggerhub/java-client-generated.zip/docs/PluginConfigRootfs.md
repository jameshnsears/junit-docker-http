
# PluginConfigRootfs

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** |  |  [optional]
**diffIds** | **List&lt;String&gt;** |  |  [optional]



