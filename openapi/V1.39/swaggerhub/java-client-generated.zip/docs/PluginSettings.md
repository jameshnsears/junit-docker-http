
# PluginSettings

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mounts** | [**List&lt;PluginMount&gt;**](PluginMount.md) |  | 
**env** | **List&lt;String&gt;** |  | 
**args** | **List&lt;String&gt;** |  | 
**devices** | [**List&lt;PluginDevice&gt;**](PluginDevice.md) |  | 



