
# PluginConfigUser

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**UID** | **Integer** |  |  [optional]
**GID** | **Integer** |  |  [optional]



