
# ResourcesBlkioWeightDevice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**path** | **String** |  |  [optional]
**weight** | **Integer** |  |  [optional]



