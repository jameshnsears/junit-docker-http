
# ContainerSummaryInnerNetworkSettings

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**networks** | [**Map&lt;String, EndpointSettings&gt;**](EndpointSettings.md) |  |  [optional]



