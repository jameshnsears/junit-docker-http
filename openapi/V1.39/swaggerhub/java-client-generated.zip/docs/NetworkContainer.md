
# NetworkContainer

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  |  [optional]
**endpointID** | **String** |  |  [optional]
**macAddress** | **String** |  |  [optional]
**ipv4Address** | **String** |  |  [optional]
**ipv6Address** | **String** |  |  [optional]



