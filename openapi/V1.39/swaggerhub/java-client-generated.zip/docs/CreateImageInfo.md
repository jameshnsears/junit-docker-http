
# CreateImageInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  |  [optional]
**error** | **String** |  |  [optional]
**status** | **String** |  |  [optional]
**progress** | **String** |  |  [optional]
**progressDetail** | [**ProgressDetail**](ProgressDetail.md) |  |  [optional]



