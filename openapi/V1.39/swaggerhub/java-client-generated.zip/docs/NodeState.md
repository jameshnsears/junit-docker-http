
# NodeState

## Enum


* `UNKNOWN` (value: `"unknown"`)

* `DOWN` (value: `"down"`)

* `READY` (value: `"ready"`)

* `DISCONNECTED` (value: `"disconnected"`)



