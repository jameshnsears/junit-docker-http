
# Commit

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ID** | **String** | Actual commit ID of external tool. |  [optional]
**expected** | **String** | Commit ID of external tool expected by dockerd as set at build time.  |  [optional]



