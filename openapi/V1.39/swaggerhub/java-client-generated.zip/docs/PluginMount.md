
# PluginMount

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**description** | **String** |  | 
**settable** | **List&lt;String&gt;** |  | 
**source** | **String** |  | 
**destination** | **String** |  | 
**type** | **String** |  | 
**options** | **List&lt;String&gt;** |  | 



