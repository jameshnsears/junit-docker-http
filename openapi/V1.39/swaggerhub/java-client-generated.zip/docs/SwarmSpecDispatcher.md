
# SwarmSpecDispatcher

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**heartbeatPeriod** | **Long** | The delay for an agent to send a heartbeat to the dispatcher. |  [optional]



