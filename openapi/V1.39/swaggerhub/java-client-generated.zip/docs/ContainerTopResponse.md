
# ContainerTopResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**titles** | **List&lt;String&gt;** | The ps column titles |  [optional]
**processes** | [**List&lt;List&lt;String&gt;&gt;**](List.md) | Each process running in the container, where each is process is an array of values corresponding to the titles |  [optional]



