
# GraphDriverData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**data** | **Map&lt;String, String&gt;** |  | 



