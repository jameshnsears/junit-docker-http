
# NetworkCreateResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | The ID of the created network. |  [optional]
**warning** | **String** |  |  [optional]



