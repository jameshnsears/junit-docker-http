
# PluginsInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**volume** | **List&lt;String&gt;** | Names of available volume-drivers, and network-driver plugins. |  [optional]
**network** | **List&lt;String&gt;** | Names of available network-drivers, and network-driver plugins. |  [optional]
**authorization** | **List&lt;String&gt;** | Names of available authorization plugins. |  [optional]
**log** | **List&lt;String&gt;** | Names of available logging-drivers, and logging-driver plugins. |  [optional]



