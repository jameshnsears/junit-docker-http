
# SwarmSpecTaskDefaults

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**logDriver** | [**SwarmSpecTaskDefaultsLogDriver**](SwarmSpecTaskDefaultsLogDriver.md) |  |  [optional]



