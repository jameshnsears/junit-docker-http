
# VolumeListResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**volumes** | [**List&lt;Volume&gt;**](Volume.md) | List of volumes | 
**warnings** | **List&lt;String&gt;** | Warnings that occurred when fetching the list of volumes | 



