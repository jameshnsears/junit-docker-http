
# ImageSummary

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | 
**parentId** | **String** |  | 
**repoTags** | **List&lt;String&gt;** |  | 
**repoDigests** | **List&lt;String&gt;** |  | 
**created** | **Integer** |  | 
**size** | **Integer** |  | 
**sharedSize** | **Integer** |  | 
**virtualSize** | **Integer** |  | 
**labels** | **Map&lt;String, String&gt;** |  | 
**containers** | **Integer** |  | 



