
# ResourcesUlimits

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Name of ulimit |  [optional]
**soft** | **Integer** | Soft limit |  [optional]
**hard** | **Integer** | Hard limit |  [optional]



