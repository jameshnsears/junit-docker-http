
# TaskState

## Enum


* `NEW` (value: `"new"`)

* `ALLOCATED` (value: `"allocated"`)

* `PENDING` (value: `"pending"`)

* `ASSIGNED` (value: `"assigned"`)

* `ACCEPTED` (value: `"accepted"`)

* `PREPARING` (value: `"preparing"`)

* `READY` (value: `"ready"`)

* `STARTING` (value: `"starting"`)

* `RUNNING` (value: `"running"`)

* `COMPLETE` (value: `"complete"`)

* `SHUTDOWN` (value: `"shutdown"`)

* `FAILED` (value: `"failed"`)

* `REJECTED` (value: `"rejected"`)

* `REMOVE` (value: `"remove"`)

* `ORPHANED` (value: `"orphaned"`)



