
# TaskStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**timestamp** | **String** |  |  [optional]
**state** | [**TaskState**](TaskState.md) |  |  [optional]
**message** | **String** |  |  [optional]
**err** | **String** |  |  [optional]
**containerStatus** | [**TaskStatusContainerStatus**](TaskStatusContainerStatus.md) |  |  [optional]



