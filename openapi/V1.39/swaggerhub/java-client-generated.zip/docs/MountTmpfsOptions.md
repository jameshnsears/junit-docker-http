
# MountTmpfsOptions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sizeBytes** | **Long** | The size for the tmpfs mount in bytes. |  [optional]
**mode** | **Integer** | The permission mode for the tmpfs mount in an integer. |  [optional]



