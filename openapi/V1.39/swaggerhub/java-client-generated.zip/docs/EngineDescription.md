
# EngineDescription

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**engineVersion** | **String** |  |  [optional]
**labels** | **Map&lt;String, String&gt;** |  |  [optional]
**plugins** | [**List&lt;EngineDescriptionPlugins&gt;**](EngineDescriptionPlugins.md) |  |  [optional]



