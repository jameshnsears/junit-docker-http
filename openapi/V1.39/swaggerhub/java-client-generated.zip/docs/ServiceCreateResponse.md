
# ServiceCreateResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ID** | **String** | The ID of the created service. |  [optional]
**warning** | **String** | Optional warning message |  [optional]



