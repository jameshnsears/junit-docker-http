
# BuildInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  |  [optional]
**stream** | **String** |  |  [optional]
**error** | **String** |  |  [optional]
**errorDetail** | [**ErrorDetail**](ErrorDetail.md) |  |  [optional]
**status** | **String** |  |  [optional]
**progress** | **String** |  |  [optional]
**progressDetail** | [**ProgressDetail**](ProgressDetail.md) |  |  [optional]
**aux** | [**ImageID**](ImageID.md) |  |  [optional]



