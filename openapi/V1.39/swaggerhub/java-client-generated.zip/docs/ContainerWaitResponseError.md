
# ContainerWaitResponseError

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | **String** | Details of an error |  [optional]



