
# PluginPrivilegeItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  |  [optional]
**description** | **String** |  |  [optional]
**value** | **List&lt;String&gt;** |  |  [optional]



