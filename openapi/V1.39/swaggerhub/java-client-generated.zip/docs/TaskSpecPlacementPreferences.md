
# TaskSpecPlacementPreferences

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**spread** | [**TaskSpecPlacementSpread**](TaskSpecPlacementSpread.md) |  |  [optional]



