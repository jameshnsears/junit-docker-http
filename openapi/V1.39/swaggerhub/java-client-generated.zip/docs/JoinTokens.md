
# JoinTokens

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**worker** | **String** | The token workers can use to join the swarm.  |  [optional]
**manager** | **String** | The token managers can use to join the swarm.  |  [optional]



