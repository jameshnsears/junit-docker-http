
# ProgressDetail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**current** | **Integer** |  |  [optional]
**total** | **Integer** |  |  [optional]



