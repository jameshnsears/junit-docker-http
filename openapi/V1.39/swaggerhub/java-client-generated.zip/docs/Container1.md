
# Container1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**container** | **String** | The ID or name of the container to disconnect from the network. |  [optional]
**force** | **Boolean** | Force the container to disconnect from the network. |  [optional]



