
# MountVolumeOptions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**noCopy** | **Boolean** | Populate volume with data from the target. |  [optional]
**labels** | **Map&lt;String, String&gt;** | User-defined key/value metadata. |  [optional]
**driverConfig** | [**MountVolumeOptionsDriverConfig**](MountVolumeOptionsDriverConfig.md) |  |  [optional]



