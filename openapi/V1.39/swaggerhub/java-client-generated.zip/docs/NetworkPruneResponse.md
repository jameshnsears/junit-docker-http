
# NetworkPruneResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**networksDeleted** | **List&lt;String&gt;** | Networks that were deleted |  [optional]



