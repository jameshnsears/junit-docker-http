
# SystemVersionResponseComponents

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**version** | **String** |  | 
**details** | **Object** |  |  [optional]



