
# PluginInterfaceType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**prefix** | **String** |  | 
**capability** | **String** |  | 
**version** | **String** |  | 



