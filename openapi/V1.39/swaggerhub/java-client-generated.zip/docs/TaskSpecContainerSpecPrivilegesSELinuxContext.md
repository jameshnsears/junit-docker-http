
# TaskSpecContainerSpecPrivilegesSELinuxContext

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**disable** | **Boolean** | Disable SELinux |  [optional]
**user** | **String** | SELinux user label |  [optional]
**role** | **String** | SELinux role label |  [optional]
**type** | **String** | SELinux type label |  [optional]
**level** | **String** | SELinux level label |  [optional]



