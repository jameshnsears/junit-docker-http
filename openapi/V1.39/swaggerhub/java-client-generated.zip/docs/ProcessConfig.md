
# ProcessConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**privileged** | **Boolean** |  |  [optional]
**user** | **String** |  |  [optional]
**tty** | **Boolean** |  |  [optional]
**entrypoint** | **String** |  |  [optional]
**arguments** | **List&lt;String&gt;** |  |  [optional]



