
# ImageDeleteResponseItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**untagged** | **String** | The image ID of an image that was untagged |  [optional]
**deleted** | **String** | The image ID of an image that was deleted |  [optional]



