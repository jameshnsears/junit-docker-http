
# Body3

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**unlockKey** | **String** | The swarm&#39;s unlock key. |  [optional]



