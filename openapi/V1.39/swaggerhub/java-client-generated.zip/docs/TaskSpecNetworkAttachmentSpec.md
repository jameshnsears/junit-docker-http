
# TaskSpecNetworkAttachmentSpec

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**containerID** | **String** | ID of the container represented by this task |  [optional]



