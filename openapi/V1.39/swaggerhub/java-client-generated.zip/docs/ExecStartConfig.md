
# ExecStartConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**detach** | **Boolean** | Detach from the command. |  [optional]
**tty** | **Boolean** | Allocate a pseudo-TTY. |  [optional]



