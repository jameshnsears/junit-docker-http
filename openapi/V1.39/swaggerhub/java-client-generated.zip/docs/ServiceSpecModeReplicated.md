
# ServiceSpecModeReplicated

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**replicas** | **Long** |  |  [optional]



