
# LocalNodeState

## Enum


* `EMPTY` (value: `""`)

* `INACTIVE` (value: `"inactive"`)

* `PENDING` (value: `"pending"`)

* `ACTIVE` (value: `"active"`)

* `ERROR` (value: `"error"`)

* `LOCKED` (value: `"locked"`)



