
# TaskSpecLogDriver

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  |  [optional]
**options** | **Map&lt;String, String&gt;** |  |  [optional]



