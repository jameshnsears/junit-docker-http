
# ImageRootFS

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** |  | 
**layers** | **List&lt;String&gt;** |  |  [optional]
**baseLayer** | **String** |  |  [optional]



