
# BuildPruneResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cachesDeleted** | **List&lt;String&gt;** |  |  [optional]
**spaceReclaimed** | **Long** | Disk space reclaimed in bytes |  [optional]



