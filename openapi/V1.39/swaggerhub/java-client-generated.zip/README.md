# swagger-java-client

## Requirements

Building the API client library requires [Maven](https://maven.apache.org/) to be installed.

## Installation

To install the API client library to your local Maven repository, simply execute:

```shell
mvn install
```

To deploy it to a remote Maven repository instead, configure the settings of the repository and execute:

```shell
mvn deploy
```

Refer to the [official documentation](https://maven.apache.org/plugins/maven-deploy-plugin/usage.html) for more information.

### Maven users

Add this dependency to your project's POM:

```xml
<dependency>
    <groupId>io.swagger</groupId>
    <artifactId>swagger-java-client</artifactId>
    <version>1.0.0</version>
    <scope>compile</scope>
</dependency>
```

### Gradle users

Add this dependency to your project's build file:

```groovy
compile "io.swagger:swagger-java-client:1.0.0"
```

### Others

At first generate the JAR by executing:

    mvn package

Then manually install the following JARs:

* target/swagger-java-client-1.0.0.jar
* target/lib/*.jar

## Getting Started

Please follow the [installation](#installation) instruction and execute the following Java code:

```java

import io.swagger.client.*;
import io.swagger.client.auth.*;
import io.swagger.client.model.*;
import io.swagger.client.api.ConfigApi;

import java.io.File;
import java.util.*;

public class ConfigApiExample {

    public static void main(String[] args) {
        
        ConfigApi apiInstance = new ConfigApi();
         body = new null(); //  | 
        try {
            IdResponse result = apiInstance.configCreate(body);
            System.out.println(result);
        } catch (ApiException e) {
            System.err.println("Exception when calling ConfigApi#configCreate");
            e.printStackTrace();
        }
    }
}

```

## Documentation for API Endpoints

All URIs are relative to *http://localhost/v1.39*

Class | Method | HTTP request | Description
------------ | ------------- | ------------- | -------------
*ConfigApi* | [**configCreate**](docs/ConfigApi.md#configCreate) | **POST** /configs/create | Create a config
*ConfigApi* | [**configDelete**](docs/ConfigApi.md#configDelete) | **DELETE** /configs/{id} | Delete a config
*ConfigApi* | [**configInspect**](docs/ConfigApi.md#configInspect) | **GET** /configs/{id} | Inspect a config
*ConfigApi* | [**configList**](docs/ConfigApi.md#configList) | **GET** /configs | List configs
*ConfigApi* | [**configUpdate**](docs/ConfigApi.md#configUpdate) | **POST** /configs/{id}/update | Update a Config
*ContainerApi* | [**containerArchive**](docs/ContainerApi.md#containerArchive) | **GET** /containers/{id}/archive | Get an archive of a filesystem resource in a container
*ContainerApi* | [**containerArchiveInfo**](docs/ContainerApi.md#containerArchiveInfo) | **HEAD** /containers/{id}/archive | Get information about files in a container
*ContainerApi* | [**containerAttach**](docs/ContainerApi.md#containerAttach) | **POST** /containers/{id}/attach | Attach to a container
*ContainerApi* | [**containerAttachWebsocket**](docs/ContainerApi.md#containerAttachWebsocket) | **GET** /containers/{id}/attach/ws | Attach to a container via a websocket
*ContainerApi* | [**containerChanges**](docs/ContainerApi.md#containerChanges) | **GET** /containers/{id}/changes | Get changes on a container’s filesystem
*ContainerApi* | [**containerCreate**](docs/ContainerApi.md#containerCreate) | **POST** /containers/create | Create a container
*ContainerApi* | [**containerDelete**](docs/ContainerApi.md#containerDelete) | **DELETE** /containers/{id} | Remove a container
*ContainerApi* | [**containerExport**](docs/ContainerApi.md#containerExport) | **GET** /containers/{id}/export | Export a container
*ContainerApi* | [**containerInspect**](docs/ContainerApi.md#containerInspect) | **GET** /containers/{id}/json | Inspect a container
*ContainerApi* | [**containerKill**](docs/ContainerApi.md#containerKill) | **POST** /containers/{id}/kill | Kill a container
*ContainerApi* | [**containerList**](docs/ContainerApi.md#containerList) | **GET** /containers/json | List containers
*ContainerApi* | [**containerLogs**](docs/ContainerApi.md#containerLogs) | **GET** /containers/{id}/logs | Get container logs
*ContainerApi* | [**containerPause**](docs/ContainerApi.md#containerPause) | **POST** /containers/{id}/pause | Pause a container
*ContainerApi* | [**containerPrune**](docs/ContainerApi.md#containerPrune) | **POST** /containers/prune | Delete stopped containers
*ContainerApi* | [**containerRename**](docs/ContainerApi.md#containerRename) | **POST** /containers/{id}/rename | Rename a container
*ContainerApi* | [**containerResize**](docs/ContainerApi.md#containerResize) | **POST** /containers/{id}/resize | Resize a container TTY
*ContainerApi* | [**containerRestart**](docs/ContainerApi.md#containerRestart) | **POST** /containers/{id}/restart | Restart a container
*ContainerApi* | [**containerStart**](docs/ContainerApi.md#containerStart) | **POST** /containers/{id}/start | Start a container
*ContainerApi* | [**containerStats**](docs/ContainerApi.md#containerStats) | **GET** /containers/{id}/stats | Get container stats based on resource usage
*ContainerApi* | [**containerStop**](docs/ContainerApi.md#containerStop) | **POST** /containers/{id}/stop | Stop a container
*ContainerApi* | [**containerTop**](docs/ContainerApi.md#containerTop) | **GET** /containers/{id}/top | List processes running inside a container
*ContainerApi* | [**containerUnpause**](docs/ContainerApi.md#containerUnpause) | **POST** /containers/{id}/unpause | Unpause a container
*ContainerApi* | [**containerUpdate**](docs/ContainerApi.md#containerUpdate) | **POST** /containers/{id}/update | Update a container
*ContainerApi* | [**containerWait**](docs/ContainerApi.md#containerWait) | **POST** /containers/{id}/wait | Wait for a container
*ContainerApi* | [**putContainerArchive**](docs/ContainerApi.md#putContainerArchive) | **PUT** /containers/{id}/archive | Extract an archive of files or folders to a directory in a container
*DefaultApi* | [**taskLogs**](docs/DefaultApi.md#taskLogs) | **GET** /tasks/{id}/logs | Get task logs
*DistributionApi* | [**distributionInspect**](docs/DistributionApi.md#distributionInspect) | **GET** /distribution/{name}/json | Get image information from the registry
*ExecApi* | [**containerExec**](docs/ExecApi.md#containerExec) | **POST** /containers/{id}/exec | Create an exec instance
*ExecApi* | [**execInspect**](docs/ExecApi.md#execInspect) | **GET** /exec/{id}/json | Inspect an exec instance
*ExecApi* | [**execResize**](docs/ExecApi.md#execResize) | **POST** /exec/{id}/resize | Resize an exec instance
*ExecApi* | [**execStart**](docs/ExecApi.md#execStart) | **POST** /exec/{id}/start | Start an exec instance
*ImageApi* | [**buildPrune**](docs/ImageApi.md#buildPrune) | **POST** /build/prune | Delete builder cache
*ImageApi* | [**imageBuild**](docs/ImageApi.md#imageBuild) | **POST** /build | Build an image
*ImageApi* | [**imageCommit**](docs/ImageApi.md#imageCommit) | **POST** /commit | Create a new image from a container
*ImageApi* | [**imageCreate**](docs/ImageApi.md#imageCreate) | **POST** /images/create | Create an image
*ImageApi* | [**imageDelete**](docs/ImageApi.md#imageDelete) | **DELETE** /images/{name} | Remove an image
*ImageApi* | [**imageGet**](docs/ImageApi.md#imageGet) | **GET** /images/{name}/get | Export an image
*ImageApi* | [**imageGetAll**](docs/ImageApi.md#imageGetAll) | **GET** /images/get | Export several images
*ImageApi* | [**imageHistory**](docs/ImageApi.md#imageHistory) | **GET** /images/{name}/history | Get the history of an image
*ImageApi* | [**imageInspect**](docs/ImageApi.md#imageInspect) | **GET** /images/{name}/json | Inspect an image
*ImageApi* | [**imageList**](docs/ImageApi.md#imageList) | **GET** /images/json | List Images
*ImageApi* | [**imageLoad**](docs/ImageApi.md#imageLoad) | **POST** /images/load | Import images
*ImageApi* | [**imagePrune**](docs/ImageApi.md#imagePrune) | **POST** /images/prune | Delete unused images
*ImageApi* | [**imagePush**](docs/ImageApi.md#imagePush) | **POST** /images/{name}/push | Push an image
*ImageApi* | [**imageSearch**](docs/ImageApi.md#imageSearch) | **GET** /images/search | Search images
*ImageApi* | [**imageTag**](docs/ImageApi.md#imageTag) | **POST** /images/{name}/tag | Tag an image
*NetworkApi* | [**networkConnect**](docs/NetworkApi.md#networkConnect) | **POST** /networks/{id}/connect | Connect a container to a network
*NetworkApi* | [**networkCreate**](docs/NetworkApi.md#networkCreate) | **POST** /networks/create | Create a network
*NetworkApi* | [**networkDelete**](docs/NetworkApi.md#networkDelete) | **DELETE** /networks/{id} | Remove a network
*NetworkApi* | [**networkDisconnect**](docs/NetworkApi.md#networkDisconnect) | **POST** /networks/{id}/disconnect | Disconnect a container from a network
*NetworkApi* | [**networkInspect**](docs/NetworkApi.md#networkInspect) | **GET** /networks/{id} | Inspect a network
*NetworkApi* | [**networkList**](docs/NetworkApi.md#networkList) | **GET** /networks | List networks
*NetworkApi* | [**networkPrune**](docs/NetworkApi.md#networkPrune) | **POST** /networks/prune | Delete unused networks
*NodeApi* | [**nodeDelete**](docs/NodeApi.md#nodeDelete) | **DELETE** /nodes/{id} | Delete a node
*NodeApi* | [**nodeInspect**](docs/NodeApi.md#nodeInspect) | **GET** /nodes/{id} | Inspect a node
*NodeApi* | [**nodeList**](docs/NodeApi.md#nodeList) | **GET** /nodes | List nodes
*NodeApi* | [**nodeUpdate**](docs/NodeApi.md#nodeUpdate) | **POST** /nodes/{id}/update | Update a node
*PluginApi* | [**getPluginPrivileges**](docs/PluginApi.md#getPluginPrivileges) | **GET** /plugins/privileges | Get plugin privileges
*PluginApi* | [**pluginCreate**](docs/PluginApi.md#pluginCreate) | **POST** /plugins/create | Create a plugin
*PluginApi* | [**pluginDelete**](docs/PluginApi.md#pluginDelete) | **DELETE** /plugins/{name} | Remove a plugin
*PluginApi* | [**pluginDisable**](docs/PluginApi.md#pluginDisable) | **POST** /plugins/{name}/disable | Disable a plugin
*PluginApi* | [**pluginEnable**](docs/PluginApi.md#pluginEnable) | **POST** /plugins/{name}/enable | Enable a plugin
*PluginApi* | [**pluginInspect**](docs/PluginApi.md#pluginInspect) | **GET** /plugins/{name}/json | Inspect a plugin
*PluginApi* | [**pluginList**](docs/PluginApi.md#pluginList) | **GET** /plugins | List plugins
*PluginApi* | [**pluginPull**](docs/PluginApi.md#pluginPull) | **POST** /plugins/pull | Install a plugin
*PluginApi* | [**pluginPush**](docs/PluginApi.md#pluginPush) | **POST** /plugins/{name}/push | Push a plugin
*PluginApi* | [**pluginSet**](docs/PluginApi.md#pluginSet) | **POST** /plugins/{name}/set | Configure a plugin
*PluginApi* | [**pluginUpgrade**](docs/PluginApi.md#pluginUpgrade) | **POST** /plugins/{name}/upgrade | Upgrade a plugin
*SecretApi* | [**secretCreate**](docs/SecretApi.md#secretCreate) | **POST** /secrets/create | Create a secret
*SecretApi* | [**secretDelete**](docs/SecretApi.md#secretDelete) | **DELETE** /secrets/{id} | Delete a secret
*SecretApi* | [**secretInspect**](docs/SecretApi.md#secretInspect) | **GET** /secrets/{id} | Inspect a secret
*SecretApi* | [**secretList**](docs/SecretApi.md#secretList) | **GET** /secrets | List secrets
*SecretApi* | [**secretUpdate**](docs/SecretApi.md#secretUpdate) | **POST** /secrets/{id}/update | Update a Secret
*ServiceApi* | [**serviceCreate**](docs/ServiceApi.md#serviceCreate) | **POST** /services/create | Create a service
*ServiceApi* | [**serviceDelete**](docs/ServiceApi.md#serviceDelete) | **DELETE** /services/{id} | Delete a service
*ServiceApi* | [**serviceInspect**](docs/ServiceApi.md#serviceInspect) | **GET** /services/{id} | Inspect a service
*ServiceApi* | [**serviceList**](docs/ServiceApi.md#serviceList) | **GET** /services | List services
*ServiceApi* | [**serviceLogs**](docs/ServiceApi.md#serviceLogs) | **GET** /services/{id}/logs | Get service logs
*ServiceApi* | [**serviceUpdate**](docs/ServiceApi.md#serviceUpdate) | **POST** /services/{id}/update | Update a service
*SessionExperimentalApi* | [**session**](docs/SessionExperimentalApi.md#session) | **POST** /session | Initialize interactive session
*SwarmApi* | [**swarmInit**](docs/SwarmApi.md#swarmInit) | **POST** /swarm/init | Initialize a new swarm
*SwarmApi* | [**swarmInspect**](docs/SwarmApi.md#swarmInspect) | **GET** /swarm | Inspect swarm
*SwarmApi* | [**swarmJoin**](docs/SwarmApi.md#swarmJoin) | **POST** /swarm/join | Join an existing swarm
*SwarmApi* | [**swarmLeave**](docs/SwarmApi.md#swarmLeave) | **POST** /swarm/leave | Leave a swarm
*SwarmApi* | [**swarmUnlock**](docs/SwarmApi.md#swarmUnlock) | **POST** /swarm/unlock | Unlock a locked manager
*SwarmApi* | [**swarmUnlockkey**](docs/SwarmApi.md#swarmUnlockkey) | **GET** /swarm/unlockkey | Get the unlock key
*SwarmApi* | [**swarmUpdate**](docs/SwarmApi.md#swarmUpdate) | **POST** /swarm/update | Update a swarm
*SystemApi* | [**systemAuth**](docs/SystemApi.md#systemAuth) | **POST** /auth | Check auth configuration
*SystemApi* | [**systemDataUsage**](docs/SystemApi.md#systemDataUsage) | **GET** /system/df | Get data usage information
*SystemApi* | [**systemEvents**](docs/SystemApi.md#systemEvents) | **GET** /events | Monitor events
*SystemApi* | [**systemInfo**](docs/SystemApi.md#systemInfo) | **GET** /info | Get system information
*SystemApi* | [**systemPing**](docs/SystemApi.md#systemPing) | **GET** /_ping | Ping
*SystemApi* | [**systemVersion**](docs/SystemApi.md#systemVersion) | **GET** /version | Get version
*TaskApi* | [**taskInspect**](docs/TaskApi.md#taskInspect) | **GET** /tasks/{id} | Inspect a task
*TaskApi* | [**taskList**](docs/TaskApi.md#taskList) | **GET** /tasks | List tasks
*VolumeApi* | [**volumeCreate**](docs/VolumeApi.md#volumeCreate) | **POST** /volumes/create | Create a volume
*VolumeApi* | [**volumeDelete**](docs/VolumeApi.md#volumeDelete) | **DELETE** /volumes/{name} | Remove a volume
*VolumeApi* | [**volumeInspect**](docs/VolumeApi.md#volumeInspect) | **GET** /volumes/{name} | Inspect a volume
*VolumeApi* | [**volumeList**](docs/VolumeApi.md#volumeList) | **GET** /volumes | List volumes
*VolumeApi* | [**volumePrune**](docs/VolumeApi.md#volumePrune) | **POST** /volumes/prune | Delete unused volumes


## Documentation for Models

 - [Address](docs/Address.md)
 - [AuthConfig](docs/AuthConfig.md)
 - [Body](docs/Body.md)
 - [Body1](docs/Body1.md)
 - [Body2](docs/Body2.md)
 - [Body3](docs/Body3.md)
 - [BuildCache](docs/BuildCache.md)
 - [BuildInfo](docs/BuildInfo.md)
 - [BuildPruneResponse](docs/BuildPruneResponse.md)
 - [ClusterInfo](docs/ClusterInfo.md)
 - [Commit](docs/Commit.md)
 - [Config](docs/Config.md)
 - [ConfigSpec](docs/ConfigSpec.md)
 - [Container](docs/Container.md)
 - [Container1](docs/Container1.md)
 - [ContainerChangeResponseItem](docs/ContainerChangeResponseItem.md)
 - [ContainerConfig](docs/ContainerConfig.md)
 - [ContainerCreateResponse](docs/ContainerCreateResponse.md)
 - [ContainerInspectResponse](docs/ContainerInspectResponse.md)
 - [ContainerInspectResponseState](docs/ContainerInspectResponseState.md)
 - [ContainerPruneResponse](docs/ContainerPruneResponse.md)
 - [ContainerSummary](docs/ContainerSummary.md)
 - [ContainerSummaryInner](docs/ContainerSummaryInner.md)
 - [ContainerSummaryInnerHostConfig](docs/ContainerSummaryInnerHostConfig.md)
 - [ContainerSummaryInnerNetworkSettings](docs/ContainerSummaryInnerNetworkSettings.md)
 - [ContainerTopResponse](docs/ContainerTopResponse.md)
 - [ContainerUpdateResponse](docs/ContainerUpdateResponse.md)
 - [ContainerWaitResponse](docs/ContainerWaitResponse.md)
 - [ContainerWaitResponseError](docs/ContainerWaitResponseError.md)
 - [CreateImageInfo](docs/CreateImageInfo.md)
 - [DeviceMapping](docs/DeviceMapping.md)
 - [DistributionInspectResponse](docs/DistributionInspectResponse.md)
 - [DistributionInspectResponseDescriptor](docs/DistributionInspectResponseDescriptor.md)
 - [DistributionInspectResponsePlatforms](docs/DistributionInspectResponsePlatforms.md)
 - [Driver](docs/Driver.md)
 - [EndpointIPAMConfig](docs/EndpointIPAMConfig.md)
 - [EndpointPortConfig](docs/EndpointPortConfig.md)
 - [EndpointSettings](docs/EndpointSettings.md)
 - [EndpointSpec](docs/EndpointSpec.md)
 - [EngineDescription](docs/EngineDescription.md)
 - [EngineDescriptionPlugins](docs/EngineDescriptionPlugins.md)
 - [ErrorDetail](docs/ErrorDetail.md)
 - [ErrorResponse](docs/ErrorResponse.md)
 - [ExecConfig](docs/ExecConfig.md)
 - [ExecInspectResponse](docs/ExecInspectResponse.md)
 - [ExecStartConfig](docs/ExecStartConfig.md)
 - [GenericResources](docs/GenericResources.md)
 - [GenericResourcesInner](docs/GenericResourcesInner.md)
 - [GenericResourcesInnerDiscreteResourceSpec](docs/GenericResourcesInnerDiscreteResourceSpec.md)
 - [GenericResourcesInnerNamedResourceSpec](docs/GenericResourcesInnerNamedResourceSpec.md)
 - [GraphDriverData](docs/GraphDriverData.md)
 - [HealthConfig](docs/HealthConfig.md)
 - [HistoryResponseItem](docs/HistoryResponseItem.md)
 - [HostConfig](docs/HostConfig.md)
 - [HostConfigLogConfig](docs/HostConfigLogConfig.md)
 - [IPAM](docs/IPAM.md)
 - [IdResponse](docs/IdResponse.md)
 - [Image](docs/Image.md)
 - [ImageDeleteResponseItem](docs/ImageDeleteResponseItem.md)
 - [ImageID](docs/ImageID.md)
 - [ImageMetadata](docs/ImageMetadata.md)
 - [ImagePruneResponse](docs/ImagePruneResponse.md)
 - [ImageRootFS](docs/ImageRootFS.md)
 - [ImageSearchResponseItem](docs/ImageSearchResponseItem.md)
 - [ImageSummary](docs/ImageSummary.md)
 - [IndexInfo](docs/IndexInfo.md)
 - [InlineResponse400](docs/InlineResponse400.md)
 - [JoinTokens](docs/JoinTokens.md)
 - [LocalNodeState](docs/LocalNodeState.md)
 - [ManagerStatus](docs/ManagerStatus.md)
 - [Mount](docs/Mount.md)
 - [MountBindOptions](docs/MountBindOptions.md)
 - [MountPoint](docs/MountPoint.md)
 - [MountTmpfsOptions](docs/MountTmpfsOptions.md)
 - [MountVolumeOptions](docs/MountVolumeOptions.md)
 - [MountVolumeOptionsDriverConfig](docs/MountVolumeOptionsDriverConfig.md)
 - [Network](docs/Network.md)
 - [NetworkConfig](docs/NetworkConfig.md)
 - [NetworkContainer](docs/NetworkContainer.md)
 - [NetworkCreateResponse](docs/NetworkCreateResponse.md)
 - [NetworkPruneResponse](docs/NetworkPruneResponse.md)
 - [NetworkSettings](docs/NetworkSettings.md)
 - [Node](docs/Node.md)
 - [NodeDescription](docs/NodeDescription.md)
 - [NodeSpec](docs/NodeSpec.md)
 - [NodeState](docs/NodeState.md)
 - [NodeStatus](docs/NodeStatus.md)
 - [ObjectVersion](docs/ObjectVersion.md)
 - [PeerNode](docs/PeerNode.md)
 - [Platform](docs/Platform.md)
 - [Plugin](docs/Plugin.md)
 - [PluginConfig](docs/PluginConfig.md)
 - [PluginConfigArgs](docs/PluginConfigArgs.md)
 - [PluginConfigInterface](docs/PluginConfigInterface.md)
 - [PluginConfigLinux](docs/PluginConfigLinux.md)
 - [PluginConfigNetwork](docs/PluginConfigNetwork.md)
 - [PluginConfigRootfs](docs/PluginConfigRootfs.md)
 - [PluginConfigUser](docs/PluginConfigUser.md)
 - [PluginDevice](docs/PluginDevice.md)
 - [PluginEnv](docs/PluginEnv.md)
 - [PluginInterfaceType](docs/PluginInterfaceType.md)
 - [PluginMount](docs/PluginMount.md)
 - [PluginPrivilegeItem](docs/PluginPrivilegeItem.md)
 - [PluginSettings](docs/PluginSettings.md)
 - [PluginsInfo](docs/PluginsInfo.md)
 - [Port](docs/Port.md)
 - [PortBinding](docs/PortBinding.md)
 - [PortMap](docs/PortMap.md)
 - [ProcessConfig](docs/ProcessConfig.md)
 - [ProgressDetail](docs/ProgressDetail.md)
 - [PushImageInfo](docs/PushImageInfo.md)
 - [Reachability](docs/Reachability.md)
 - [RegistryServiceConfig](docs/RegistryServiceConfig.md)
 - [ResourceObject](docs/ResourceObject.md)
 - [Resources](docs/Resources.md)
 - [ResourcesBlkioWeightDevice](docs/ResourcesBlkioWeightDevice.md)
 - [ResourcesUlimits](docs/ResourcesUlimits.md)
 - [RestartPolicy](docs/RestartPolicy.md)
 - [Runtime](docs/Runtime.md)
 - [Secret](docs/Secret.md)
 - [SecretSpec](docs/SecretSpec.md)
 - [Service](docs/Service.md)
 - [ServiceCreateResponse](docs/ServiceCreateResponse.md)
 - [ServiceEndpoint](docs/ServiceEndpoint.md)
 - [ServiceEndpointVirtualIPs](docs/ServiceEndpointVirtualIPs.md)
 - [ServiceSpec](docs/ServiceSpec.md)
 - [ServiceSpecMode](docs/ServiceSpecMode.md)
 - [ServiceSpecModeReplicated](docs/ServiceSpecModeReplicated.md)
 - [ServiceSpecRollbackConfig](docs/ServiceSpecRollbackConfig.md)
 - [ServiceSpecUpdateConfig](docs/ServiceSpecUpdateConfig.md)
 - [ServiceUpdateResponse](docs/ServiceUpdateResponse.md)
 - [ServiceUpdateStatus](docs/ServiceUpdateStatus.md)
 - [Swarm](docs/Swarm.md)
 - [SwarmInfo](docs/SwarmInfo.md)
 - [SwarmSpec](docs/SwarmSpec.md)
 - [SwarmSpecCAConfig](docs/SwarmSpecCAConfig.md)
 - [SwarmSpecCAConfigExternalCAs](docs/SwarmSpecCAConfigExternalCAs.md)
 - [SwarmSpecDispatcher](docs/SwarmSpecDispatcher.md)
 - [SwarmSpecEncryptionConfig](docs/SwarmSpecEncryptionConfig.md)
 - [SwarmSpecOrchestration](docs/SwarmSpecOrchestration.md)
 - [SwarmSpecRaft](docs/SwarmSpecRaft.md)
 - [SwarmSpecTaskDefaults](docs/SwarmSpecTaskDefaults.md)
 - [SwarmSpecTaskDefaultsLogDriver](docs/SwarmSpecTaskDefaultsLogDriver.md)
 - [SystemAuthResponse](docs/SystemAuthResponse.md)
 - [SystemDataUsageResponse](docs/SystemDataUsageResponse.md)
 - [SystemEventsResponse](docs/SystemEventsResponse.md)
 - [SystemEventsResponseActor](docs/SystemEventsResponseActor.md)
 - [SystemInfo](docs/SystemInfo.md)
 - [SystemVersionResponse](docs/SystemVersionResponse.md)
 - [SystemVersionResponseComponents](docs/SystemVersionResponseComponents.md)
 - [SystemVersionResponsePlatform](docs/SystemVersionResponsePlatform.md)
 - [TLSInfo](docs/TLSInfo.md)
 - [Task](docs/Task.md)
 - [TaskSpec](docs/TaskSpec.md)
 - [TaskSpecContainerSpec](docs/TaskSpecContainerSpec.md)
 - [TaskSpecContainerSpecConfigs](docs/TaskSpecContainerSpecConfigs.md)
 - [TaskSpecContainerSpecDNSConfig](docs/TaskSpecContainerSpecDNSConfig.md)
 - [TaskSpecContainerSpecFile](docs/TaskSpecContainerSpecFile.md)
 - [TaskSpecContainerSpecPrivileges](docs/TaskSpecContainerSpecPrivileges.md)
 - [TaskSpecContainerSpecPrivilegesCredentialSpec](docs/TaskSpecContainerSpecPrivilegesCredentialSpec.md)
 - [TaskSpecContainerSpecPrivilegesSELinuxContext](docs/TaskSpecContainerSpecPrivilegesSELinuxContext.md)
 - [TaskSpecContainerSpecSecrets](docs/TaskSpecContainerSpecSecrets.md)
 - [TaskSpecLogDriver](docs/TaskSpecLogDriver.md)
 - [TaskSpecNetworkAttachmentSpec](docs/TaskSpecNetworkAttachmentSpec.md)
 - [TaskSpecNetworks](docs/TaskSpecNetworks.md)
 - [TaskSpecPlacement](docs/TaskSpecPlacement.md)
 - [TaskSpecPlacementPreferences](docs/TaskSpecPlacementPreferences.md)
 - [TaskSpecPlacementSpread](docs/TaskSpecPlacementSpread.md)
 - [TaskSpecPluginSpec](docs/TaskSpecPluginSpec.md)
 - [TaskSpecResources](docs/TaskSpecResources.md)
 - [TaskSpecRestartPolicy](docs/TaskSpecRestartPolicy.md)
 - [TaskState](docs/TaskState.md)
 - [TaskStatus](docs/TaskStatus.md)
 - [TaskStatusContainerStatus](docs/TaskStatusContainerStatus.md)
 - [ThrottleDevice](docs/ThrottleDevice.md)
 - [UnlockKeyResponse](docs/UnlockKeyResponse.md)
 - [Volume](docs/Volume.md)
 - [VolumeConfig](docs/VolumeConfig.md)
 - [VolumeListResponse](docs/VolumeListResponse.md)
 - [VolumePruneResponse](docs/VolumePruneResponse.md)
 - [VolumeUsageData](docs/VolumeUsageData.md)


## Documentation for Authorization

All endpoints do not require authorization.
Authentication schemes defined for the API:

## Recommendation

It's recommended to create an instance of `ApiClient` per thread in a multithreaded environment to avoid any potential issues.

## Author



