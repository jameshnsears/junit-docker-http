package io.swagger.model;

import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class PluginConfigRootfs  {
  
  @ApiModelProperty(example = "layers", value = "")
  private String type = null;

  @ApiModelProperty(example = "[\"sha256:675532206fbf3030b8458f88d6e26d4eb1577688a25efec97154c94e8b6b4887\",\"sha256:e216a057b1cb1efc11f8a268f37ef62083e70b1b38323ba252e25ac88904a7e8\"]", value = "")
  private List<String> diffIds = null;
 /**
   * Get type
   * @return type
  **/
  @JsonProperty("type")
  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public PluginConfigRootfs type(String type) {
    this.type = type;
    return this;
  }

 /**
   * Get diffIds
   * @return diffIds
  **/
  @JsonProperty("diff_ids")
  public List<String> getDiffIds() {
    return diffIds;
  }

  public void setDiffIds(List<String> diffIds) {
    this.diffIds = diffIds;
  }

  public PluginConfigRootfs diffIds(List<String> diffIds) {
    this.diffIds = diffIds;
    return this;
  }

  public PluginConfigRootfs addDiffIdsItem(String diffIdsItem) {
    this.diffIds.add(diffIdsItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PluginConfigRootfs {\n");
    
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    diffIds: ").append(toIndentedString(diffIds)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

