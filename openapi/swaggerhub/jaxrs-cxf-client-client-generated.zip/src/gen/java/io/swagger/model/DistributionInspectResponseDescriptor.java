package io.swagger.model;

import io.swagger.annotations.ApiModel;
import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * A descriptor struct containing digest, media type, and size
 **/
@ApiModel(description="A descriptor struct containing digest, media type, and size")
public class DistributionInspectResponseDescriptor  {
  
  @ApiModelProperty(value = "")
  private String mediaType = null;

  @ApiModelProperty(value = "")
  private Long size = null;

  @ApiModelProperty(value = "")
  private String digest = null;

  @ApiModelProperty(value = "")
  private List<String> urLs = null;
 /**
   * Get mediaType
   * @return mediaType
  **/
  @JsonProperty("MediaType")
  public String getMediaType() {
    return mediaType;
  }

  public void setMediaType(String mediaType) {
    this.mediaType = mediaType;
  }

  public DistributionInspectResponseDescriptor mediaType(String mediaType) {
    this.mediaType = mediaType;
    return this;
  }

 /**
   * Get size
   * @return size
  **/
  @JsonProperty("Size")
  public Long getSize() {
    return size;
  }

  public void setSize(Long size) {
    this.size = size;
  }

  public DistributionInspectResponseDescriptor size(Long size) {
    this.size = size;
    return this;
  }

 /**
   * Get digest
   * @return digest
  **/
  @JsonProperty("Digest")
  public String getDigest() {
    return digest;
  }

  public void setDigest(String digest) {
    this.digest = digest;
  }

  public DistributionInspectResponseDescriptor digest(String digest) {
    this.digest = digest;
    return this;
  }

 /**
   * Get urLs
   * @return urLs
  **/
  @JsonProperty("URLs")
  public List<String> getUrLs() {
    return urLs;
  }

  public void setUrLs(List<String> urLs) {
    this.urLs = urLs;
  }

  public DistributionInspectResponseDescriptor urLs(List<String> urLs) {
    this.urLs = urLs;
    return this;
  }

  public DistributionInspectResponseDescriptor addUrLsItem(String urLsItem) {
    this.urLs.add(urLsItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class DistributionInspectResponseDescriptor {\n");
    
    sb.append("    mediaType: ").append(toIndentedString(mediaType)).append("\n");
    sb.append("    size: ").append(toIndentedString(size)).append("\n");
    sb.append("    digest: ").append(toIndentedString(digest)).append("\n");
    sb.append("    urLs: ").append(toIndentedString(urLs)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

