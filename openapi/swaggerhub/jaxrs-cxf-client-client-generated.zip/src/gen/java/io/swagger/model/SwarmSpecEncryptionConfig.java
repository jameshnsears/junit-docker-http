package io.swagger.model;

import io.swagger.annotations.ApiModel;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * Parameters related to encryption-at-rest.
 **/
@ApiModel(description="Parameters related to encryption-at-rest.")
public class SwarmSpecEncryptionConfig  {
  
  @ApiModelProperty(example = "false", value = "If set, generate a key and use it to lock data stored on the managers.")
 /**
   * If set, generate a key and use it to lock data stored on the managers.  
  **/
  private Boolean autoLockManagers = null;
 /**
   * If set, generate a key and use it to lock data stored on the managers.
   * @return autoLockManagers
  **/
  @JsonProperty("AutoLockManagers")
  public Boolean isAutoLockManagers() {
    return autoLockManagers;
  }

  public void setAutoLockManagers(Boolean autoLockManagers) {
    this.autoLockManagers = autoLockManagers;
  }

  public SwarmSpecEncryptionConfig autoLockManagers(Boolean autoLockManagers) {
    this.autoLockManagers = autoLockManagers;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SwarmSpecEncryptionConfig {\n");
    
    sb.append("    autoLockManagers: ").append(toIndentedString(autoLockManagers)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

