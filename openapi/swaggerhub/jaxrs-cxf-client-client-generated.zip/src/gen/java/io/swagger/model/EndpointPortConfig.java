package io.swagger.model;


import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class EndpointPortConfig  {
  
  @ApiModelProperty(value = "")
  private String name = null;


@XmlType(name="ProtocolEnum")
@XmlEnum(String.class)
public enum ProtocolEnum {

@XmlEnumValue("tcp") TCP(String.valueOf("tcp")), @XmlEnumValue("udp") UDP(String.valueOf("udp")), @XmlEnumValue("sctp") SCTP(String.valueOf("sctp"));


    private String value;

    ProtocolEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static ProtocolEnum fromValue(String v) {
        for (ProtocolEnum b : ProtocolEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(value = "")
  private ProtocolEnum protocol = null;

  @ApiModelProperty(value = "The port inside the container.")
 /**
   * The port inside the container.  
  **/
  private Integer targetPort = null;

  @ApiModelProperty(value = "The port on the swarm hosts.")
 /**
   * The port on the swarm hosts.  
  **/
  private Integer publishedPort = null;


@XmlType(name="PublishModeEnum")
@XmlEnum(String.class)
public enum PublishModeEnum {

@XmlEnumValue("ingress") INGRESS(String.valueOf("ingress")), @XmlEnumValue("host") HOST(String.valueOf("host"));


    private String value;

    PublishModeEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static PublishModeEnum fromValue(String v) {
        for (PublishModeEnum b : PublishModeEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "ingress", value = "The mode in which port is published.  <p><br /></p>  - \"ingress\" makes the target port accessible on on every node,   regardless of whether there is a task for the service running on   that node or not. - \"host\" bypasses the routing mesh and publish the port directly on   the swarm node where that service is running. ")
 /**
   * The mode in which port is published.  <p><br /></p>  - \"ingress\" makes the target port accessible on on every node,   regardless of whether there is a task for the service running on   that node or not. - \"host\" bypasses the routing mesh and publish the port directly on   the swarm node where that service is running.   
  **/
  private PublishModeEnum publishMode = PublishModeEnum.INGRESS;
 /**
   * Get name
   * @return name
  **/
  @JsonProperty("Name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public EndpointPortConfig name(String name) {
    this.name = name;
    return this;
  }

 /**
   * Get protocol
   * @return protocol
  **/
  @JsonProperty("Protocol")
  public String getProtocol() {
    if (protocol == null) {
      return null;
    }
    return protocol.value();
  }

  public void setProtocol(ProtocolEnum protocol) {
    this.protocol = protocol;
  }

  public EndpointPortConfig protocol(ProtocolEnum protocol) {
    this.protocol = protocol;
    return this;
  }

 /**
   * The port inside the container.
   * @return targetPort
  **/
  @JsonProperty("TargetPort")
  public Integer getTargetPort() {
    return targetPort;
  }

  public void setTargetPort(Integer targetPort) {
    this.targetPort = targetPort;
  }

  public EndpointPortConfig targetPort(Integer targetPort) {
    this.targetPort = targetPort;
    return this;
  }

 /**
   * The port on the swarm hosts.
   * @return publishedPort
  **/
  @JsonProperty("PublishedPort")
  public Integer getPublishedPort() {
    return publishedPort;
  }

  public void setPublishedPort(Integer publishedPort) {
    this.publishedPort = publishedPort;
  }

  public EndpointPortConfig publishedPort(Integer publishedPort) {
    this.publishedPort = publishedPort;
    return this;
  }

 /**
   * The mode in which port is published.  &lt;p&gt;&lt;br /&gt;&lt;/p&gt;  - \&quot;ingress\&quot; makes the target port accessible on on every node,   regardless of whether there is a task for the service running on   that node or not. - \&quot;host\&quot; bypasses the routing mesh and publish the port directly on   the swarm node where that service is running. 
   * @return publishMode
  **/
  @JsonProperty("PublishMode")
  public String getPublishMode() {
    if (publishMode == null) {
      return null;
    }
    return publishMode.value();
  }

  public void setPublishMode(PublishModeEnum publishMode) {
    this.publishMode = publishMode;
  }

  public EndpointPortConfig publishMode(PublishModeEnum publishMode) {
    this.publishMode = publishMode;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class EndpointPortConfig {\n");
    
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    protocol: ").append(toIndentedString(protocol)).append("\n");
    sb.append("    targetPort: ").append(toIndentedString(targetPort)).append("\n");
    sb.append("    publishedPort: ").append(toIndentedString(publishedPort)).append("\n");
    sb.append("    publishMode: ").append(toIndentedString(publishMode)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

