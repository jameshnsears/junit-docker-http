package io.swagger.model;

import io.swagger.annotations.ApiModel;
import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * Runtime describes an [OCI compliant](https://github.com/opencontainers/runtime-spec) runtime.  The runtime is invoked by the daemon via the `containerd` daemon. OCI runtimes act as an interface to the Linux kernel namespaces, cgroups, and SELinux. 
 **/
@ApiModel(description="Runtime describes an [OCI compliant](https://github.com/opencontainers/runtime-spec) runtime.  The runtime is invoked by the daemon via the `containerd` daemon. OCI runtimes act as an interface to the Linux kernel namespaces, cgroups, and SELinux. ")
public class Runtime  {
  
  @ApiModelProperty(example = "/usr/local/bin/my-oci-runtime", value = "Name and, optional, path, of the OCI executable binary.  If the path is omitted, the daemon searches the host's `$PATH` for the binary and uses the first result. ")
 /**
   * Name and, optional, path, of the OCI executable binary.  If the path is omitted, the daemon searches the host's `$PATH` for the binary and uses the first result.   
  **/
  private String path = null;

  @ApiModelProperty(example = "[\"--debug\",\"--systemd-cgroup=false\"]", value = "List of command-line arguments to pass to the runtime when invoked. ")
 /**
   * List of command-line arguments to pass to the runtime when invoked.   
  **/
  private List<String> runtimeArgs = null;
 /**
   * Name and, optional, path, of the OCI executable binary.  If the path is omitted, the daemon searches the host&#39;s &#x60;$PATH&#x60; for the binary and uses the first result. 
   * @return path
  **/
  @JsonProperty("path")
  public String getPath() {
    return path;
  }

  public void setPath(String path) {
    this.path = path;
  }

  public Runtime path(String path) {
    this.path = path;
    return this;
  }

 /**
   * List of command-line arguments to pass to the runtime when invoked. 
   * @return runtimeArgs
  **/
  @JsonProperty("runtimeArgs")
  public List<String> getRuntimeArgs() {
    return runtimeArgs;
  }

  public void setRuntimeArgs(List<String> runtimeArgs) {
    this.runtimeArgs = runtimeArgs;
  }

  public Runtime runtimeArgs(List<String> runtimeArgs) {
    this.runtimeArgs = runtimeArgs;
    return this;
  }

  public Runtime addRuntimeArgsItem(String runtimeArgsItem) {
    this.runtimeArgs.add(runtimeArgsItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Runtime {\n");
    
    sb.append("    path: ").append(toIndentedString(path)).append("\n");
    sb.append("    runtimeArgs: ").append(toIndentedString(runtimeArgs)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

