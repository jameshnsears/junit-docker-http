package io.swagger.model;

import io.swagger.annotations.ApiModel;
import io.swagger.model.SwarmSpecCAConfig;
import io.swagger.model.SwarmSpecDispatcher;
import io.swagger.model.SwarmSpecEncryptionConfig;
import io.swagger.model.SwarmSpecOrchestration;
import io.swagger.model.SwarmSpecRaft;
import io.swagger.model.SwarmSpecTaskDefaults;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * User modifiable swarm configuration.
 **/
@ApiModel(description="User modifiable swarm configuration.")
public class SwarmSpec  {
  
  @ApiModelProperty(example = "default", value = "Name of the swarm.")
 /**
   * Name of the swarm.  
  **/
  private String name = null;

  @ApiModelProperty(example = "{\"com.example.corp.type\":\"production\",\"com.example.corp.department\":\"engineering\"}", value = "User-defined key/value metadata.")
 /**
   * User-defined key/value metadata.  
  **/
  private Map<String, String> labels = null;

  @ApiModelProperty(value = "")
  private SwarmSpecOrchestration orchestration = null;

  @ApiModelProperty(value = "")
  private SwarmSpecRaft raft = null;

  @ApiModelProperty(value = "")
  private SwarmSpecDispatcher dispatcher = null;

  @ApiModelProperty(value = "")
  private SwarmSpecCAConfig caConfig = null;

  @ApiModelProperty(value = "")
  private SwarmSpecEncryptionConfig encryptionConfig = null;

  @ApiModelProperty(value = "")
  private SwarmSpecTaskDefaults taskDefaults = null;
 /**
   * Name of the swarm.
   * @return name
  **/
  @JsonProperty("Name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public SwarmSpec name(String name) {
    this.name = name;
    return this;
  }

 /**
   * User-defined key/value metadata.
   * @return labels
  **/
  @JsonProperty("Labels")
  public Map<String, String> getLabels() {
    return labels;
  }

  public void setLabels(Map<String, String> labels) {
    this.labels = labels;
  }

  public SwarmSpec labels(Map<String, String> labels) {
    this.labels = labels;
    return this;
  }

  public SwarmSpec putLabelsItem(String key, String labelsItem) {
    this.labels.put(key, labelsItem);
    return this;
  }

 /**
   * Get orchestration
   * @return orchestration
  **/
  @JsonProperty("Orchestration")
  public SwarmSpecOrchestration getOrchestration() {
    return orchestration;
  }

  public void setOrchestration(SwarmSpecOrchestration orchestration) {
    this.orchestration = orchestration;
  }

  public SwarmSpec orchestration(SwarmSpecOrchestration orchestration) {
    this.orchestration = orchestration;
    return this;
  }

 /**
   * Get raft
   * @return raft
  **/
  @JsonProperty("Raft")
  public SwarmSpecRaft getRaft() {
    return raft;
  }

  public void setRaft(SwarmSpecRaft raft) {
    this.raft = raft;
  }

  public SwarmSpec raft(SwarmSpecRaft raft) {
    this.raft = raft;
    return this;
  }

 /**
   * Get dispatcher
   * @return dispatcher
  **/
  @JsonProperty("Dispatcher")
  public SwarmSpecDispatcher getDispatcher() {
    return dispatcher;
  }

  public void setDispatcher(SwarmSpecDispatcher dispatcher) {
    this.dispatcher = dispatcher;
  }

  public SwarmSpec dispatcher(SwarmSpecDispatcher dispatcher) {
    this.dispatcher = dispatcher;
    return this;
  }

 /**
   * Get caConfig
   * @return caConfig
  **/
  @JsonProperty("CAConfig")
  public SwarmSpecCAConfig getCaConfig() {
    return caConfig;
  }

  public void setCaConfig(SwarmSpecCAConfig caConfig) {
    this.caConfig = caConfig;
  }

  public SwarmSpec caConfig(SwarmSpecCAConfig caConfig) {
    this.caConfig = caConfig;
    return this;
  }

 /**
   * Get encryptionConfig
   * @return encryptionConfig
  **/
  @JsonProperty("EncryptionConfig")
  public SwarmSpecEncryptionConfig getEncryptionConfig() {
    return encryptionConfig;
  }

  public void setEncryptionConfig(SwarmSpecEncryptionConfig encryptionConfig) {
    this.encryptionConfig = encryptionConfig;
  }

  public SwarmSpec encryptionConfig(SwarmSpecEncryptionConfig encryptionConfig) {
    this.encryptionConfig = encryptionConfig;
    return this;
  }

 /**
   * Get taskDefaults
   * @return taskDefaults
  **/
  @JsonProperty("TaskDefaults")
  public SwarmSpecTaskDefaults getTaskDefaults() {
    return taskDefaults;
  }

  public void setTaskDefaults(SwarmSpecTaskDefaults taskDefaults) {
    this.taskDefaults = taskDefaults;
  }

  public SwarmSpec taskDefaults(SwarmSpecTaskDefaults taskDefaults) {
    this.taskDefaults = taskDefaults;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SwarmSpec {\n");
    
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    labels: ").append(toIndentedString(labels)).append("\n");
    sb.append("    orchestration: ").append(toIndentedString(orchestration)).append("\n");
    sb.append("    raft: ").append(toIndentedString(raft)).append("\n");
    sb.append("    dispatcher: ").append(toIndentedString(dispatcher)).append("\n");
    sb.append("    caConfig: ").append(toIndentedString(caConfig)).append("\n");
    sb.append("    encryptionConfig: ").append(toIndentedString(encryptionConfig)).append("\n");
    sb.append("    taskDefaults: ").append(toIndentedString(taskDefaults)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

