package io.swagger.model;

import io.swagger.annotations.ApiModel;
import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * A test to perform to check that the container is healthy.
 **/
@ApiModel(description="A test to perform to check that the container is healthy.")
public class HealthConfig  {
  
  @ApiModelProperty(value = "The test to perform. Possible values are:  - `[]` inherit healthcheck from image or parent image - `[\"NONE\"]` disable healthcheck - `[\"CMD\", args...]` exec arguments directly - `[\"CMD-SHELL\", command]` run command with system's default shell ")
 /**
   * The test to perform. Possible values are:  - `[]` inherit healthcheck from image or parent image - `[\"NONE\"]` disable healthcheck - `[\"CMD\", args...]` exec arguments directly - `[\"CMD-SHELL\", command]` run command with system's default shell   
  **/
  private List<String> test = null;

  @ApiModelProperty(value = "The time to wait between checks in nanoseconds. It should be 0 or at least 1000000 (1 ms). 0 means inherit.")
 /**
   * The time to wait between checks in nanoseconds. It should be 0 or at least 1000000 (1 ms). 0 means inherit.  
  **/
  private Integer interval = null;

  @ApiModelProperty(value = "The time to wait before considering the check to have hung. It should be 0 or at least 1000000 (1 ms). 0 means inherit.")
 /**
   * The time to wait before considering the check to have hung. It should be 0 or at least 1000000 (1 ms). 0 means inherit.  
  **/
  private Integer timeout = null;

  @ApiModelProperty(value = "The number of consecutive failures needed to consider a container as unhealthy. 0 means inherit.")
 /**
   * The number of consecutive failures needed to consider a container as unhealthy. 0 means inherit.  
  **/
  private Integer retries = null;

  @ApiModelProperty(value = "Start period for the container to initialize before starting health-retries countdown in nanoseconds. It should be 0 or at least 1000000 (1 ms). 0 means inherit.")
 /**
   * Start period for the container to initialize before starting health-retries countdown in nanoseconds. It should be 0 or at least 1000000 (1 ms). 0 means inherit.  
  **/
  private Integer startPeriod = null;
 /**
   * The test to perform. Possible values are:  - &#x60;[]&#x60; inherit healthcheck from image or parent image - &#x60;[\&quot;NONE\&quot;]&#x60; disable healthcheck - &#x60;[\&quot;CMD\&quot;, args...]&#x60; exec arguments directly - &#x60;[\&quot;CMD-SHELL\&quot;, command]&#x60; run command with system&#39;s default shell 
   * @return test
  **/
  @JsonProperty("Test")
  public List<String> getTest() {
    return test;
  }

  public void setTest(List<String> test) {
    this.test = test;
  }

  public HealthConfig test(List<String> test) {
    this.test = test;
    return this;
  }

  public HealthConfig addTestItem(String testItem) {
    this.test.add(testItem);
    return this;
  }

 /**
   * The time to wait between checks in nanoseconds. It should be 0 or at least 1000000 (1 ms). 0 means inherit.
   * @return interval
  **/
  @JsonProperty("Interval")
  public Integer getInterval() {
    return interval;
  }

  public void setInterval(Integer interval) {
    this.interval = interval;
  }

  public HealthConfig interval(Integer interval) {
    this.interval = interval;
    return this;
  }

 /**
   * The time to wait before considering the check to have hung. It should be 0 or at least 1000000 (1 ms). 0 means inherit.
   * @return timeout
  **/
  @JsonProperty("Timeout")
  public Integer getTimeout() {
    return timeout;
  }

  public void setTimeout(Integer timeout) {
    this.timeout = timeout;
  }

  public HealthConfig timeout(Integer timeout) {
    this.timeout = timeout;
    return this;
  }

 /**
   * The number of consecutive failures needed to consider a container as unhealthy. 0 means inherit.
   * @return retries
  **/
  @JsonProperty("Retries")
  public Integer getRetries() {
    return retries;
  }

  public void setRetries(Integer retries) {
    this.retries = retries;
  }

  public HealthConfig retries(Integer retries) {
    this.retries = retries;
    return this;
  }

 /**
   * Start period for the container to initialize before starting health-retries countdown in nanoseconds. It should be 0 or at least 1000000 (1 ms). 0 means inherit.
   * @return startPeriod
  **/
  @JsonProperty("StartPeriod")
  public Integer getStartPeriod() {
    return startPeriod;
  }

  public void setStartPeriod(Integer startPeriod) {
    this.startPeriod = startPeriod;
  }

  public HealthConfig startPeriod(Integer startPeriod) {
    this.startPeriod = startPeriod;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class HealthConfig {\n");
    
    sb.append("    test: ").append(toIndentedString(test)).append("\n");
    sb.append("    interval: ").append(toIndentedString(interval)).append("\n");
    sb.append("    timeout: ").append(toIndentedString(timeout)).append("\n");
    sb.append("    retries: ").append(toIndentedString(retries)).append("\n");
    sb.append("    startPeriod: ").append(toIndentedString(startPeriod)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

