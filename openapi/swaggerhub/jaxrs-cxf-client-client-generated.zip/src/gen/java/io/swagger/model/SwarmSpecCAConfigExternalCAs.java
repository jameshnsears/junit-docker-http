package io.swagger.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class SwarmSpecCAConfigExternalCAs  {
  

@XmlType(name="ProtocolEnum")
@XmlEnum(String.class)
public enum ProtocolEnum {

@XmlEnumValue("cfssl") CFSSL(String.valueOf("cfssl"));


    private String value;

    ProtocolEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static ProtocolEnum fromValue(String v) {
        for (ProtocolEnum b : ProtocolEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(value = "Protocol for communication with the external CA (currently only `cfssl` is supported).")
 /**
   * Protocol for communication with the external CA (currently only `cfssl` is supported).  
  **/
  private ProtocolEnum protocol = ProtocolEnum.CFSSL;

  @ApiModelProperty(value = "URL where certificate signing requests should be sent.")
 /**
   * URL where certificate signing requests should be sent.  
  **/
  private String URL = null;

  @ApiModelProperty(value = "An object with key/value pairs that are interpreted as protocol-specific options for the external CA driver.")
 /**
   * An object with key/value pairs that are interpreted as protocol-specific options for the external CA driver.  
  **/
  private Map<String, String> options = null;

  @ApiModelProperty(value = "The root CA certificate (in PEM format) this external CA uses to issue TLS certificates (assumed to be to the current swarm root CA certificate if not provided).")
 /**
   * The root CA certificate (in PEM format) this external CA uses to issue TLS certificates (assumed to be to the current swarm root CA certificate if not provided).  
  **/
  private String caCert = null;
 /**
   * Protocol for communication with the external CA (currently only &#x60;cfssl&#x60; is supported).
   * @return protocol
  **/
  @JsonProperty("Protocol")
  public String getProtocol() {
    if (protocol == null) {
      return null;
    }
    return protocol.value();
  }

  public void setProtocol(ProtocolEnum protocol) {
    this.protocol = protocol;
  }

  public SwarmSpecCAConfigExternalCAs protocol(ProtocolEnum protocol) {
    this.protocol = protocol;
    return this;
  }

 /**
   * URL where certificate signing requests should be sent.
   * @return URL
  **/
  @JsonProperty("URL")
  public String getURL() {
    return URL;
  }

  public void setURL(String URL) {
    this.URL = URL;
  }

  public SwarmSpecCAConfigExternalCAs URL(String URL) {
    this.URL = URL;
    return this;
  }

 /**
   * An object with key/value pairs that are interpreted as protocol-specific options for the external CA driver.
   * @return options
  **/
  @JsonProperty("Options")
  public Map<String, String> getOptions() {
    return options;
  }

  public void setOptions(Map<String, String> options) {
    this.options = options;
  }

  public SwarmSpecCAConfigExternalCAs options(Map<String, String> options) {
    this.options = options;
    return this;
  }

  public SwarmSpecCAConfigExternalCAs putOptionsItem(String key, String optionsItem) {
    this.options.put(key, optionsItem);
    return this;
  }

 /**
   * The root CA certificate (in PEM format) this external CA uses to issue TLS certificates (assumed to be to the current swarm root CA certificate if not provided).
   * @return caCert
  **/
  @JsonProperty("CACert")
  public String getCaCert() {
    return caCert;
  }

  public void setCaCert(String caCert) {
    this.caCert = caCert;
  }

  public SwarmSpecCAConfigExternalCAs caCert(String caCert) {
    this.caCert = caCert;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SwarmSpecCAConfigExternalCAs {\n");
    
    sb.append("    protocol: ").append(toIndentedString(protocol)).append("\n");
    sb.append("    URL: ").append(toIndentedString(URL)).append("\n");
    sb.append("    options: ").append(toIndentedString(options)).append("\n");
    sb.append("    caCert: ").append(toIndentedString(caCert)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

