package io.swagger.model;


import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ResourcesUlimits  {
  
  @ApiModelProperty(value = "Name of ulimit")
 /**
   * Name of ulimit  
  **/
  private String name = null;

  @ApiModelProperty(value = "Soft limit")
 /**
   * Soft limit  
  **/
  private Integer soft = null;

  @ApiModelProperty(value = "Hard limit")
 /**
   * Hard limit  
  **/
  private Integer hard = null;
 /**
   * Name of ulimit
   * @return name
  **/
  @JsonProperty("Name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public ResourcesUlimits name(String name) {
    this.name = name;
    return this;
  }

 /**
   * Soft limit
   * @return soft
  **/
  @JsonProperty("Soft")
  public Integer getSoft() {
    return soft;
  }

  public void setSoft(Integer soft) {
    this.soft = soft;
  }

  public ResourcesUlimits soft(Integer soft) {
    this.soft = soft;
    return this;
  }

 /**
   * Hard limit
   * @return hard
  **/
  @JsonProperty("Hard")
  public Integer getHard() {
    return hard;
  }

  public void setHard(Integer hard) {
    this.hard = hard;
  }

  public ResourcesUlimits hard(Integer hard) {
    this.hard = hard;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ResourcesUlimits {\n");
    
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    soft: ").append(toIndentedString(soft)).append("\n");
    sb.append("    hard: ").append(toIndentedString(hard)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

