package io.swagger.model;

import io.swagger.annotations.ApiModel;
import io.swagger.model.ClusterInfo;
import io.swagger.model.LocalNodeState;
import io.swagger.model.PeerNode;
import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * Represents generic information about swarm. 
 **/
@ApiModel(description="Represents generic information about swarm. ")
public class SwarmInfo  {
  
  @ApiModelProperty(example = "k67qz4598weg5unwwffg6z1m1", value = "Unique identifier of for this node in the swarm.")
 /**
   * Unique identifier of for this node in the swarm.  
  **/
  private String nodeID = "";

  @ApiModelProperty(example = "10.0.0.46", value = "IP address at which this node can be reached by other nodes in the swarm. ")
 /**
   * IP address at which this node can be reached by other nodes in the swarm.   
  **/
  private String nodeAddr = "";

  @ApiModelProperty(value = "")
  private LocalNodeState localNodeState = null;

  @ApiModelProperty(example = "true", value = "")
  private Boolean controlAvailable = false;

  @ApiModelProperty(value = "")
  private String error = "";

  @ApiModelProperty(example = "[{\"NodeID\":\"71izy0goik036k48jg985xnds\",\"Addr\":\"10.0.0.158:2377\"},{\"NodeID\":\"79y6h1o4gv8n120drcprv5nmc\",\"Addr\":\"10.0.0.159:2377\"},{\"NodeID\":\"k67qz4598weg5unwwffg6z1m1\",\"Addr\":\"10.0.0.46:2377\"}]", value = "List of ID's and addresses of other managers in the swarm. ")
 /**
   * List of ID's and addresses of other managers in the swarm.   
  **/
  private List<PeerNode> remoteManagers = null;

  @ApiModelProperty(example = "4", value = "Total number of nodes in the swarm.")
 /**
   * Total number of nodes in the swarm.  
  **/
  private Integer nodes = null;

  @ApiModelProperty(example = "3", value = "Total number of managers in the swarm.")
 /**
   * Total number of managers in the swarm.  
  **/
  private Integer managers = null;

  @ApiModelProperty(value = "")
  private ClusterInfo cluster = null;
 /**
   * Unique identifier of for this node in the swarm.
   * @return nodeID
  **/
  @JsonProperty("NodeID")
  public String getNodeID() {
    return nodeID;
  }

  public void setNodeID(String nodeID) {
    this.nodeID = nodeID;
  }

  public SwarmInfo nodeID(String nodeID) {
    this.nodeID = nodeID;
    return this;
  }

 /**
   * IP address at which this node can be reached by other nodes in the swarm. 
   * @return nodeAddr
  **/
  @JsonProperty("NodeAddr")
  public String getNodeAddr() {
    return nodeAddr;
  }

  public void setNodeAddr(String nodeAddr) {
    this.nodeAddr = nodeAddr;
  }

  public SwarmInfo nodeAddr(String nodeAddr) {
    this.nodeAddr = nodeAddr;
    return this;
  }

 /**
   * Get localNodeState
   * @return localNodeState
  **/
  @JsonProperty("LocalNodeState")
  public LocalNodeState getLocalNodeState() {
    return localNodeState;
  }

  public void setLocalNodeState(LocalNodeState localNodeState) {
    this.localNodeState = localNodeState;
  }

  public SwarmInfo localNodeState(LocalNodeState localNodeState) {
    this.localNodeState = localNodeState;
    return this;
  }

 /**
   * Get controlAvailable
   * @return controlAvailable
  **/
  @JsonProperty("ControlAvailable")
  public Boolean isControlAvailable() {
    return controlAvailable;
  }

  public void setControlAvailable(Boolean controlAvailable) {
    this.controlAvailable = controlAvailable;
  }

  public SwarmInfo controlAvailable(Boolean controlAvailable) {
    this.controlAvailable = controlAvailable;
    return this;
  }

 /**
   * Get error
   * @return error
  **/
  @JsonProperty("Error")
  public String getError() {
    return error;
  }

  public void setError(String error) {
    this.error = error;
  }

  public SwarmInfo error(String error) {
    this.error = error;
    return this;
  }

 /**
   * List of ID&#39;s and addresses of other managers in the swarm. 
   * @return remoteManagers
  **/
  @JsonProperty("RemoteManagers")
  public List<PeerNode> getRemoteManagers() {
    return remoteManagers;
  }

  public void setRemoteManagers(List<PeerNode> remoteManagers) {
    this.remoteManagers = remoteManagers;
  }

  public SwarmInfo remoteManagers(List<PeerNode> remoteManagers) {
    this.remoteManagers = remoteManagers;
    return this;
  }

  public SwarmInfo addRemoteManagersItem(PeerNode remoteManagersItem) {
    this.remoteManagers.add(remoteManagersItem);
    return this;
  }

 /**
   * Total number of nodes in the swarm.
   * @return nodes
  **/
  @JsonProperty("Nodes")
  public Integer getNodes() {
    return nodes;
  }

  public void setNodes(Integer nodes) {
    this.nodes = nodes;
  }

  public SwarmInfo nodes(Integer nodes) {
    this.nodes = nodes;
    return this;
  }

 /**
   * Total number of managers in the swarm.
   * @return managers
  **/
  @JsonProperty("Managers")
  public Integer getManagers() {
    return managers;
  }

  public void setManagers(Integer managers) {
    this.managers = managers;
  }

  public SwarmInfo managers(Integer managers) {
    this.managers = managers;
    return this;
  }

 /**
   * Get cluster
   * @return cluster
  **/
  @JsonProperty("Cluster")
  public ClusterInfo getCluster() {
    return cluster;
  }

  public void setCluster(ClusterInfo cluster) {
    this.cluster = cluster;
  }

  public SwarmInfo cluster(ClusterInfo cluster) {
    this.cluster = cluster;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SwarmInfo {\n");
    
    sb.append("    nodeID: ").append(toIndentedString(nodeID)).append("\n");
    sb.append("    nodeAddr: ").append(toIndentedString(nodeAddr)).append("\n");
    sb.append("    localNodeState: ").append(toIndentedString(localNodeState)).append("\n");
    sb.append("    controlAvailable: ").append(toIndentedString(controlAvailable)).append("\n");
    sb.append("    error: ").append(toIndentedString(error)).append("\n");
    sb.append("    remoteManagers: ").append(toIndentedString(remoteManagers)).append("\n");
    sb.append("    nodes: ").append(toIndentedString(nodes)).append("\n");
    sb.append("    managers: ").append(toIndentedString(managers)).append("\n");
    sb.append("    cluster: ").append(toIndentedString(cluster)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

