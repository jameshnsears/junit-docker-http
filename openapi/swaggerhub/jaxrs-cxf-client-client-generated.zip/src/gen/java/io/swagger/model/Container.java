package io.swagger.model;

import io.swagger.model.EndpointSettings;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Container  {
  
  @ApiModelProperty(value = "The ID or name of the container to connect to the network.")
 /**
   * The ID or name of the container to connect to the network.  
  **/
  private String container = null;

  @ApiModelProperty(value = "")
  private EndpointSettings endpointConfig = null;
 /**
   * The ID or name of the container to connect to the network.
   * @return container
  **/
  @JsonProperty("Container")
  public String getContainer() {
    return container;
  }

  public void setContainer(String container) {
    this.container = container;
  }

  public Container container(String container) {
    this.container = container;
    return this;
  }

 /**
   * Get endpointConfig
   * @return endpointConfig
  **/
  @JsonProperty("EndpointConfig")
  public EndpointSettings getEndpointConfig() {
    return endpointConfig;
  }

  public void setEndpointConfig(EndpointSettings endpointConfig) {
    this.endpointConfig = endpointConfig;
  }

  public Container endpointConfig(EndpointSettings endpointConfig) {
    this.endpointConfig = endpointConfig;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Container {\n");
    
    sb.append("    container: ").append(toIndentedString(container)).append("\n");
    sb.append("    endpointConfig: ").append(toIndentedString(endpointConfig)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

