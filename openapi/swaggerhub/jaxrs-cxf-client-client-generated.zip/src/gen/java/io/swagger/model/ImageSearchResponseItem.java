package io.swagger.model;


import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ImageSearchResponseItem  {
  
  @ApiModelProperty(value = "")
  private String description = null;

  @ApiModelProperty(value = "")
  private Boolean isOfficial = null;

  @ApiModelProperty(value = "")
  private Boolean isAutomated = null;

  @ApiModelProperty(value = "")
  private String name = null;

  @ApiModelProperty(value = "")
  private Integer starCount = null;
 /**
   * Get description
   * @return description
  **/
  @JsonProperty("description")
  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public ImageSearchResponseItem description(String description) {
    this.description = description;
    return this;
  }

 /**
   * Get isOfficial
   * @return isOfficial
  **/
  @JsonProperty("is_official")
  public Boolean isIsOfficial() {
    return isOfficial;
  }

  public void setIsOfficial(Boolean isOfficial) {
    this.isOfficial = isOfficial;
  }

  public ImageSearchResponseItem isOfficial(Boolean isOfficial) {
    this.isOfficial = isOfficial;
    return this;
  }

 /**
   * Get isAutomated
   * @return isAutomated
  **/
  @JsonProperty("is_automated")
  public Boolean isIsAutomated() {
    return isAutomated;
  }

  public void setIsAutomated(Boolean isAutomated) {
    this.isAutomated = isAutomated;
  }

  public ImageSearchResponseItem isAutomated(Boolean isAutomated) {
    this.isAutomated = isAutomated;
    return this;
  }

 /**
   * Get name
   * @return name
  **/
  @JsonProperty("name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public ImageSearchResponseItem name(String name) {
    this.name = name;
    return this;
  }

 /**
   * Get starCount
   * @return starCount
  **/
  @JsonProperty("star_count")
  public Integer getStarCount() {
    return starCount;
  }

  public void setStarCount(Integer starCount) {
    this.starCount = starCount;
  }

  public ImageSearchResponseItem starCount(Integer starCount) {
    this.starCount = starCount;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ImageSearchResponseItem {\n");
    
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("    isOfficial: ").append(toIndentedString(isOfficial)).append("\n");
    sb.append("    isAutomated: ").append(toIndentedString(isAutomated)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    starCount: ").append(toIndentedString(starCount)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

