package io.swagger.model;

import io.swagger.annotations.ApiModel;
import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * Specification for DNS related configurations in resolver configuration file (`resolv.conf`).
 **/
@ApiModel(description="Specification for DNS related configurations in resolver configuration file (`resolv.conf`).")
public class TaskSpecContainerSpecDNSConfig  {
  
  @ApiModelProperty(value = "The IP addresses of the name servers.")
 /**
   * The IP addresses of the name servers.  
  **/
  private List<String> nameservers = null;

  @ApiModelProperty(value = "A search list for host-name lookup.")
 /**
   * A search list for host-name lookup.  
  **/
  private List<String> search = null;

  @ApiModelProperty(value = "A list of internal resolver variables to be modified (e.g., `debug`, `ndots:3`, etc.).")
 /**
   * A list of internal resolver variables to be modified (e.g., `debug`, `ndots:3`, etc.).  
  **/
  private List<String> options = null;
 /**
   * The IP addresses of the name servers.
   * @return nameservers
  **/
  @JsonProperty("Nameservers")
  public List<String> getNameservers() {
    return nameservers;
  }

  public void setNameservers(List<String> nameservers) {
    this.nameservers = nameservers;
  }

  public TaskSpecContainerSpecDNSConfig nameservers(List<String> nameservers) {
    this.nameservers = nameservers;
    return this;
  }

  public TaskSpecContainerSpecDNSConfig addNameserversItem(String nameserversItem) {
    this.nameservers.add(nameserversItem);
    return this;
  }

 /**
   * A search list for host-name lookup.
   * @return search
  **/
  @JsonProperty("Search")
  public List<String> getSearch() {
    return search;
  }

  public void setSearch(List<String> search) {
    this.search = search;
  }

  public TaskSpecContainerSpecDNSConfig search(List<String> search) {
    this.search = search;
    return this;
  }

  public TaskSpecContainerSpecDNSConfig addSearchItem(String searchItem) {
    this.search.add(searchItem);
    return this;
  }

 /**
   * A list of internal resolver variables to be modified (e.g., &#x60;debug&#x60;, &#x60;ndots:3&#x60;, etc.).
   * @return options
  **/
  @JsonProperty("Options")
  public List<String> getOptions() {
    return options;
  }

  public void setOptions(List<String> options) {
    this.options = options;
  }

  public TaskSpecContainerSpecDNSConfig options(List<String> options) {
    this.options = options;
    return this;
  }

  public TaskSpecContainerSpecDNSConfig addOptionsItem(String optionsItem) {
    this.options.add(optionsItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TaskSpecContainerSpecDNSConfig {\n");
    
    sb.append("    nameservers: ").append(toIndentedString(nameservers)).append("\n");
    sb.append("    search: ").append(toIndentedString(search)).append("\n");
    sb.append("    options: ").append(toIndentedString(options)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

