package io.swagger.model;


import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class NetworkContainer  {
  
  @ApiModelProperty(value = "")
  private String name = null;

  @ApiModelProperty(value = "")
  private String endpointID = null;

  @ApiModelProperty(value = "")
  private String macAddress = null;

  @ApiModelProperty(value = "")
  private String ipv4Address = null;

  @ApiModelProperty(value = "")
  private String ipv6Address = null;
 /**
   * Get name
   * @return name
  **/
  @JsonProperty("Name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public NetworkContainer name(String name) {
    this.name = name;
    return this;
  }

 /**
   * Get endpointID
   * @return endpointID
  **/
  @JsonProperty("EndpointID")
  public String getEndpointID() {
    return endpointID;
  }

  public void setEndpointID(String endpointID) {
    this.endpointID = endpointID;
  }

  public NetworkContainer endpointID(String endpointID) {
    this.endpointID = endpointID;
    return this;
  }

 /**
   * Get macAddress
   * @return macAddress
  **/
  @JsonProperty("MacAddress")
  public String getMacAddress() {
    return macAddress;
  }

  public void setMacAddress(String macAddress) {
    this.macAddress = macAddress;
  }

  public NetworkContainer macAddress(String macAddress) {
    this.macAddress = macAddress;
    return this;
  }

 /**
   * Get ipv4Address
   * @return ipv4Address
  **/
  @JsonProperty("IPv4Address")
  public String getIpv4Address() {
    return ipv4Address;
  }

  public void setIpv4Address(String ipv4Address) {
    this.ipv4Address = ipv4Address;
  }

  public NetworkContainer ipv4Address(String ipv4Address) {
    this.ipv4Address = ipv4Address;
    return this;
  }

 /**
   * Get ipv6Address
   * @return ipv6Address
  **/
  @JsonProperty("IPv6Address")
  public String getIpv6Address() {
    return ipv6Address;
  }

  public void setIpv6Address(String ipv6Address) {
    this.ipv6Address = ipv6Address;
  }

  public NetworkContainer ipv6Address(String ipv6Address) {
    this.ipv6Address = ipv6Address;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class NetworkContainer {\n");
    
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    endpointID: ").append(toIndentedString(endpointID)).append("\n");
    sb.append("    macAddress: ").append(toIndentedString(macAddress)).append("\n");
    sb.append("    ipv4Address: ").append(toIndentedString(ipv4Address)).append("\n");
    sb.append("    ipv6Address: ").append(toIndentedString(ipv6Address)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

