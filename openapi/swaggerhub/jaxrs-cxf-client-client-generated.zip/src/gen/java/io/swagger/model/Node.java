package io.swagger.model;

import io.swagger.model.ManagerStatus;
import io.swagger.model.NodeDescription;
import io.swagger.model.NodeSpec;
import io.swagger.model.NodeStatus;
import io.swagger.model.ObjectVersion;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Node  {
  
  @ApiModelProperty(example = "24ifsmvkjbyhk", value = "")
  private String ID = null;

  @ApiModelProperty(value = "")
  private ObjectVersion version = null;

  @ApiModelProperty(example = "2016-08-18T10:44:24.496525531Z", value = "Date and time at which the node was added to the swarm in [RFC 3339](https://www.ietf.org/rfc/rfc3339.txt) format with nano-seconds. ")
 /**
   * Date and time at which the node was added to the swarm in [RFC 3339](https://www.ietf.org/rfc/rfc3339.txt) format with nano-seconds.   
  **/
  private String createdAt = null;

  @ApiModelProperty(example = "2017-08-09T07:09:37.632105588Z", value = "Date and time at which the node was last updated in [RFC 3339](https://www.ietf.org/rfc/rfc3339.txt) format with nano-seconds. ")
 /**
   * Date and time at which the node was last updated in [RFC 3339](https://www.ietf.org/rfc/rfc3339.txt) format with nano-seconds.   
  **/
  private String updatedAt = null;

  @ApiModelProperty(value = "")
  private NodeSpec spec = null;

  @ApiModelProperty(value = "")
  private NodeDescription description = null;

  @ApiModelProperty(value = "")
  private NodeStatus status = null;

  @ApiModelProperty(value = "")
  private ManagerStatus managerStatus = null;
 /**
   * Get ID
   * @return ID
  **/
  @JsonProperty("ID")
  public String getID() {
    return ID;
  }

  public void setID(String ID) {
    this.ID = ID;
  }

  public Node ID(String ID) {
    this.ID = ID;
    return this;
  }

 /**
   * Get version
   * @return version
  **/
  @JsonProperty("Version")
  public ObjectVersion getVersion() {
    return version;
  }

  public void setVersion(ObjectVersion version) {
    this.version = version;
  }

  public Node version(ObjectVersion version) {
    this.version = version;
    return this;
  }

 /**
   * Date and time at which the node was added to the swarm in [RFC 3339](https://www.ietf.org/rfc/rfc3339.txt) format with nano-seconds. 
   * @return createdAt
  **/
  @JsonProperty("CreatedAt")
  public String getCreatedAt() {
    return createdAt;
  }

  public void setCreatedAt(String createdAt) {
    this.createdAt = createdAt;
  }

  public Node createdAt(String createdAt) {
    this.createdAt = createdAt;
    return this;
  }

 /**
   * Date and time at which the node was last updated in [RFC 3339](https://www.ietf.org/rfc/rfc3339.txt) format with nano-seconds. 
   * @return updatedAt
  **/
  @JsonProperty("UpdatedAt")
  public String getUpdatedAt() {
    return updatedAt;
  }

  public void setUpdatedAt(String updatedAt) {
    this.updatedAt = updatedAt;
  }

  public Node updatedAt(String updatedAt) {
    this.updatedAt = updatedAt;
    return this;
  }

 /**
   * Get spec
   * @return spec
  **/
  @JsonProperty("Spec")
  public NodeSpec getSpec() {
    return spec;
  }

  public void setSpec(NodeSpec spec) {
    this.spec = spec;
  }

  public Node spec(NodeSpec spec) {
    this.spec = spec;
    return this;
  }

 /**
   * Get description
   * @return description
  **/
  @JsonProperty("Description")
  public NodeDescription getDescription() {
    return description;
  }

  public void setDescription(NodeDescription description) {
    this.description = description;
  }

  public Node description(NodeDescription description) {
    this.description = description;
    return this;
  }

 /**
   * Get status
   * @return status
  **/
  @JsonProperty("Status")
  public NodeStatus getStatus() {
    return status;
  }

  public void setStatus(NodeStatus status) {
    this.status = status;
  }

  public Node status(NodeStatus status) {
    this.status = status;
    return this;
  }

 /**
   * Get managerStatus
   * @return managerStatus
  **/
  @JsonProperty("ManagerStatus")
  public ManagerStatus getManagerStatus() {
    return managerStatus;
  }

  public void setManagerStatus(ManagerStatus managerStatus) {
    this.managerStatus = managerStatus;
  }

  public Node managerStatus(ManagerStatus managerStatus) {
    this.managerStatus = managerStatus;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Node {\n");
    
    sb.append("    ID: ").append(toIndentedString(ID)).append("\n");
    sb.append("    version: ").append(toIndentedString(version)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("    spec: ").append(toIndentedString(spec)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    managerStatus: ").append(toIndentedString(managerStatus)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

