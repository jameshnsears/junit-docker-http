package io.swagger.api;

import io.swagger.model.AuthConfig;
import io.swagger.model.ErrorResponse;
import io.swagger.model.SystemAuthResponse;
import io.swagger.model.SystemDataUsageResponse;
import io.swagger.model.SystemEventsResponse;
import io.swagger.model.SystemInfo;
import io.swagger.model.SystemVersionResponse;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import org.apache.cxf.jaxrs.ext.multipart.*;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.ApiResponse;
import io.swagger.jaxrs.PATCH;

/**
 * Docker Engine API
 *
 * <p>The Engine API is an HTTP API served by Docker Engine. It is the API the Docker client uses to communicate with the Engine, so everything the Docker client can do can be done with the API.  Most of the client's commands map directly to API endpoints (e.g. `docker ps` is `GET /containers/json`). The notable exception is running containers, which consists of several API calls.  # Errors  The API uses standard HTTP status codes to indicate the success or failure of the API call. The body of the response will be JSON in the following format:  ``` {   \"message\": \"page not found\" } ```  # Versioning  The API is usually changed in each release, so API calls are versioned to ensure that clients don't break. To lock to a specific version of the API, you prefix the URL with its version, for example, call `/v1.30/info` to use the v1.30 version of the `/info` endpoint. If the API version specified in the URL is not supported by the daemon, a HTTP `400 Bad Request` error message is returned.  If you omit the version-prefix, the current version of the API (v1.39) is used. For example, calling `/info` is the same as calling `/v1.39/info`. Using the API without a version-prefix is deprecated and will be removed in a future release.  Engine releases in the near future should support this version of the API, so your client will continue to work even if it is talking to a newer Engine.  The API uses an open schema model, which means server may add extra properties to responses. Likewise, the server will ignore any extra query parameters and request body properties. When you write clients, you need to ignore additional properties in responses to ensure they do not break when talking to newer daemons.   # Authentication  Authentication for registries is handled client side. The client has to send authentication details to various endpoints that need to communicate with registries, such as `POST /images/(name)/push`. These are sent as `X-Registry-Auth` header as a Base64 encoded (JSON) string with the following structure:  ``` {   \"username\": \"string\",   \"password\": \"string\",   \"email\": \"string\",   \"serveraddress\": \"string\" } ```  The `serveraddress` is a domain/IP without a protocol. Throughout this structure, double quotes are required.  If you have already got an identity token from the [`/auth` endpoint](#operation/SystemAuth), you can just pass this instead of credentials:  ``` {   \"identitytoken\": \"9cbaf023786cd7...\" } ``` 
 *
 */
@Path("/")
@Api(value = "/", description = "")
public interface SystemApi  {

    /**
     * Check auth configuration
     *
     * Validate credentials for a registry and, if available, get an identity token for accessing the registry without password.
     *
     */
    @POST
    @Path("/auth")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Check auth configuration", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "An identity token was generated successfully.", response = SystemAuthResponse.class),
        @ApiResponse(code = 204, message = "No error", response = .class),
        @ApiResponse(code = 500, message = "Server error", response = ErrorResponse.class) })
    public SystemAuthResponse systemAuth(AuthConfig authConfig);

    /**
     * Get data usage information
     *
     */
    @GET
    @Path("/system/df")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json", "text/plain" })
    @ApiOperation(value = "Get data usage information", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "no error", response = SystemDataUsageResponse.class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public SystemDataUsageResponse systemDataUsage();

    /**
     * Monitor events
     *
     * Stream real-time events from the server.  Various objects within Docker report events when something happens to them.  Containers report these events: &#x60;attach&#x60;, &#x60;commit&#x60;, &#x60;copy&#x60;, &#x60;create&#x60;, &#x60;destroy&#x60;, &#x60;detach&#x60;, &#x60;die&#x60;, &#x60;exec_create&#x60;, &#x60;exec_detach&#x60;, &#x60;exec_start&#x60;, &#x60;exec_die&#x60;, &#x60;export&#x60;, &#x60;health_status&#x60;, &#x60;kill&#x60;, &#x60;oom&#x60;, &#x60;pause&#x60;, &#x60;rename&#x60;, &#x60;resize&#x60;, &#x60;restart&#x60;, &#x60;start&#x60;, &#x60;stop&#x60;, &#x60;top&#x60;, &#x60;unpause&#x60;, and &#x60;update&#x60;  Images report these events: &#x60;delete&#x60;, &#x60;import&#x60;, &#x60;load&#x60;, &#x60;pull&#x60;, &#x60;push&#x60;, &#x60;save&#x60;, &#x60;tag&#x60;, and &#x60;untag&#x60;  Volumes report these events: &#x60;create&#x60;, &#x60;mount&#x60;, &#x60;unmount&#x60;, and &#x60;destroy&#x60;  Networks report these events: &#x60;create&#x60;, &#x60;connect&#x60;, &#x60;disconnect&#x60;, &#x60;destroy&#x60;, &#x60;update&#x60;, and &#x60;remove&#x60;  The Docker daemon reports these events: &#x60;reload&#x60;  Services report these events: &#x60;create&#x60;, &#x60;update&#x60;, and &#x60;remove&#x60;  Nodes report these events: &#x60;create&#x60;, &#x60;update&#x60;, and &#x60;remove&#x60;  Secrets report these events: &#x60;create&#x60;, &#x60;update&#x60;, and &#x60;remove&#x60;  Configs report these events: &#x60;create&#x60;, &#x60;update&#x60;, and &#x60;remove&#x60; 
     *
     */
    @GET
    @Path("/events")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Monitor events", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "no error", response = SystemEventsResponse.class),
        @ApiResponse(code = 400, message = "bad parameter", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public SystemEventsResponse systemEvents(@QueryParam("since")String since, @QueryParam("until")String until, @QueryParam("filters")String filters);

    /**
     * Get system information
     *
     */
    @GET
    @Path("/info")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Get system information", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "No error", response = SystemInfo.class),
        @ApiResponse(code = 500, message = "Server error", response = ErrorResponse.class) })
    public SystemInfo systemInfo();

    /**
     * Ping
     *
     * This is a dummy endpoint you can use to test if the server is accessible.
     *
     */
    @GET
    @Path("/_ping")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "text/plain" })
    @ApiOperation(value = "Ping", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "no error", response = String.class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public String systemPing();

    /**
     * Get version
     *
     * Returns the version of Docker that is running and various information about the system that Docker is running on.
     *
     */
    @GET
    @Path("/version")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Get version", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "no error", response = SystemVersionResponse.class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public SystemVersionResponse systemVersion();
}

