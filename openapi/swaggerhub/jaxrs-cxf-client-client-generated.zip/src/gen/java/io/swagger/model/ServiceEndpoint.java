package io.swagger.model;

import io.swagger.model.EndpointPortConfig;
import io.swagger.model.EndpointSpec;
import io.swagger.model.ServiceEndpointVirtualIPs;
import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ServiceEndpoint  {
  
  @ApiModelProperty(value = "")
  private EndpointSpec spec = null;

  @ApiModelProperty(value = "")
  private List<EndpointPortConfig> ports = null;

  @ApiModelProperty(value = "")
  private List<ServiceEndpointVirtualIPs> virtualIPs = null;
 /**
   * Get spec
   * @return spec
  **/
  @JsonProperty("Spec")
  public EndpointSpec getSpec() {
    return spec;
  }

  public void setSpec(EndpointSpec spec) {
    this.spec = spec;
  }

  public ServiceEndpoint spec(EndpointSpec spec) {
    this.spec = spec;
    return this;
  }

 /**
   * Get ports
   * @return ports
  **/
  @JsonProperty("Ports")
  public List<EndpointPortConfig> getPorts() {
    return ports;
  }

  public void setPorts(List<EndpointPortConfig> ports) {
    this.ports = ports;
  }

  public ServiceEndpoint ports(List<EndpointPortConfig> ports) {
    this.ports = ports;
    return this;
  }

  public ServiceEndpoint addPortsItem(EndpointPortConfig portsItem) {
    this.ports.add(portsItem);
    return this;
  }

 /**
   * Get virtualIPs
   * @return virtualIPs
  **/
  @JsonProperty("VirtualIPs")
  public List<ServiceEndpointVirtualIPs> getVirtualIPs() {
    return virtualIPs;
  }

  public void setVirtualIPs(List<ServiceEndpointVirtualIPs> virtualIPs) {
    this.virtualIPs = virtualIPs;
  }

  public ServiceEndpoint virtualIPs(List<ServiceEndpointVirtualIPs> virtualIPs) {
    this.virtualIPs = virtualIPs;
    return this;
  }

  public ServiceEndpoint addVirtualIPsItem(ServiceEndpointVirtualIPs virtualIPsItem) {
    this.virtualIPs.add(virtualIPsItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ServiceEndpoint {\n");
    
    sb.append("    spec: ").append(toIndentedString(spec)).append("\n");
    sb.append("    ports: ").append(toIndentedString(ports)).append("\n");
    sb.append("    virtualIPs: ").append(toIndentedString(virtualIPs)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

