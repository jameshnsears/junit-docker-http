package io.swagger.model;

import io.swagger.annotations.ApiModel;
import io.swagger.model.DeviceMapping;
import io.swagger.model.ResourcesBlkioWeightDevice;
import io.swagger.model.ResourcesUlimits;
import io.swagger.model.ThrottleDevice;
import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * A container's resources (cgroups config, ulimits, etc)
 **/
@ApiModel(description="A container's resources (cgroups config, ulimits, etc)")
public class Resources  {
  
  @ApiModelProperty(value = "An integer value representing this container's relative CPU weight versus other containers.")
 /**
   * An integer value representing this container's relative CPU weight versus other containers.  
  **/
  private Integer cpuShares = null;

  @ApiModelProperty(value = "Memory limit in bytes.")
 /**
   * Memory limit in bytes.  
  **/
  private Long memory = 0l;

  @ApiModelProperty(value = "Path to `cgroups` under which the container's `cgroup` is created. If the path is not absolute, the path is considered to be relative to the `cgroups` path of the init process. Cgroups are created if they do not already exist.")
 /**
   * Path to `cgroups` under which the container's `cgroup` is created. If the path is not absolute, the path is considered to be relative to the `cgroups` path of the init process. Cgroups are created if they do not already exist.  
  **/
  private String cgroupParent = null;

  @ApiModelProperty(value = "Block IO weight (relative weight).")
 /**
   * Block IO weight (relative weight).  
  **/
  private Integer blkioWeight = null;

  @ApiModelProperty(value = "Block IO weight (relative device weight) in the form `[{\"Path\": \"device_path\", \"Weight\": weight}]`. ")
 /**
   * Block IO weight (relative device weight) in the form `[{\"Path\": \"device_path\", \"Weight\": weight}]`.   
  **/
  private List<ResourcesBlkioWeightDevice> blkioWeightDevice = null;

  @ApiModelProperty(value = "Limit read rate (bytes per second) from a device, in the form `[{\"Path\": \"device_path\", \"Rate\": rate}]`. ")
 /**
   * Limit read rate (bytes per second) from a device, in the form `[{\"Path\": \"device_path\", \"Rate\": rate}]`.   
  **/
  private List<ThrottleDevice> blkioDeviceReadBps = null;

  @ApiModelProperty(value = "Limit write rate (bytes per second) to a device, in the form `[{\"Path\": \"device_path\", \"Rate\": rate}]`. ")
 /**
   * Limit write rate (bytes per second) to a device, in the form `[{\"Path\": \"device_path\", \"Rate\": rate}]`.   
  **/
  private List<ThrottleDevice> blkioDeviceWriteBps = null;

  @ApiModelProperty(value = "Limit read rate (IO per second) from a device, in the form `[{\"Path\": \"device_path\", \"Rate\": rate}]`. ")
 /**
   * Limit read rate (IO per second) from a device, in the form `[{\"Path\": \"device_path\", \"Rate\": rate}]`.   
  **/
  private List<ThrottleDevice> blkioDeviceReadIOps = null;

  @ApiModelProperty(value = "Limit write rate (IO per second) to a device, in the form `[{\"Path\": \"device_path\", \"Rate\": rate}]`. ")
 /**
   * Limit write rate (IO per second) to a device, in the form `[{\"Path\": \"device_path\", \"Rate\": rate}]`.   
  **/
  private List<ThrottleDevice> blkioDeviceWriteIOps = null;

  @ApiModelProperty(value = "The length of a CPU period in microseconds.")
 /**
   * The length of a CPU period in microseconds.  
  **/
  private Long cpuPeriod = null;

  @ApiModelProperty(value = "Microseconds of CPU time that the container can get in a CPU period.")
 /**
   * Microseconds of CPU time that the container can get in a CPU period.  
  **/
  private Long cpuQuota = null;

  @ApiModelProperty(value = "The length of a CPU real-time period in microseconds. Set to 0 to allocate no time allocated to real-time tasks.")
 /**
   * The length of a CPU real-time period in microseconds. Set to 0 to allocate no time allocated to real-time tasks.  
  **/
  private Long cpuRealtimePeriod = null;

  @ApiModelProperty(value = "The length of a CPU real-time runtime in microseconds. Set to 0 to allocate no time allocated to real-time tasks.")
 /**
   * The length of a CPU real-time runtime in microseconds. Set to 0 to allocate no time allocated to real-time tasks.  
  **/
  private Long cpuRealtimeRuntime = null;

  @ApiModelProperty(example = "0-3", value = "CPUs in which to allow execution (e.g., `0-3`, `0,1`)")
 /**
   * CPUs in which to allow execution (e.g., `0-3`, `0,1`)  
  **/
  private String cpusetCpus = null;

  @ApiModelProperty(value = "Memory nodes (MEMs) in which to allow execution (0-3, 0,1). Only effective on NUMA systems.")
 /**
   * Memory nodes (MEMs) in which to allow execution (0-3, 0,1). Only effective on NUMA systems.  
  **/
  private String cpusetMems = null;

  @ApiModelProperty(value = "A list of devices to add to the container.")
 /**
   * A list of devices to add to the container.  
  **/
  private List<DeviceMapping> devices = null;

  @ApiModelProperty(value = "a list of cgroup rules to apply to the container")
 /**
   * a list of cgroup rules to apply to the container  
  **/
  private List<String> deviceCgroupRules = null;

  @ApiModelProperty(value = "Disk limit (in bytes).")
 /**
   * Disk limit (in bytes).  
  **/
  private Long diskQuota = null;

  @ApiModelProperty(value = "Kernel memory limit in bytes.")
 /**
   * Kernel memory limit in bytes.  
  **/
  private Long kernelMemory = null;

  @ApiModelProperty(value = "Memory soft limit in bytes.")
 /**
   * Memory soft limit in bytes.  
  **/
  private Long memoryReservation = null;

  @ApiModelProperty(value = "Total memory limit (memory + swap). Set as `-1` to enable unlimited swap.")
 /**
   * Total memory limit (memory + swap). Set as `-1` to enable unlimited swap.  
  **/
  private Long memorySwap = null;

  @ApiModelProperty(value = "Tune a container's memory swappiness behavior. Accepts an integer between 0 and 100.")
 /**
   * Tune a container's memory swappiness behavior. Accepts an integer between 0 and 100.  
  **/
  private Long memorySwappiness = null;

  @ApiModelProperty(value = "CPU quota in units of 10<sup>-9</sup> CPUs.")
 /**
   * CPU quota in units of 10<sup>-9</sup> CPUs.  
  **/
  private Long nanoCPUs = null;

  @ApiModelProperty(value = "Disable OOM Killer for the container.")
 /**
   * Disable OOM Killer for the container.  
  **/
  private Boolean oomKillDisable = null;

  @ApiModelProperty(value = "Run an init inside the container that forwards signals and reaps processes. This field is omitted if empty, and the default (as configured on the daemon) is used.")
 /**
   * Run an init inside the container that forwards signals and reaps processes. This field is omitted if empty, and the default (as configured on the daemon) is used.  
  **/
  private Boolean init = null;

  @ApiModelProperty(value = "Tune a container's pids limit. Set -1 for unlimited.")
 /**
   * Tune a container's pids limit. Set -1 for unlimited.  
  **/
  private Long pidsLimit = null;

  @ApiModelProperty(value = "A list of resource limits to set in the container. For example: `{\"Name\": \"nofile\", \"Soft\": 1024, \"Hard\": 2048}`\" ")
 /**
   * A list of resource limits to set in the container. For example: `{\"Name\": \"nofile\", \"Soft\": 1024, \"Hard\": 2048}`\"   
  **/
  private List<ResourcesUlimits> ulimits = null;

  @ApiModelProperty(value = "The number of usable CPUs (Windows only).  On Windows Server containers, the processor resource controls are mutually exclusive. The order of precedence is `CPUCount` first, then `CPUShares`, and `CPUPercent` last. ")
 /**
   * The number of usable CPUs (Windows only).  On Windows Server containers, the processor resource controls are mutually exclusive. The order of precedence is `CPUCount` first, then `CPUShares`, and `CPUPercent` last.   
  **/
  private Long cpuCount = null;

  @ApiModelProperty(value = "The usable percentage of the available CPUs (Windows only).  On Windows Server containers, the processor resource controls are mutually exclusive. The order of precedence is `CPUCount` first, then `CPUShares`, and `CPUPercent` last. ")
 /**
   * The usable percentage of the available CPUs (Windows only).  On Windows Server containers, the processor resource controls are mutually exclusive. The order of precedence is `CPUCount` first, then `CPUShares`, and `CPUPercent` last.   
  **/
  private Long cpuPercent = null;

  @ApiModelProperty(value = "Maximum IOps for the container system drive (Windows only)")
 /**
   * Maximum IOps for the container system drive (Windows only)  
  **/
  private Long ioMaximumIOps = null;

  @ApiModelProperty(value = "Maximum IO in bytes per second for the container system drive (Windows only)")
 /**
   * Maximum IO in bytes per second for the container system drive (Windows only)  
  **/
  private Long ioMaximumBandwidth = null;
 /**
   * An integer value representing this container&#39;s relative CPU weight versus other containers.
   * @return cpuShares
  **/
  @JsonProperty("CpuShares")
  public Integer getCpuShares() {
    return cpuShares;
  }

  public void setCpuShares(Integer cpuShares) {
    this.cpuShares = cpuShares;
  }

  public Resources cpuShares(Integer cpuShares) {
    this.cpuShares = cpuShares;
    return this;
  }

 /**
   * Memory limit in bytes.
   * @return memory
  **/
  @JsonProperty("Memory")
  public Long getMemory() {
    return memory;
  }

  public void setMemory(Long memory) {
    this.memory = memory;
  }

  public Resources memory(Long memory) {
    this.memory = memory;
    return this;
  }

 /**
   * Path to &#x60;cgroups&#x60; under which the container&#39;s &#x60;cgroup&#x60; is created. If the path is not absolute, the path is considered to be relative to the &#x60;cgroups&#x60; path of the init process. Cgroups are created if they do not already exist.
   * @return cgroupParent
  **/
  @JsonProperty("CgroupParent")
  public String getCgroupParent() {
    return cgroupParent;
  }

  public void setCgroupParent(String cgroupParent) {
    this.cgroupParent = cgroupParent;
  }

  public Resources cgroupParent(String cgroupParent) {
    this.cgroupParent = cgroupParent;
    return this;
  }

 /**
   * Block IO weight (relative weight).
   * minimum: 0
   * maximum: 1000
   * @return blkioWeight
  **/
  @JsonProperty("BlkioWeight")
  public Integer getBlkioWeight() {
    return blkioWeight;
  }

  public void setBlkioWeight(Integer blkioWeight) {
    this.blkioWeight = blkioWeight;
  }

  public Resources blkioWeight(Integer blkioWeight) {
    this.blkioWeight = blkioWeight;
    return this;
  }

 /**
   * Block IO weight (relative device weight) in the form &#x60;[{\&quot;Path\&quot;: \&quot;device_path\&quot;, \&quot;Weight\&quot;: weight}]&#x60;. 
   * @return blkioWeightDevice
  **/
  @JsonProperty("BlkioWeightDevice")
  public List<ResourcesBlkioWeightDevice> getBlkioWeightDevice() {
    return blkioWeightDevice;
  }

  public void setBlkioWeightDevice(List<ResourcesBlkioWeightDevice> blkioWeightDevice) {
    this.blkioWeightDevice = blkioWeightDevice;
  }

  public Resources blkioWeightDevice(List<ResourcesBlkioWeightDevice> blkioWeightDevice) {
    this.blkioWeightDevice = blkioWeightDevice;
    return this;
  }

  public Resources addBlkioWeightDeviceItem(ResourcesBlkioWeightDevice blkioWeightDeviceItem) {
    this.blkioWeightDevice.add(blkioWeightDeviceItem);
    return this;
  }

 /**
   * Limit read rate (bytes per second) from a device, in the form &#x60;[{\&quot;Path\&quot;: \&quot;device_path\&quot;, \&quot;Rate\&quot;: rate}]&#x60;. 
   * @return blkioDeviceReadBps
  **/
  @JsonProperty("BlkioDeviceReadBps")
  public List<ThrottleDevice> getBlkioDeviceReadBps() {
    return blkioDeviceReadBps;
  }

  public void setBlkioDeviceReadBps(List<ThrottleDevice> blkioDeviceReadBps) {
    this.blkioDeviceReadBps = blkioDeviceReadBps;
  }

  public Resources blkioDeviceReadBps(List<ThrottleDevice> blkioDeviceReadBps) {
    this.blkioDeviceReadBps = blkioDeviceReadBps;
    return this;
  }

  public Resources addBlkioDeviceReadBpsItem(ThrottleDevice blkioDeviceReadBpsItem) {
    this.blkioDeviceReadBps.add(blkioDeviceReadBpsItem);
    return this;
  }

 /**
   * Limit write rate (bytes per second) to a device, in the form &#x60;[{\&quot;Path\&quot;: \&quot;device_path\&quot;, \&quot;Rate\&quot;: rate}]&#x60;. 
   * @return blkioDeviceWriteBps
  **/
  @JsonProperty("BlkioDeviceWriteBps")
  public List<ThrottleDevice> getBlkioDeviceWriteBps() {
    return blkioDeviceWriteBps;
  }

  public void setBlkioDeviceWriteBps(List<ThrottleDevice> blkioDeviceWriteBps) {
    this.blkioDeviceWriteBps = blkioDeviceWriteBps;
  }

  public Resources blkioDeviceWriteBps(List<ThrottleDevice> blkioDeviceWriteBps) {
    this.blkioDeviceWriteBps = blkioDeviceWriteBps;
    return this;
  }

  public Resources addBlkioDeviceWriteBpsItem(ThrottleDevice blkioDeviceWriteBpsItem) {
    this.blkioDeviceWriteBps.add(blkioDeviceWriteBpsItem);
    return this;
  }

 /**
   * Limit read rate (IO per second) from a device, in the form &#x60;[{\&quot;Path\&quot;: \&quot;device_path\&quot;, \&quot;Rate\&quot;: rate}]&#x60;. 
   * @return blkioDeviceReadIOps
  **/
  @JsonProperty("BlkioDeviceReadIOps")
  public List<ThrottleDevice> getBlkioDeviceReadIOps() {
    return blkioDeviceReadIOps;
  }

  public void setBlkioDeviceReadIOps(List<ThrottleDevice> blkioDeviceReadIOps) {
    this.blkioDeviceReadIOps = blkioDeviceReadIOps;
  }

  public Resources blkioDeviceReadIOps(List<ThrottleDevice> blkioDeviceReadIOps) {
    this.blkioDeviceReadIOps = blkioDeviceReadIOps;
    return this;
  }

  public Resources addBlkioDeviceReadIOpsItem(ThrottleDevice blkioDeviceReadIOpsItem) {
    this.blkioDeviceReadIOps.add(blkioDeviceReadIOpsItem);
    return this;
  }

 /**
   * Limit write rate (IO per second) to a device, in the form &#x60;[{\&quot;Path\&quot;: \&quot;device_path\&quot;, \&quot;Rate\&quot;: rate}]&#x60;. 
   * @return blkioDeviceWriteIOps
  **/
  @JsonProperty("BlkioDeviceWriteIOps")
  public List<ThrottleDevice> getBlkioDeviceWriteIOps() {
    return blkioDeviceWriteIOps;
  }

  public void setBlkioDeviceWriteIOps(List<ThrottleDevice> blkioDeviceWriteIOps) {
    this.blkioDeviceWriteIOps = blkioDeviceWriteIOps;
  }

  public Resources blkioDeviceWriteIOps(List<ThrottleDevice> blkioDeviceWriteIOps) {
    this.blkioDeviceWriteIOps = blkioDeviceWriteIOps;
    return this;
  }

  public Resources addBlkioDeviceWriteIOpsItem(ThrottleDevice blkioDeviceWriteIOpsItem) {
    this.blkioDeviceWriteIOps.add(blkioDeviceWriteIOpsItem);
    return this;
  }

 /**
   * The length of a CPU period in microseconds.
   * @return cpuPeriod
  **/
  @JsonProperty("CpuPeriod")
  public Long getCpuPeriod() {
    return cpuPeriod;
  }

  public void setCpuPeriod(Long cpuPeriod) {
    this.cpuPeriod = cpuPeriod;
  }

  public Resources cpuPeriod(Long cpuPeriod) {
    this.cpuPeriod = cpuPeriod;
    return this;
  }

 /**
   * Microseconds of CPU time that the container can get in a CPU period.
   * @return cpuQuota
  **/
  @JsonProperty("CpuQuota")
  public Long getCpuQuota() {
    return cpuQuota;
  }

  public void setCpuQuota(Long cpuQuota) {
    this.cpuQuota = cpuQuota;
  }

  public Resources cpuQuota(Long cpuQuota) {
    this.cpuQuota = cpuQuota;
    return this;
  }

 /**
   * The length of a CPU real-time period in microseconds. Set to 0 to allocate no time allocated to real-time tasks.
   * @return cpuRealtimePeriod
  **/
  @JsonProperty("CpuRealtimePeriod")
  public Long getCpuRealtimePeriod() {
    return cpuRealtimePeriod;
  }

  public void setCpuRealtimePeriod(Long cpuRealtimePeriod) {
    this.cpuRealtimePeriod = cpuRealtimePeriod;
  }

  public Resources cpuRealtimePeriod(Long cpuRealtimePeriod) {
    this.cpuRealtimePeriod = cpuRealtimePeriod;
    return this;
  }

 /**
   * The length of a CPU real-time runtime in microseconds. Set to 0 to allocate no time allocated to real-time tasks.
   * @return cpuRealtimeRuntime
  **/
  @JsonProperty("CpuRealtimeRuntime")
  public Long getCpuRealtimeRuntime() {
    return cpuRealtimeRuntime;
  }

  public void setCpuRealtimeRuntime(Long cpuRealtimeRuntime) {
    this.cpuRealtimeRuntime = cpuRealtimeRuntime;
  }

  public Resources cpuRealtimeRuntime(Long cpuRealtimeRuntime) {
    this.cpuRealtimeRuntime = cpuRealtimeRuntime;
    return this;
  }

 /**
   * CPUs in which to allow execution (e.g., &#x60;0-3&#x60;, &#x60;0,1&#x60;)
   * @return cpusetCpus
  **/
  @JsonProperty("CpusetCpus")
  public String getCpusetCpus() {
    return cpusetCpus;
  }

  public void setCpusetCpus(String cpusetCpus) {
    this.cpusetCpus = cpusetCpus;
  }

  public Resources cpusetCpus(String cpusetCpus) {
    this.cpusetCpus = cpusetCpus;
    return this;
  }

 /**
   * Memory nodes (MEMs) in which to allow execution (0-3, 0,1). Only effective on NUMA systems.
   * @return cpusetMems
  **/
  @JsonProperty("CpusetMems")
  public String getCpusetMems() {
    return cpusetMems;
  }

  public void setCpusetMems(String cpusetMems) {
    this.cpusetMems = cpusetMems;
  }

  public Resources cpusetMems(String cpusetMems) {
    this.cpusetMems = cpusetMems;
    return this;
  }

 /**
   * A list of devices to add to the container.
   * @return devices
  **/
  @JsonProperty("Devices")
  public List<DeviceMapping> getDevices() {
    return devices;
  }

  public void setDevices(List<DeviceMapping> devices) {
    this.devices = devices;
  }

  public Resources devices(List<DeviceMapping> devices) {
    this.devices = devices;
    return this;
  }

  public Resources addDevicesItem(DeviceMapping devicesItem) {
    this.devices.add(devicesItem);
    return this;
  }

 /**
   * a list of cgroup rules to apply to the container
   * @return deviceCgroupRules
  **/
  @JsonProperty("DeviceCgroupRules")
  public List<String> getDeviceCgroupRules() {
    return deviceCgroupRules;
  }

  public void setDeviceCgroupRules(List<String> deviceCgroupRules) {
    this.deviceCgroupRules = deviceCgroupRules;
  }

  public Resources deviceCgroupRules(List<String> deviceCgroupRules) {
    this.deviceCgroupRules = deviceCgroupRules;
    return this;
  }

  public Resources addDeviceCgroupRulesItem(String deviceCgroupRulesItem) {
    this.deviceCgroupRules.add(deviceCgroupRulesItem);
    return this;
  }

 /**
   * Disk limit (in bytes).
   * @return diskQuota
  **/
  @JsonProperty("DiskQuota")
  public Long getDiskQuota() {
    return diskQuota;
  }

  public void setDiskQuota(Long diskQuota) {
    this.diskQuota = diskQuota;
  }

  public Resources diskQuota(Long diskQuota) {
    this.diskQuota = diskQuota;
    return this;
  }

 /**
   * Kernel memory limit in bytes.
   * @return kernelMemory
  **/
  @JsonProperty("KernelMemory")
  public Long getKernelMemory() {
    return kernelMemory;
  }

  public void setKernelMemory(Long kernelMemory) {
    this.kernelMemory = kernelMemory;
  }

  public Resources kernelMemory(Long kernelMemory) {
    this.kernelMemory = kernelMemory;
    return this;
  }

 /**
   * Memory soft limit in bytes.
   * @return memoryReservation
  **/
  @JsonProperty("MemoryReservation")
  public Long getMemoryReservation() {
    return memoryReservation;
  }

  public void setMemoryReservation(Long memoryReservation) {
    this.memoryReservation = memoryReservation;
  }

  public Resources memoryReservation(Long memoryReservation) {
    this.memoryReservation = memoryReservation;
    return this;
  }

 /**
   * Total memory limit (memory + swap). Set as &#x60;-1&#x60; to enable unlimited swap.
   * @return memorySwap
  **/
  @JsonProperty("MemorySwap")
  public Long getMemorySwap() {
    return memorySwap;
  }

  public void setMemorySwap(Long memorySwap) {
    this.memorySwap = memorySwap;
  }

  public Resources memorySwap(Long memorySwap) {
    this.memorySwap = memorySwap;
    return this;
  }

 /**
   * Tune a container&#39;s memory swappiness behavior. Accepts an integer between 0 and 100.
   * minimum: 0
   * maximum: 100
   * @return memorySwappiness
  **/
  @JsonProperty("MemorySwappiness")
  public Long getMemorySwappiness() {
    return memorySwappiness;
  }

  public void setMemorySwappiness(Long memorySwappiness) {
    this.memorySwappiness = memorySwappiness;
  }

  public Resources memorySwappiness(Long memorySwappiness) {
    this.memorySwappiness = memorySwappiness;
    return this;
  }

 /**
   * CPU quota in units of 10&lt;sup&gt;-9&lt;/sup&gt; CPUs.
   * @return nanoCPUs
  **/
  @JsonProperty("NanoCPUs")
  public Long getNanoCPUs() {
    return nanoCPUs;
  }

  public void setNanoCPUs(Long nanoCPUs) {
    this.nanoCPUs = nanoCPUs;
  }

  public Resources nanoCPUs(Long nanoCPUs) {
    this.nanoCPUs = nanoCPUs;
    return this;
  }

 /**
   * Disable OOM Killer for the container.
   * @return oomKillDisable
  **/
  @JsonProperty("OomKillDisable")
  public Boolean isOomKillDisable() {
    return oomKillDisable;
  }

  public void setOomKillDisable(Boolean oomKillDisable) {
    this.oomKillDisable = oomKillDisable;
  }

  public Resources oomKillDisable(Boolean oomKillDisable) {
    this.oomKillDisable = oomKillDisable;
    return this;
  }

 /**
   * Run an init inside the container that forwards signals and reaps processes. This field is omitted if empty, and the default (as configured on the daemon) is used.
   * @return init
  **/
  @JsonProperty("Init")
  public Boolean isInit() {
    return init;
  }

  public void setInit(Boolean init) {
    this.init = init;
  }

  public Resources init(Boolean init) {
    this.init = init;
    return this;
  }

 /**
   * Tune a container&#39;s pids limit. Set -1 for unlimited.
   * @return pidsLimit
  **/
  @JsonProperty("PidsLimit")
  public Long getPidsLimit() {
    return pidsLimit;
  }

  public void setPidsLimit(Long pidsLimit) {
    this.pidsLimit = pidsLimit;
  }

  public Resources pidsLimit(Long pidsLimit) {
    this.pidsLimit = pidsLimit;
    return this;
  }

 /**
   * A list of resource limits to set in the container. For example: &#x60;{\&quot;Name\&quot;: \&quot;nofile\&quot;, \&quot;Soft\&quot;: 1024, \&quot;Hard\&quot;: 2048}&#x60;\&quot; 
   * @return ulimits
  **/
  @JsonProperty("Ulimits")
  public List<ResourcesUlimits> getUlimits() {
    return ulimits;
  }

  public void setUlimits(List<ResourcesUlimits> ulimits) {
    this.ulimits = ulimits;
  }

  public Resources ulimits(List<ResourcesUlimits> ulimits) {
    this.ulimits = ulimits;
    return this;
  }

  public Resources addUlimitsItem(ResourcesUlimits ulimitsItem) {
    this.ulimits.add(ulimitsItem);
    return this;
  }

 /**
   * The number of usable CPUs (Windows only).  On Windows Server containers, the processor resource controls are mutually exclusive. The order of precedence is &#x60;CPUCount&#x60; first, then &#x60;CPUShares&#x60;, and &#x60;CPUPercent&#x60; last. 
   * @return cpuCount
  **/
  @JsonProperty("CpuCount")
  public Long getCpuCount() {
    return cpuCount;
  }

  public void setCpuCount(Long cpuCount) {
    this.cpuCount = cpuCount;
  }

  public Resources cpuCount(Long cpuCount) {
    this.cpuCount = cpuCount;
    return this;
  }

 /**
   * The usable percentage of the available CPUs (Windows only).  On Windows Server containers, the processor resource controls are mutually exclusive. The order of precedence is &#x60;CPUCount&#x60; first, then &#x60;CPUShares&#x60;, and &#x60;CPUPercent&#x60; last. 
   * @return cpuPercent
  **/
  @JsonProperty("CpuPercent")
  public Long getCpuPercent() {
    return cpuPercent;
  }

  public void setCpuPercent(Long cpuPercent) {
    this.cpuPercent = cpuPercent;
  }

  public Resources cpuPercent(Long cpuPercent) {
    this.cpuPercent = cpuPercent;
    return this;
  }

 /**
   * Maximum IOps for the container system drive (Windows only)
   * @return ioMaximumIOps
  **/
  @JsonProperty("IOMaximumIOps")
  public Long getIoMaximumIOps() {
    return ioMaximumIOps;
  }

  public void setIoMaximumIOps(Long ioMaximumIOps) {
    this.ioMaximumIOps = ioMaximumIOps;
  }

  public Resources ioMaximumIOps(Long ioMaximumIOps) {
    this.ioMaximumIOps = ioMaximumIOps;
    return this;
  }

 /**
   * Maximum IO in bytes per second for the container system drive (Windows only)
   * @return ioMaximumBandwidth
  **/
  @JsonProperty("IOMaximumBandwidth")
  public Long getIoMaximumBandwidth() {
    return ioMaximumBandwidth;
  }

  public void setIoMaximumBandwidth(Long ioMaximumBandwidth) {
    this.ioMaximumBandwidth = ioMaximumBandwidth;
  }

  public Resources ioMaximumBandwidth(Long ioMaximumBandwidth) {
    this.ioMaximumBandwidth = ioMaximumBandwidth;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Resources {\n");
    
    sb.append("    cpuShares: ").append(toIndentedString(cpuShares)).append("\n");
    sb.append("    memory: ").append(toIndentedString(memory)).append("\n");
    sb.append("    cgroupParent: ").append(toIndentedString(cgroupParent)).append("\n");
    sb.append("    blkioWeight: ").append(toIndentedString(blkioWeight)).append("\n");
    sb.append("    blkioWeightDevice: ").append(toIndentedString(blkioWeightDevice)).append("\n");
    sb.append("    blkioDeviceReadBps: ").append(toIndentedString(blkioDeviceReadBps)).append("\n");
    sb.append("    blkioDeviceWriteBps: ").append(toIndentedString(blkioDeviceWriteBps)).append("\n");
    sb.append("    blkioDeviceReadIOps: ").append(toIndentedString(blkioDeviceReadIOps)).append("\n");
    sb.append("    blkioDeviceWriteIOps: ").append(toIndentedString(blkioDeviceWriteIOps)).append("\n");
    sb.append("    cpuPeriod: ").append(toIndentedString(cpuPeriod)).append("\n");
    sb.append("    cpuQuota: ").append(toIndentedString(cpuQuota)).append("\n");
    sb.append("    cpuRealtimePeriod: ").append(toIndentedString(cpuRealtimePeriod)).append("\n");
    sb.append("    cpuRealtimeRuntime: ").append(toIndentedString(cpuRealtimeRuntime)).append("\n");
    sb.append("    cpusetCpus: ").append(toIndentedString(cpusetCpus)).append("\n");
    sb.append("    cpusetMems: ").append(toIndentedString(cpusetMems)).append("\n");
    sb.append("    devices: ").append(toIndentedString(devices)).append("\n");
    sb.append("    deviceCgroupRules: ").append(toIndentedString(deviceCgroupRules)).append("\n");
    sb.append("    diskQuota: ").append(toIndentedString(diskQuota)).append("\n");
    sb.append("    kernelMemory: ").append(toIndentedString(kernelMemory)).append("\n");
    sb.append("    memoryReservation: ").append(toIndentedString(memoryReservation)).append("\n");
    sb.append("    memorySwap: ").append(toIndentedString(memorySwap)).append("\n");
    sb.append("    memorySwappiness: ").append(toIndentedString(memorySwappiness)).append("\n");
    sb.append("    nanoCPUs: ").append(toIndentedString(nanoCPUs)).append("\n");
    sb.append("    oomKillDisable: ").append(toIndentedString(oomKillDisable)).append("\n");
    sb.append("    init: ").append(toIndentedString(init)).append("\n");
    sb.append("    pidsLimit: ").append(toIndentedString(pidsLimit)).append("\n");
    sb.append("    ulimits: ").append(toIndentedString(ulimits)).append("\n");
    sb.append("    cpuCount: ").append(toIndentedString(cpuCount)).append("\n");
    sb.append("    cpuPercent: ").append(toIndentedString(cpuPercent)).append("\n");
    sb.append("    ioMaximumIOps: ").append(toIndentedString(ioMaximumIOps)).append("\n");
    sb.append("    ioMaximumBandwidth: ").append(toIndentedString(ioMaximumBandwidth)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

