package io.swagger.model;

import io.swagger.annotations.ApiModel;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * Address represents an IPv4 or IPv6 IP address.
 **/
@ApiModel(description="Address represents an IPv4 or IPv6 IP address.")
public class Address  {
  
  @ApiModelProperty(value = "IP address.")
 /**
   * IP address.  
  **/
  private String addr = null;

  @ApiModelProperty(value = "Mask length of the IP address.")
 /**
   * Mask length of the IP address.  
  **/
  private Integer prefixLen = null;
 /**
   * IP address.
   * @return addr
  **/
  @JsonProperty("Addr")
  public String getAddr() {
    return addr;
  }

  public void setAddr(String addr) {
    this.addr = addr;
  }

  public Address addr(String addr) {
    this.addr = addr;
    return this;
  }

 /**
   * Mask length of the IP address.
   * @return prefixLen
  **/
  @JsonProperty("PrefixLen")
  public Integer getPrefixLen() {
    return prefixLen;
  }

  public void setPrefixLen(Integer prefixLen) {
    this.prefixLen = prefixLen;
  }

  public Address prefixLen(Integer prefixLen) {
    this.prefixLen = prefixLen;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Address {\n");
    
    sb.append("    addr: ").append(toIndentedString(addr)).append("\n");
    sb.append("    prefixLen: ").append(toIndentedString(prefixLen)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

