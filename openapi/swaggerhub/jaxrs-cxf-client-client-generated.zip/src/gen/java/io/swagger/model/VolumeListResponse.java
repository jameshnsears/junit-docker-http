package io.swagger.model;

import io.swagger.annotations.ApiModel;
import io.swagger.model.Volume;
import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * Volume list response
 **/
@ApiModel(description="Volume list response")
public class VolumeListResponse  {
  
  @ApiModelProperty(required = true, value = "List of volumes")
 /**
   * List of volumes  
  **/
  private List<Volume> volumes = new ArrayList<Volume>();

  @ApiModelProperty(required = true, value = "Warnings that occurred when fetching the list of volumes")
 /**
   * Warnings that occurred when fetching the list of volumes  
  **/
  private List<String> warnings = new ArrayList<String>();
 /**
   * List of volumes
   * @return volumes
  **/
  @JsonProperty("Volumes")
  public List<Volume> getVolumes() {
    return volumes;
  }

  public void setVolumes(List<Volume> volumes) {
    this.volumes = volumes;
  }

  public VolumeListResponse volumes(List<Volume> volumes) {
    this.volumes = volumes;
    return this;
  }

  public VolumeListResponse addVolumesItem(Volume volumesItem) {
    this.volumes.add(volumesItem);
    return this;
  }

 /**
   * Warnings that occurred when fetching the list of volumes
   * @return warnings
  **/
  @JsonProperty("Warnings")
  public List<String> getWarnings() {
    return warnings;
  }

  public void setWarnings(List<String> warnings) {
    this.warnings = warnings;
  }

  public VolumeListResponse warnings(List<String> warnings) {
    this.warnings = warnings;
    return this;
  }

  public VolumeListResponse addWarningsItem(String warningsItem) {
    this.warnings.add(warningsItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class VolumeListResponse {\n");
    
    sb.append("    volumes: ").append(toIndentedString(volumes)).append("\n");
    sb.append("    warnings: ").append(toIndentedString(warnings)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

