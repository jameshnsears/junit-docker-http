package io.swagger.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ImageSummary  {
  
  @ApiModelProperty(required = true, value = "")
  private String id = null;

  @ApiModelProperty(required = true, value = "")
  private String parentId = null;

  @ApiModelProperty(required = true, value = "")
  private List<String> repoTags = new ArrayList<String>();

  @ApiModelProperty(required = true, value = "")
  private List<String> repoDigests = new ArrayList<String>();

  @ApiModelProperty(required = true, value = "")
  private Integer created = null;

  @ApiModelProperty(required = true, value = "")
  private Integer size = null;

  @ApiModelProperty(required = true, value = "")
  private Integer sharedSize = null;

  @ApiModelProperty(required = true, value = "")
  private Integer virtualSize = null;

  @ApiModelProperty(required = true, value = "")
  private Map<String, String> labels = new HashMap<String, String>();

  @ApiModelProperty(required = true, value = "")
  private Integer containers = null;
 /**
   * Get id
   * @return id
  **/
  @JsonProperty("Id")
  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public ImageSummary id(String id) {
    this.id = id;
    return this;
  }

 /**
   * Get parentId
   * @return parentId
  **/
  @JsonProperty("ParentId")
  public String getParentId() {
    return parentId;
  }

  public void setParentId(String parentId) {
    this.parentId = parentId;
  }

  public ImageSummary parentId(String parentId) {
    this.parentId = parentId;
    return this;
  }

 /**
   * Get repoTags
   * @return repoTags
  **/
  @JsonProperty("RepoTags")
  public List<String> getRepoTags() {
    return repoTags;
  }

  public void setRepoTags(List<String> repoTags) {
    this.repoTags = repoTags;
  }

  public ImageSummary repoTags(List<String> repoTags) {
    this.repoTags = repoTags;
    return this;
  }

  public ImageSummary addRepoTagsItem(String repoTagsItem) {
    this.repoTags.add(repoTagsItem);
    return this;
  }

 /**
   * Get repoDigests
   * @return repoDigests
  **/
  @JsonProperty("RepoDigests")
  public List<String> getRepoDigests() {
    return repoDigests;
  }

  public void setRepoDigests(List<String> repoDigests) {
    this.repoDigests = repoDigests;
  }

  public ImageSummary repoDigests(List<String> repoDigests) {
    this.repoDigests = repoDigests;
    return this;
  }

  public ImageSummary addRepoDigestsItem(String repoDigestsItem) {
    this.repoDigests.add(repoDigestsItem);
    return this;
  }

 /**
   * Get created
   * @return created
  **/
  @JsonProperty("Created")
  public Integer getCreated() {
    return created;
  }

  public void setCreated(Integer created) {
    this.created = created;
  }

  public ImageSummary created(Integer created) {
    this.created = created;
    return this;
  }

 /**
   * Get size
   * @return size
  **/
  @JsonProperty("Size")
  public Integer getSize() {
    return size;
  }

  public void setSize(Integer size) {
    this.size = size;
  }

  public ImageSummary size(Integer size) {
    this.size = size;
    return this;
  }

 /**
   * Get sharedSize
   * @return sharedSize
  **/
  @JsonProperty("SharedSize")
  public Integer getSharedSize() {
    return sharedSize;
  }

  public void setSharedSize(Integer sharedSize) {
    this.sharedSize = sharedSize;
  }

  public ImageSummary sharedSize(Integer sharedSize) {
    this.sharedSize = sharedSize;
    return this;
  }

 /**
   * Get virtualSize
   * @return virtualSize
  **/
  @JsonProperty("VirtualSize")
  public Integer getVirtualSize() {
    return virtualSize;
  }

  public void setVirtualSize(Integer virtualSize) {
    this.virtualSize = virtualSize;
  }

  public ImageSummary virtualSize(Integer virtualSize) {
    this.virtualSize = virtualSize;
    return this;
  }

 /**
   * Get labels
   * @return labels
  **/
  @JsonProperty("Labels")
  public Map<String, String> getLabels() {
    return labels;
  }

  public void setLabels(Map<String, String> labels) {
    this.labels = labels;
  }

  public ImageSummary labels(Map<String, String> labels) {
    this.labels = labels;
    return this;
  }

  public ImageSummary putLabelsItem(String key, String labelsItem) {
    this.labels.put(key, labelsItem);
    return this;
  }

 /**
   * Get containers
   * @return containers
  **/
  @JsonProperty("Containers")
  public Integer getContainers() {
    return containers;
  }

  public void setContainers(Integer containers) {
    this.containers = containers;
  }

  public ImageSummary containers(Integer containers) {
    this.containers = containers;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ImageSummary {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    parentId: ").append(toIndentedString(parentId)).append("\n");
    sb.append("    repoTags: ").append(toIndentedString(repoTags)).append("\n");
    sb.append("    repoDigests: ").append(toIndentedString(repoDigests)).append("\n");
    sb.append("    created: ").append(toIndentedString(created)).append("\n");
    sb.append("    size: ").append(toIndentedString(size)).append("\n");
    sb.append("    sharedSize: ").append(toIndentedString(sharedSize)).append("\n");
    sb.append("    virtualSize: ").append(toIndentedString(virtualSize)).append("\n");
    sb.append("    labels: ").append(toIndentedString(labels)).append("\n");
    sb.append("    containers: ").append(toIndentedString(containers)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

