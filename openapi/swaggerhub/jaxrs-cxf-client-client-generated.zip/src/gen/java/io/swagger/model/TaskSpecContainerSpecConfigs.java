package io.swagger.model;

import io.swagger.model.TaskSpecContainerSpecFile;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class TaskSpecContainerSpecConfigs  {
  
  @ApiModelProperty(value = "")
  private TaskSpecContainerSpecFile file = null;

  @ApiModelProperty(value = "ConfigID represents the ID of the specific config that we're referencing.")
 /**
   * ConfigID represents the ID of the specific config that we're referencing.  
  **/
  private String configID = null;

  @ApiModelProperty(value = "ConfigName is the name of the config that this references, but this is just provided for lookup/display purposes. The config in the reference will be identified by its ID. ")
 /**
   * ConfigName is the name of the config that this references, but this is just provided for lookup/display purposes. The config in the reference will be identified by its ID.   
  **/
  private String configName = null;
 /**
   * Get file
   * @return file
  **/
  @JsonProperty("File")
  public TaskSpecContainerSpecFile getFile() {
    return file;
  }

  public void setFile(TaskSpecContainerSpecFile file) {
    this.file = file;
  }

  public TaskSpecContainerSpecConfigs file(TaskSpecContainerSpecFile file) {
    this.file = file;
    return this;
  }

 /**
   * ConfigID represents the ID of the specific config that we&#39;re referencing.
   * @return configID
  **/
  @JsonProperty("ConfigID")
  public String getConfigID() {
    return configID;
  }

  public void setConfigID(String configID) {
    this.configID = configID;
  }

  public TaskSpecContainerSpecConfigs configID(String configID) {
    this.configID = configID;
    return this;
  }

 /**
   * ConfigName is the name of the config that this references, but this is just provided for lookup/display purposes. The config in the reference will be identified by its ID. 
   * @return configName
  **/
  @JsonProperty("ConfigName")
  public String getConfigName() {
    return configName;
  }

  public void setConfigName(String configName) {
    this.configName = configName;
  }

  public TaskSpecContainerSpecConfigs configName(String configName) {
    this.configName = configName;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TaskSpecContainerSpecConfigs {\n");
    
    sb.append("    file: ").append(toIndentedString(file)).append("\n");
    sb.append("    configID: ").append(toIndentedString(configID)).append("\n");
    sb.append("    configName: ").append(toIndentedString(configName)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

