package io.swagger.model;

import io.swagger.annotations.ApiModel;
import io.swagger.model.HealthConfig;
import io.swagger.model.Mount;
import io.swagger.model.TaskSpecContainerSpecConfigs;
import io.swagger.model.TaskSpecContainerSpecDNSConfig;
import io.swagger.model.TaskSpecContainerSpecPrivileges;
import io.swagger.model.TaskSpecContainerSpecSecrets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * Container spec for the service.  <p><br /></p>  > **Note**: ContainerSpec, NetworkAttachmentSpec, and PluginSpec are > mutually exclusive. PluginSpec is only used when the Runtime field > is set to `plugin`. NetworkAttachmentSpec is used when the Runtime > field is set to `attachment`. 
 **/
@ApiModel(description="Container spec for the service.  <p><br /></p>  > **Note**: ContainerSpec, NetworkAttachmentSpec, and PluginSpec are > mutually exclusive. PluginSpec is only used when the Runtime field > is set to `plugin`. NetworkAttachmentSpec is used when the Runtime > field is set to `attachment`. ")
public class TaskSpecContainerSpec  {
  
  @ApiModelProperty(value = "The image name to use for the container")
 /**
   * The image name to use for the container  
  **/
  private String image = null;

  @ApiModelProperty(value = "User-defined key/value data.")
 /**
   * User-defined key/value data.  
  **/
  private Map<String, String> labels = null;

  @ApiModelProperty(value = "The command to be run in the image.")
 /**
   * The command to be run in the image.  
  **/
  private List<String> command = null;

  @ApiModelProperty(value = "Arguments to the command.")
 /**
   * Arguments to the command.  
  **/
  private List<String> args = null;

  @ApiModelProperty(value = "The hostname to use for the container, as a valid RFC 1123 hostname.")
 /**
   * The hostname to use for the container, as a valid RFC 1123 hostname.  
  **/
  private String hostname = null;

  @ApiModelProperty(value = "A list of environment variables in the form `VAR=value`.")
 /**
   * A list of environment variables in the form `VAR=value`.  
  **/
  private List<String> env = null;

  @ApiModelProperty(value = "The working directory for commands to run in.")
 /**
   * The working directory for commands to run in.  
  **/
  private String dir = null;

  @ApiModelProperty(value = "The user inside the container.")
 /**
   * The user inside the container.  
  **/
  private String user = null;

  @ApiModelProperty(value = "A list of additional groups that the container process will run as.")
 /**
   * A list of additional groups that the container process will run as.  
  **/
  private List<String> groups = null;

  @ApiModelProperty(value = "")
  private TaskSpecContainerSpecPrivileges privileges = null;

  @ApiModelProperty(value = "Whether a pseudo-TTY should be allocated.")
 /**
   * Whether a pseudo-TTY should be allocated.  
  **/
  private Boolean TTY = null;

  @ApiModelProperty(value = "Open `stdin`")
 /**
   * Open `stdin`  
  **/
  private Boolean openStdin = null;

  @ApiModelProperty(value = "Mount the container's root filesystem as read only.")
 /**
   * Mount the container's root filesystem as read only.  
  **/
  private Boolean readOnly = null;

  @ApiModelProperty(value = "Specification for mounts to be added to containers created as part of the service.")
 /**
   * Specification for mounts to be added to containers created as part of the service.  
  **/
  private List<Mount> mounts = null;

  @ApiModelProperty(value = "Signal to stop the container.")
 /**
   * Signal to stop the container.  
  **/
  private String stopSignal = null;

  @ApiModelProperty(value = "Amount of time to wait for the container to terminate before forcefully killing it.")
 /**
   * Amount of time to wait for the container to terminate before forcefully killing it.  
  **/
  private Long stopGracePeriod = null;

  @ApiModelProperty(value = "")
  private HealthConfig healthCheck = null;

  @ApiModelProperty(value = "A list of hostname/IP mappings to add to the container's `hosts` file. The format of extra hosts is specified in the [hosts(5)](http://man7.org/linux/man-pages/man5/hosts.5.html) man page:      IP_address canonical_hostname [aliases...] ")
 /**
   * A list of hostname/IP mappings to add to the container's `hosts` file. The format of extra hosts is specified in the [hosts(5)](http://man7.org/linux/man-pages/man5/hosts.5.html) man page:      IP_address canonical_hostname [aliases...]   
  **/
  private List<String> hosts = null;

  @ApiModelProperty(value = "")
  private TaskSpecContainerSpecDNSConfig dnSConfig = null;

  @ApiModelProperty(value = "Secrets contains references to zero or more secrets that will be exposed to the service.")
 /**
   * Secrets contains references to zero or more secrets that will be exposed to the service.  
  **/
  private List<TaskSpecContainerSpecSecrets> secrets = null;

  @ApiModelProperty(value = "Configs contains references to zero or more configs that will be exposed to the service.")
 /**
   * Configs contains references to zero or more configs that will be exposed to the service.  
  **/
  private List<TaskSpecContainerSpecConfigs> configs = null;


@XmlType(name="IsolationEnum")
@XmlEnum(String.class)
public enum IsolationEnum {

@XmlEnumValue("default") DEFAULT(String.valueOf("default")), @XmlEnumValue("process") PROCESS(String.valueOf("process")), @XmlEnumValue("hyperv") HYPERV(String.valueOf("hyperv"));


    private String value;

    IsolationEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static IsolationEnum fromValue(String v) {
        for (IsolationEnum b : IsolationEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(value = "Isolation technology of the containers running the service. (Windows only)")
 /**
   * Isolation technology of the containers running the service. (Windows only)  
  **/
  private IsolationEnum isolation = null;

  @ApiModelProperty(value = "Run an init inside the container that forwards signals and reaps processes. This field is omitted if empty, and the default (as configured on the daemon) is used.")
 /**
   * Run an init inside the container that forwards signals and reaps processes. This field is omitted if empty, and the default (as configured on the daemon) is used.  
  **/
  private Boolean init = null;
 /**
   * The image name to use for the container
   * @return image
  **/
  @JsonProperty("Image")
  public String getImage() {
    return image;
  }

  public void setImage(String image) {
    this.image = image;
  }

  public TaskSpecContainerSpec image(String image) {
    this.image = image;
    return this;
  }

 /**
   * User-defined key/value data.
   * @return labels
  **/
  @JsonProperty("Labels")
  public Map<String, String> getLabels() {
    return labels;
  }

  public void setLabels(Map<String, String> labels) {
    this.labels = labels;
  }

  public TaskSpecContainerSpec labels(Map<String, String> labels) {
    this.labels = labels;
    return this;
  }

  public TaskSpecContainerSpec putLabelsItem(String key, String labelsItem) {
    this.labels.put(key, labelsItem);
    return this;
  }

 /**
   * The command to be run in the image.
   * @return command
  **/
  @JsonProperty("Command")
  public List<String> getCommand() {
    return command;
  }

  public void setCommand(List<String> command) {
    this.command = command;
  }

  public TaskSpecContainerSpec command(List<String> command) {
    this.command = command;
    return this;
  }

  public TaskSpecContainerSpec addCommandItem(String commandItem) {
    this.command.add(commandItem);
    return this;
  }

 /**
   * Arguments to the command.
   * @return args
  **/
  @JsonProperty("Args")
  public List<String> getArgs() {
    return args;
  }

  public void setArgs(List<String> args) {
    this.args = args;
  }

  public TaskSpecContainerSpec args(List<String> args) {
    this.args = args;
    return this;
  }

  public TaskSpecContainerSpec addArgsItem(String argsItem) {
    this.args.add(argsItem);
    return this;
  }

 /**
   * The hostname to use for the container, as a valid RFC 1123 hostname.
   * @return hostname
  **/
  @JsonProperty("Hostname")
  public String getHostname() {
    return hostname;
  }

  public void setHostname(String hostname) {
    this.hostname = hostname;
  }

  public TaskSpecContainerSpec hostname(String hostname) {
    this.hostname = hostname;
    return this;
  }

 /**
   * A list of environment variables in the form &#x60;VAR&#x3D;value&#x60;.
   * @return env
  **/
  @JsonProperty("Env")
  public List<String> getEnv() {
    return env;
  }

  public void setEnv(List<String> env) {
    this.env = env;
  }

  public TaskSpecContainerSpec env(List<String> env) {
    this.env = env;
    return this;
  }

  public TaskSpecContainerSpec addEnvItem(String envItem) {
    this.env.add(envItem);
    return this;
  }

 /**
   * The working directory for commands to run in.
   * @return dir
  **/
  @JsonProperty("Dir")
  public String getDir() {
    return dir;
  }

  public void setDir(String dir) {
    this.dir = dir;
  }

  public TaskSpecContainerSpec dir(String dir) {
    this.dir = dir;
    return this;
  }

 /**
   * The user inside the container.
   * @return user
  **/
  @JsonProperty("User")
  public String getUser() {
    return user;
  }

  public void setUser(String user) {
    this.user = user;
  }

  public TaskSpecContainerSpec user(String user) {
    this.user = user;
    return this;
  }

 /**
   * A list of additional groups that the container process will run as.
   * @return groups
  **/
  @JsonProperty("Groups")
  public List<String> getGroups() {
    return groups;
  }

  public void setGroups(List<String> groups) {
    this.groups = groups;
  }

  public TaskSpecContainerSpec groups(List<String> groups) {
    this.groups = groups;
    return this;
  }

  public TaskSpecContainerSpec addGroupsItem(String groupsItem) {
    this.groups.add(groupsItem);
    return this;
  }

 /**
   * Get privileges
   * @return privileges
  **/
  @JsonProperty("Privileges")
  public TaskSpecContainerSpecPrivileges getPrivileges() {
    return privileges;
  }

  public void setPrivileges(TaskSpecContainerSpecPrivileges privileges) {
    this.privileges = privileges;
  }

  public TaskSpecContainerSpec privileges(TaskSpecContainerSpecPrivileges privileges) {
    this.privileges = privileges;
    return this;
  }

 /**
   * Whether a pseudo-TTY should be allocated.
   * @return TTY
  **/
  @JsonProperty("TTY")
  public Boolean isTTY() {
    return TTY;
  }

  public void setTTY(Boolean TTY) {
    this.TTY = TTY;
  }

  public TaskSpecContainerSpec TTY(Boolean TTY) {
    this.TTY = TTY;
    return this;
  }

 /**
   * Open &#x60;stdin&#x60;
   * @return openStdin
  **/
  @JsonProperty("OpenStdin")
  public Boolean isOpenStdin() {
    return openStdin;
  }

  public void setOpenStdin(Boolean openStdin) {
    this.openStdin = openStdin;
  }

  public TaskSpecContainerSpec openStdin(Boolean openStdin) {
    this.openStdin = openStdin;
    return this;
  }

 /**
   * Mount the container&#39;s root filesystem as read only.
   * @return readOnly
  **/
  @JsonProperty("ReadOnly")
  public Boolean isReadOnly() {
    return readOnly;
  }

  public void setReadOnly(Boolean readOnly) {
    this.readOnly = readOnly;
  }

  public TaskSpecContainerSpec readOnly(Boolean readOnly) {
    this.readOnly = readOnly;
    return this;
  }

 /**
   * Specification for mounts to be added to containers created as part of the service.
   * @return mounts
  **/
  @JsonProperty("Mounts")
  public List<Mount> getMounts() {
    return mounts;
  }

  public void setMounts(List<Mount> mounts) {
    this.mounts = mounts;
  }

  public TaskSpecContainerSpec mounts(List<Mount> mounts) {
    this.mounts = mounts;
    return this;
  }

  public TaskSpecContainerSpec addMountsItem(Mount mountsItem) {
    this.mounts.add(mountsItem);
    return this;
  }

 /**
   * Signal to stop the container.
   * @return stopSignal
  **/
  @JsonProperty("StopSignal")
  public String getStopSignal() {
    return stopSignal;
  }

  public void setStopSignal(String stopSignal) {
    this.stopSignal = stopSignal;
  }

  public TaskSpecContainerSpec stopSignal(String stopSignal) {
    this.stopSignal = stopSignal;
    return this;
  }

 /**
   * Amount of time to wait for the container to terminate before forcefully killing it.
   * @return stopGracePeriod
  **/
  @JsonProperty("StopGracePeriod")
  public Long getStopGracePeriod() {
    return stopGracePeriod;
  }

  public void setStopGracePeriod(Long stopGracePeriod) {
    this.stopGracePeriod = stopGracePeriod;
  }

  public TaskSpecContainerSpec stopGracePeriod(Long stopGracePeriod) {
    this.stopGracePeriod = stopGracePeriod;
    return this;
  }

 /**
   * Get healthCheck
   * @return healthCheck
  **/
  @JsonProperty("HealthCheck")
  public HealthConfig getHealthCheck() {
    return healthCheck;
  }

  public void setHealthCheck(HealthConfig healthCheck) {
    this.healthCheck = healthCheck;
  }

  public TaskSpecContainerSpec healthCheck(HealthConfig healthCheck) {
    this.healthCheck = healthCheck;
    return this;
  }

 /**
   * A list of hostname/IP mappings to add to the container&#39;s &#x60;hosts&#x60; file. The format of extra hosts is specified in the [hosts(5)](http://man7.org/linux/man-pages/man5/hosts.5.html) man page:      IP_address canonical_hostname [aliases...] 
   * @return hosts
  **/
  @JsonProperty("Hosts")
  public List<String> getHosts() {
    return hosts;
  }

  public void setHosts(List<String> hosts) {
    this.hosts = hosts;
  }

  public TaskSpecContainerSpec hosts(List<String> hosts) {
    this.hosts = hosts;
    return this;
  }

  public TaskSpecContainerSpec addHostsItem(String hostsItem) {
    this.hosts.add(hostsItem);
    return this;
  }

 /**
   * Get dnSConfig
   * @return dnSConfig
  **/
  @JsonProperty("DNSConfig")
  public TaskSpecContainerSpecDNSConfig getDnSConfig() {
    return dnSConfig;
  }

  public void setDnSConfig(TaskSpecContainerSpecDNSConfig dnSConfig) {
    this.dnSConfig = dnSConfig;
  }

  public TaskSpecContainerSpec dnSConfig(TaskSpecContainerSpecDNSConfig dnSConfig) {
    this.dnSConfig = dnSConfig;
    return this;
  }

 /**
   * Secrets contains references to zero or more secrets that will be exposed to the service.
   * @return secrets
  **/
  @JsonProperty("Secrets")
  public List<TaskSpecContainerSpecSecrets> getSecrets() {
    return secrets;
  }

  public void setSecrets(List<TaskSpecContainerSpecSecrets> secrets) {
    this.secrets = secrets;
  }

  public TaskSpecContainerSpec secrets(List<TaskSpecContainerSpecSecrets> secrets) {
    this.secrets = secrets;
    return this;
  }

  public TaskSpecContainerSpec addSecretsItem(TaskSpecContainerSpecSecrets secretsItem) {
    this.secrets.add(secretsItem);
    return this;
  }

 /**
   * Configs contains references to zero or more configs that will be exposed to the service.
   * @return configs
  **/
  @JsonProperty("Configs")
  public List<TaskSpecContainerSpecConfigs> getConfigs() {
    return configs;
  }

  public void setConfigs(List<TaskSpecContainerSpecConfigs> configs) {
    this.configs = configs;
  }

  public TaskSpecContainerSpec configs(List<TaskSpecContainerSpecConfigs> configs) {
    this.configs = configs;
    return this;
  }

  public TaskSpecContainerSpec addConfigsItem(TaskSpecContainerSpecConfigs configsItem) {
    this.configs.add(configsItem);
    return this;
  }

 /**
   * Isolation technology of the containers running the service. (Windows only)
   * @return isolation
  **/
  @JsonProperty("Isolation")
  public String getIsolation() {
    if (isolation == null) {
      return null;
    }
    return isolation.value();
  }

  public void setIsolation(IsolationEnum isolation) {
    this.isolation = isolation;
  }

  public TaskSpecContainerSpec isolation(IsolationEnum isolation) {
    this.isolation = isolation;
    return this;
  }

 /**
   * Run an init inside the container that forwards signals and reaps processes. This field is omitted if empty, and the default (as configured on the daemon) is used.
   * @return init
  **/
  @JsonProperty("Init")
  public Boolean isInit() {
    return init;
  }

  public void setInit(Boolean init) {
    this.init = init;
  }

  public TaskSpecContainerSpec init(Boolean init) {
    this.init = init;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TaskSpecContainerSpec {\n");
    
    sb.append("    image: ").append(toIndentedString(image)).append("\n");
    sb.append("    labels: ").append(toIndentedString(labels)).append("\n");
    sb.append("    command: ").append(toIndentedString(command)).append("\n");
    sb.append("    args: ").append(toIndentedString(args)).append("\n");
    sb.append("    hostname: ").append(toIndentedString(hostname)).append("\n");
    sb.append("    env: ").append(toIndentedString(env)).append("\n");
    sb.append("    dir: ").append(toIndentedString(dir)).append("\n");
    sb.append("    user: ").append(toIndentedString(user)).append("\n");
    sb.append("    groups: ").append(toIndentedString(groups)).append("\n");
    sb.append("    privileges: ").append(toIndentedString(privileges)).append("\n");
    sb.append("    TTY: ").append(toIndentedString(TTY)).append("\n");
    sb.append("    openStdin: ").append(toIndentedString(openStdin)).append("\n");
    sb.append("    readOnly: ").append(toIndentedString(readOnly)).append("\n");
    sb.append("    mounts: ").append(toIndentedString(mounts)).append("\n");
    sb.append("    stopSignal: ").append(toIndentedString(stopSignal)).append("\n");
    sb.append("    stopGracePeriod: ").append(toIndentedString(stopGracePeriod)).append("\n");
    sb.append("    healthCheck: ").append(toIndentedString(healthCheck)).append("\n");
    sb.append("    hosts: ").append(toIndentedString(hosts)).append("\n");
    sb.append("    dnSConfig: ").append(toIndentedString(dnSConfig)).append("\n");
    sb.append("    secrets: ").append(toIndentedString(secrets)).append("\n");
    sb.append("    configs: ").append(toIndentedString(configs)).append("\n");
    sb.append("    isolation: ").append(toIndentedString(isolation)).append("\n");
    sb.append("    init: ").append(toIndentedString(init)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

