package io.swagger.api;

import io.swagger.model.ErrorResponse;
import io.swagger.model.ExecConfig;
import io.swagger.model.ExecInspectResponse;
import io.swagger.model.ExecStartConfig;
import io.swagger.model.IdResponse;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import org.apache.cxf.jaxrs.ext.multipart.*;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.ApiResponse;
import io.swagger.jaxrs.PATCH;

/**
 * Docker Engine API
 *
 * <p>The Engine API is an HTTP API served by Docker Engine. It is the API the Docker client uses to communicate with the Engine, so everything the Docker client can do can be done with the API.  Most of the client's commands map directly to API endpoints (e.g. `docker ps` is `GET /containers/json`). The notable exception is running containers, which consists of several API calls.  # Errors  The API uses standard HTTP status codes to indicate the success or failure of the API call. The body of the response will be JSON in the following format:  ``` {   \"message\": \"page not found\" } ```  # Versioning  The API is usually changed in each release, so API calls are versioned to ensure that clients don't break. To lock to a specific version of the API, you prefix the URL with its version, for example, call `/v1.30/info` to use the v1.30 version of the `/info` endpoint. If the API version specified in the URL is not supported by the daemon, a HTTP `400 Bad Request` error message is returned.  If you omit the version-prefix, the current version of the API (v1.39) is used. For example, calling `/info` is the same as calling `/v1.39/info`. Using the API without a version-prefix is deprecated and will be removed in a future release.  Engine releases in the near future should support this version of the API, so your client will continue to work even if it is talking to a newer Engine.  The API uses an open schema model, which means server may add extra properties to responses. Likewise, the server will ignore any extra query parameters and request body properties. When you write clients, you need to ignore additional properties in responses to ensure they do not break when talking to newer daemons.   # Authentication  Authentication for registries is handled client side. The client has to send authentication details to various endpoints that need to communicate with registries, such as `POST /images/(name)/push`. These are sent as `X-Registry-Auth` header as a Base64 encoded (JSON) string with the following structure:  ``` {   \"username\": \"string\",   \"password\": \"string\",   \"email\": \"string\",   \"serveraddress\": \"string\" } ```  The `serveraddress` is a domain/IP without a protocol. Throughout this structure, double quotes are required.  If you have already got an identity token from the [`/auth` endpoint](#operation/SystemAuth), you can just pass this instead of credentials:  ``` {   \"identitytoken\": \"9cbaf023786cd7...\" } ``` 
 *
 */
@Path("/")
@Api(value = "/", description = "")
public interface ExecApi  {

    /**
     * Create an exec instance
     *
     * Run a command inside a running container.
     *
     */
    @POST
    @Path("/containers/{id}/exec")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Create an exec instance", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 201, message = "no error", response = IdResponse.class),
        @ApiResponse(code = 404, message = "no such container", response = ErrorResponse.class),
        @ApiResponse(code = 409, message = "container is paused", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "Server error", response = ErrorResponse.class) })
    public IdResponse containerExec(ExecConfig execConfig, @PathParam("id") String id);

    /**
     * Inspect an exec instance
     *
     * Return low-level information about an exec instance.
     *
     */
    @GET
    @Path("/exec/{id}/json")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Inspect an exec instance", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "No error", response = ExecInspectResponse.class),
        @ApiResponse(code = 404, message = "No such exec instance", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "Server error", response = ErrorResponse.class) })
    public ExecInspectResponse execInspect(@PathParam("id") String id);

    /**
     * Resize an exec instance
     *
     * Resize the TTY session used by an exec instance. This endpoint only works if &#x60;tty&#x60; was specified as part of creating and starting the exec instance.
     *
     */
    @POST
    @Path("/exec/{id}/resize")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json", "text/plain" })
    @ApiOperation(value = "Resize an exec instance", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 201, message = "No error", response = .class),
        @ApiResponse(code = 404, message = "No such exec instance", response = ErrorResponse.class) })
    public void execResize(@PathParam("id") String id, @QueryParam("h")Integer h, @QueryParam("w")Integer w);

    /**
     * Start an exec instance
     *
     * Starts a previously set up exec instance. If detach is true, this endpoint returns immediately after starting the command. Otherwise, it sets up an interactive session with the command.
     *
     */
    @POST
    @Path("/exec/{id}/start")
    @Consumes({ "application/json" })
    @Produces({ "application/vnd.docker.raw-stream" })
    @ApiOperation(value = "Start an exec instance", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "No error", response = .class),
        @ApiResponse(code = 404, message = "No such exec instance", response = ErrorResponse.class),
        @ApiResponse(code = 409, message = "Container is stopped or paused", response = ErrorResponse.class) })
    public void execStart(@PathParam("id") String id, ExecStartConfig execStartConfig);
}

