package io.swagger.model;

import io.swagger.annotations.ApiModel;
import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * EndpointIPAMConfig represents an endpoint's IPAM configuration. 
 **/
@ApiModel(description="EndpointIPAMConfig represents an endpoint's IPAM configuration. ")
public class EndpointIPAMConfig  {
  
  @ApiModelProperty(example = "172.20.30.33", value = "")
  private String ipv4Address = null;

  @ApiModelProperty(example = "2001:db8:abcd::3033", value = "")
  private String ipv6Address = null;

  @ApiModelProperty(example = "[\"169.254.34.68\",\"fe80::3468\"]", value = "")
  private List<String> linkLocalIPs = null;
 /**
   * Get ipv4Address
   * @return ipv4Address
  **/
  @JsonProperty("IPv4Address")
  public String getIpv4Address() {
    return ipv4Address;
  }

  public void setIpv4Address(String ipv4Address) {
    this.ipv4Address = ipv4Address;
  }

  public EndpointIPAMConfig ipv4Address(String ipv4Address) {
    this.ipv4Address = ipv4Address;
    return this;
  }

 /**
   * Get ipv6Address
   * @return ipv6Address
  **/
  @JsonProperty("IPv6Address")
  public String getIpv6Address() {
    return ipv6Address;
  }

  public void setIpv6Address(String ipv6Address) {
    this.ipv6Address = ipv6Address;
  }

  public EndpointIPAMConfig ipv6Address(String ipv6Address) {
    this.ipv6Address = ipv6Address;
    return this;
  }

 /**
   * Get linkLocalIPs
   * @return linkLocalIPs
  **/
  @JsonProperty("LinkLocalIPs")
  public List<String> getLinkLocalIPs() {
    return linkLocalIPs;
  }

  public void setLinkLocalIPs(List<String> linkLocalIPs) {
    this.linkLocalIPs = linkLocalIPs;
  }

  public EndpointIPAMConfig linkLocalIPs(List<String> linkLocalIPs) {
    this.linkLocalIPs = linkLocalIPs;
    return this;
  }

  public EndpointIPAMConfig addLinkLocalIPsItem(String linkLocalIPsItem) {
    this.linkLocalIPs.add(linkLocalIPsItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class EndpointIPAMConfig {\n");
    
    sb.append("    ipv4Address: ").append(toIndentedString(ipv4Address)).append("\n");
    sb.append("    ipv6Address: ").append(toIndentedString(ipv6Address)).append("\n");
    sb.append("    linkLocalIPs: ").append(toIndentedString(linkLocalIPs)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

