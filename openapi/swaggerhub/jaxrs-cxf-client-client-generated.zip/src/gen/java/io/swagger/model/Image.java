package io.swagger.model;

import io.swagger.model.ContainerConfig;
import io.swagger.model.GraphDriverData;
import io.swagger.model.ImageMetadata;
import io.swagger.model.ImageRootFS;
import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Image  {
  
  @ApiModelProperty(required = true, value = "")
  private String id = null;

  @ApiModelProperty(value = "")
  private List<String> repoTags = null;

  @ApiModelProperty(value = "")
  private List<String> repoDigests = null;

  @ApiModelProperty(required = true, value = "")
  private String parent = null;

  @ApiModelProperty(required = true, value = "")
  private String comment = null;

  @ApiModelProperty(required = true, value = "")
  private String created = null;

  @ApiModelProperty(required = true, value = "")
  private String container = null;

  @ApiModelProperty(value = "")
  private ContainerConfig containerConfig = null;

  @ApiModelProperty(required = true, value = "")
  private String dockerVersion = null;

  @ApiModelProperty(required = true, value = "")
  private String author = null;

  @ApiModelProperty(value = "")
  private ContainerConfig config = null;

  @ApiModelProperty(required = true, value = "")
  private String architecture = null;

  @ApiModelProperty(required = true, value = "")
  private String os = null;

  @ApiModelProperty(value = "")
  private String osVersion = null;

  @ApiModelProperty(required = true, value = "")
  private Long size = null;

  @ApiModelProperty(required = true, value = "")
  private Long virtualSize = null;

  @ApiModelProperty(required = true, value = "")
  private GraphDriverData graphDriver = null;

  @ApiModelProperty(required = true, value = "")
  private ImageRootFS rootFS = null;

  @ApiModelProperty(value = "")
  private ImageMetadata metadata = null;
 /**
   * Get id
   * @return id
  **/
  @JsonProperty("Id")
  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public Image id(String id) {
    this.id = id;
    return this;
  }

 /**
   * Get repoTags
   * @return repoTags
  **/
  @JsonProperty("RepoTags")
  public List<String> getRepoTags() {
    return repoTags;
  }

  public void setRepoTags(List<String> repoTags) {
    this.repoTags = repoTags;
  }

  public Image repoTags(List<String> repoTags) {
    this.repoTags = repoTags;
    return this;
  }

  public Image addRepoTagsItem(String repoTagsItem) {
    this.repoTags.add(repoTagsItem);
    return this;
  }

 /**
   * Get repoDigests
   * @return repoDigests
  **/
  @JsonProperty("RepoDigests")
  public List<String> getRepoDigests() {
    return repoDigests;
  }

  public void setRepoDigests(List<String> repoDigests) {
    this.repoDigests = repoDigests;
  }

  public Image repoDigests(List<String> repoDigests) {
    this.repoDigests = repoDigests;
    return this;
  }

  public Image addRepoDigestsItem(String repoDigestsItem) {
    this.repoDigests.add(repoDigestsItem);
    return this;
  }

 /**
   * Get parent
   * @return parent
  **/
  @JsonProperty("Parent")
  public String getParent() {
    return parent;
  }

  public void setParent(String parent) {
    this.parent = parent;
  }

  public Image parent(String parent) {
    this.parent = parent;
    return this;
  }

 /**
   * Get comment
   * @return comment
  **/
  @JsonProperty("Comment")
  public String getComment() {
    return comment;
  }

  public void setComment(String comment) {
    this.comment = comment;
  }

  public Image comment(String comment) {
    this.comment = comment;
    return this;
  }

 /**
   * Get created
   * @return created
  **/
  @JsonProperty("Created")
  public String getCreated() {
    return created;
  }

  public void setCreated(String created) {
    this.created = created;
  }

  public Image created(String created) {
    this.created = created;
    return this;
  }

 /**
   * Get container
   * @return container
  **/
  @JsonProperty("Container")
  public String getContainer() {
    return container;
  }

  public void setContainer(String container) {
    this.container = container;
  }

  public Image container(String container) {
    this.container = container;
    return this;
  }

 /**
   * Get containerConfig
   * @return containerConfig
  **/
  @JsonProperty("ContainerConfig")
  public ContainerConfig getContainerConfig() {
    return containerConfig;
  }

  public void setContainerConfig(ContainerConfig containerConfig) {
    this.containerConfig = containerConfig;
  }

  public Image containerConfig(ContainerConfig containerConfig) {
    this.containerConfig = containerConfig;
    return this;
  }

 /**
   * Get dockerVersion
   * @return dockerVersion
  **/
  @JsonProperty("DockerVersion")
  public String getDockerVersion() {
    return dockerVersion;
  }

  public void setDockerVersion(String dockerVersion) {
    this.dockerVersion = dockerVersion;
  }

  public Image dockerVersion(String dockerVersion) {
    this.dockerVersion = dockerVersion;
    return this;
  }

 /**
   * Get author
   * @return author
  **/
  @JsonProperty("Author")
  public String getAuthor() {
    return author;
  }

  public void setAuthor(String author) {
    this.author = author;
  }

  public Image author(String author) {
    this.author = author;
    return this;
  }

 /**
   * Get config
   * @return config
  **/
  @JsonProperty("Config")
  public ContainerConfig getConfig() {
    return config;
  }

  public void setConfig(ContainerConfig config) {
    this.config = config;
  }

  public Image config(ContainerConfig config) {
    this.config = config;
    return this;
  }

 /**
   * Get architecture
   * @return architecture
  **/
  @JsonProperty("Architecture")
  public String getArchitecture() {
    return architecture;
  }

  public void setArchitecture(String architecture) {
    this.architecture = architecture;
  }

  public Image architecture(String architecture) {
    this.architecture = architecture;
    return this;
  }

 /**
   * Get os
   * @return os
  **/
  @JsonProperty("Os")
  public String getOs() {
    return os;
  }

  public void setOs(String os) {
    this.os = os;
  }

  public Image os(String os) {
    this.os = os;
    return this;
  }

 /**
   * Get osVersion
   * @return osVersion
  **/
  @JsonProperty("OsVersion")
  public String getOsVersion() {
    return osVersion;
  }

  public void setOsVersion(String osVersion) {
    this.osVersion = osVersion;
  }

  public Image osVersion(String osVersion) {
    this.osVersion = osVersion;
    return this;
  }

 /**
   * Get size
   * @return size
  **/
  @JsonProperty("Size")
  public Long getSize() {
    return size;
  }

  public void setSize(Long size) {
    this.size = size;
  }

  public Image size(Long size) {
    this.size = size;
    return this;
  }

 /**
   * Get virtualSize
   * @return virtualSize
  **/
  @JsonProperty("VirtualSize")
  public Long getVirtualSize() {
    return virtualSize;
  }

  public void setVirtualSize(Long virtualSize) {
    this.virtualSize = virtualSize;
  }

  public Image virtualSize(Long virtualSize) {
    this.virtualSize = virtualSize;
    return this;
  }

 /**
   * Get graphDriver
   * @return graphDriver
  **/
  @JsonProperty("GraphDriver")
  public GraphDriverData getGraphDriver() {
    return graphDriver;
  }

  public void setGraphDriver(GraphDriverData graphDriver) {
    this.graphDriver = graphDriver;
  }

  public Image graphDriver(GraphDriverData graphDriver) {
    this.graphDriver = graphDriver;
    return this;
  }

 /**
   * Get rootFS
   * @return rootFS
  **/
  @JsonProperty("RootFS")
  public ImageRootFS getRootFS() {
    return rootFS;
  }

  public void setRootFS(ImageRootFS rootFS) {
    this.rootFS = rootFS;
  }

  public Image rootFS(ImageRootFS rootFS) {
    this.rootFS = rootFS;
    return this;
  }

 /**
   * Get metadata
   * @return metadata
  **/
  @JsonProperty("Metadata")
  public ImageMetadata getMetadata() {
    return metadata;
  }

  public void setMetadata(ImageMetadata metadata) {
    this.metadata = metadata;
  }

  public Image metadata(ImageMetadata metadata) {
    this.metadata = metadata;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Image {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    repoTags: ").append(toIndentedString(repoTags)).append("\n");
    sb.append("    repoDigests: ").append(toIndentedString(repoDigests)).append("\n");
    sb.append("    parent: ").append(toIndentedString(parent)).append("\n");
    sb.append("    comment: ").append(toIndentedString(comment)).append("\n");
    sb.append("    created: ").append(toIndentedString(created)).append("\n");
    sb.append("    container: ").append(toIndentedString(container)).append("\n");
    sb.append("    containerConfig: ").append(toIndentedString(containerConfig)).append("\n");
    sb.append("    dockerVersion: ").append(toIndentedString(dockerVersion)).append("\n");
    sb.append("    author: ").append(toIndentedString(author)).append("\n");
    sb.append("    config: ").append(toIndentedString(config)).append("\n");
    sb.append("    architecture: ").append(toIndentedString(architecture)).append("\n");
    sb.append("    os: ").append(toIndentedString(os)).append("\n");
    sb.append("    osVersion: ").append(toIndentedString(osVersion)).append("\n");
    sb.append("    size: ").append(toIndentedString(size)).append("\n");
    sb.append("    virtualSize: ").append(toIndentedString(virtualSize)).append("\n");
    sb.append("    graphDriver: ").append(toIndentedString(graphDriver)).append("\n");
    sb.append("    rootFS: ").append(toIndentedString(rootFS)).append("\n");
    sb.append("    metadata: ").append(toIndentedString(metadata)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

