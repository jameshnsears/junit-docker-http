package io.swagger.model;

import io.swagger.annotations.ApiModel;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * Optional configuration for the `bind` type.
 **/
@ApiModel(description="Optional configuration for the `bind` type.")
public class MountBindOptions  {
  

@XmlType(name="PropagationEnum")
@XmlEnum(String.class)
public enum PropagationEnum {

@XmlEnumValue("private") PRIVATE(String.valueOf("private")), @XmlEnumValue("rprivate") RPRIVATE(String.valueOf("rprivate")), @XmlEnumValue("shared") SHARED(String.valueOf("shared")), @XmlEnumValue("rshared") RSHARED(String.valueOf("rshared")), @XmlEnumValue("slave") SLAVE(String.valueOf("slave")), @XmlEnumValue("rslave") RSLAVE(String.valueOf("rslave"));


    private String value;

    PropagationEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static PropagationEnum fromValue(String v) {
        for (PropagationEnum b : PropagationEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(value = "A propagation mode with the value `[r]private`, `[r]shared`, or `[r]slave`.")
 /**
   * A propagation mode with the value `[r]private`, `[r]shared`, or `[r]slave`.  
  **/
  private PropagationEnum propagation = null;
 /**
   * A propagation mode with the value &#x60;[r]private&#x60;, &#x60;[r]shared&#x60;, or &#x60;[r]slave&#x60;.
   * @return propagation
  **/
  @JsonProperty("Propagation")
  public String getPropagation() {
    if (propagation == null) {
      return null;
    }
    return propagation.value();
  }

  public void setPropagation(PropagationEnum propagation) {
    this.propagation = propagation;
  }

  public MountBindOptions propagation(PropagationEnum propagation) {
    this.propagation = propagation;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class MountBindOptions {\n");
    
    sb.append("    propagation: ").append(toIndentedString(propagation)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

