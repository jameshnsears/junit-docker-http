package io.swagger.model;

import io.swagger.annotations.ApiModel;
import io.swagger.model.PluginConfig;
import io.swagger.model.PluginSettings;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * A plugin for the Engine API
 **/
@ApiModel(description="A plugin for the Engine API")
public class Plugin  {
  
  @ApiModelProperty(example = "5724e2c8652da337ab2eedd19fc6fc0ec908e4bd907c7421bf6a8dfc70c4c078", value = "")
  private String id = null;

  @ApiModelProperty(example = "tiborvass/sample-volume-plugin", required = true, value = "")
  private String name = null;

  @ApiModelProperty(example = "true", required = true, value = "True if the plugin is running. False if the plugin is not running, only installed.")
 /**
   * True if the plugin is running. False if the plugin is not running, only installed.  
  **/
  private Boolean enabled = null;

  @ApiModelProperty(required = true, value = "")
  private PluginSettings settings = null;

  @ApiModelProperty(example = "localhost:5000/tiborvass/sample-volume-plugin:latest", value = "plugin remote reference used to push/pull the plugin")
 /**
   * plugin remote reference used to push/pull the plugin  
  **/
  private String pluginReference = null;

  @ApiModelProperty(required = true, value = "")
  private PluginConfig config = null;
 /**
   * Get id
   * @return id
  **/
  @JsonProperty("Id")
  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public Plugin id(String id) {
    this.id = id;
    return this;
  }

 /**
   * Get name
   * @return name
  **/
  @JsonProperty("Name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Plugin name(String name) {
    this.name = name;
    return this;
  }

 /**
   * True if the plugin is running. False if the plugin is not running, only installed.
   * @return enabled
  **/
  @JsonProperty("Enabled")
  public Boolean isEnabled() {
    return enabled;
  }

  public void setEnabled(Boolean enabled) {
    this.enabled = enabled;
  }

  public Plugin enabled(Boolean enabled) {
    this.enabled = enabled;
    return this;
  }

 /**
   * Get settings
   * @return settings
  **/
  @JsonProperty("Settings")
  public PluginSettings getSettings() {
    return settings;
  }

  public void setSettings(PluginSettings settings) {
    this.settings = settings;
  }

  public Plugin settings(PluginSettings settings) {
    this.settings = settings;
    return this;
  }

 /**
   * plugin remote reference used to push/pull the plugin
   * @return pluginReference
  **/
  @JsonProperty("PluginReference")
  public String getPluginReference() {
    return pluginReference;
  }

  public void setPluginReference(String pluginReference) {
    this.pluginReference = pluginReference;
  }

  public Plugin pluginReference(String pluginReference) {
    this.pluginReference = pluginReference;
    return this;
  }

 /**
   * Get config
   * @return config
  **/
  @JsonProperty("Config")
  public PluginConfig getConfig() {
    return config;
  }

  public void setConfig(PluginConfig config) {
    this.config = config;
  }

  public Plugin config(PluginConfig config) {
    this.config = config;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Plugin {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    enabled: ").append(toIndentedString(enabled)).append("\n");
    sb.append("    settings: ").append(toIndentedString(settings)).append("\n");
    sb.append("    pluginReference: ").append(toIndentedString(pluginReference)).append("\n");
    sb.append("    config: ").append(toIndentedString(config)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

