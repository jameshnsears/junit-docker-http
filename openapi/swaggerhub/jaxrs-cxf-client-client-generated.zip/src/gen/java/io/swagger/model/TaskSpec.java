package io.swagger.model;

import io.swagger.annotations.ApiModel;
import io.swagger.model.TaskSpecContainerSpec;
import io.swagger.model.TaskSpecLogDriver;
import io.swagger.model.TaskSpecNetworkAttachmentSpec;
import io.swagger.model.TaskSpecNetworks;
import io.swagger.model.TaskSpecPlacement;
import io.swagger.model.TaskSpecPluginSpec;
import io.swagger.model.TaskSpecResources;
import io.swagger.model.TaskSpecRestartPolicy;
import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * User modifiable task configuration.
 **/
@ApiModel(description="User modifiable task configuration.")
public class TaskSpec  {
  
  @ApiModelProperty(value = "")
  private TaskSpecPluginSpec pluginSpec = null;

  @ApiModelProperty(value = "")
  private TaskSpecContainerSpec containerSpec = null;

  @ApiModelProperty(value = "")
  private TaskSpecNetworkAttachmentSpec networkAttachmentSpec = null;

  @ApiModelProperty(value = "")
  private TaskSpecResources resources = null;

  @ApiModelProperty(value = "")
  private TaskSpecRestartPolicy restartPolicy = null;

  @ApiModelProperty(value = "")
  private TaskSpecPlacement placement = null;

  @ApiModelProperty(value = "A counter that triggers an update even if no relevant parameters have been changed.")
 /**
   * A counter that triggers an update even if no relevant parameters have been changed.  
  **/
  private Integer forceUpdate = null;

  @ApiModelProperty(value = "Runtime is the type of runtime specified for the task executor.")
 /**
   * Runtime is the type of runtime specified for the task executor.  
  **/
  private String runtime = null;

  @ApiModelProperty(value = "")
  private List<TaskSpecNetworks> networks = null;

  @ApiModelProperty(value = "")
  private TaskSpecLogDriver logDriver = null;
 /**
   * Get pluginSpec
   * @return pluginSpec
  **/
  @JsonProperty("PluginSpec")
  public TaskSpecPluginSpec getPluginSpec() {
    return pluginSpec;
  }

  public void setPluginSpec(TaskSpecPluginSpec pluginSpec) {
    this.pluginSpec = pluginSpec;
  }

  public TaskSpec pluginSpec(TaskSpecPluginSpec pluginSpec) {
    this.pluginSpec = pluginSpec;
    return this;
  }

 /**
   * Get containerSpec
   * @return containerSpec
  **/
  @JsonProperty("ContainerSpec")
  public TaskSpecContainerSpec getContainerSpec() {
    return containerSpec;
  }

  public void setContainerSpec(TaskSpecContainerSpec containerSpec) {
    this.containerSpec = containerSpec;
  }

  public TaskSpec containerSpec(TaskSpecContainerSpec containerSpec) {
    this.containerSpec = containerSpec;
    return this;
  }

 /**
   * Get networkAttachmentSpec
   * @return networkAttachmentSpec
  **/
  @JsonProperty("NetworkAttachmentSpec")
  public TaskSpecNetworkAttachmentSpec getNetworkAttachmentSpec() {
    return networkAttachmentSpec;
  }

  public void setNetworkAttachmentSpec(TaskSpecNetworkAttachmentSpec networkAttachmentSpec) {
    this.networkAttachmentSpec = networkAttachmentSpec;
  }

  public TaskSpec networkAttachmentSpec(TaskSpecNetworkAttachmentSpec networkAttachmentSpec) {
    this.networkAttachmentSpec = networkAttachmentSpec;
    return this;
  }

 /**
   * Get resources
   * @return resources
  **/
  @JsonProperty("Resources")
  public TaskSpecResources getResources() {
    return resources;
  }

  public void setResources(TaskSpecResources resources) {
    this.resources = resources;
  }

  public TaskSpec resources(TaskSpecResources resources) {
    this.resources = resources;
    return this;
  }

 /**
   * Get restartPolicy
   * @return restartPolicy
  **/
  @JsonProperty("RestartPolicy")
  public TaskSpecRestartPolicy getRestartPolicy() {
    return restartPolicy;
  }

  public void setRestartPolicy(TaskSpecRestartPolicy restartPolicy) {
    this.restartPolicy = restartPolicy;
  }

  public TaskSpec restartPolicy(TaskSpecRestartPolicy restartPolicy) {
    this.restartPolicy = restartPolicy;
    return this;
  }

 /**
   * Get placement
   * @return placement
  **/
  @JsonProperty("Placement")
  public TaskSpecPlacement getPlacement() {
    return placement;
  }

  public void setPlacement(TaskSpecPlacement placement) {
    this.placement = placement;
  }

  public TaskSpec placement(TaskSpecPlacement placement) {
    this.placement = placement;
    return this;
  }

 /**
   * A counter that triggers an update even if no relevant parameters have been changed.
   * @return forceUpdate
  **/
  @JsonProperty("ForceUpdate")
  public Integer getForceUpdate() {
    return forceUpdate;
  }

  public void setForceUpdate(Integer forceUpdate) {
    this.forceUpdate = forceUpdate;
  }

  public TaskSpec forceUpdate(Integer forceUpdate) {
    this.forceUpdate = forceUpdate;
    return this;
  }

 /**
   * Runtime is the type of runtime specified for the task executor.
   * @return runtime
  **/
  @JsonProperty("Runtime")
  public String getRuntime() {
    return runtime;
  }

  public void setRuntime(String runtime) {
    this.runtime = runtime;
  }

  public TaskSpec runtime(String runtime) {
    this.runtime = runtime;
    return this;
  }

 /**
   * Get networks
   * @return networks
  **/
  @JsonProperty("Networks")
  public List<TaskSpecNetworks> getNetworks() {
    return networks;
  }

  public void setNetworks(List<TaskSpecNetworks> networks) {
    this.networks = networks;
  }

  public TaskSpec networks(List<TaskSpecNetworks> networks) {
    this.networks = networks;
    return this;
  }

  public TaskSpec addNetworksItem(TaskSpecNetworks networksItem) {
    this.networks.add(networksItem);
    return this;
  }

 /**
   * Get logDriver
   * @return logDriver
  **/
  @JsonProperty("LogDriver")
  public TaskSpecLogDriver getLogDriver() {
    return logDriver;
  }

  public void setLogDriver(TaskSpecLogDriver logDriver) {
    this.logDriver = logDriver;
  }

  public TaskSpec logDriver(TaskSpecLogDriver logDriver) {
    this.logDriver = logDriver;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TaskSpec {\n");
    
    sb.append("    pluginSpec: ").append(toIndentedString(pluginSpec)).append("\n");
    sb.append("    containerSpec: ").append(toIndentedString(containerSpec)).append("\n");
    sb.append("    networkAttachmentSpec: ").append(toIndentedString(networkAttachmentSpec)).append("\n");
    sb.append("    resources: ").append(toIndentedString(resources)).append("\n");
    sb.append("    restartPolicy: ").append(toIndentedString(restartPolicy)).append("\n");
    sb.append("    placement: ").append(toIndentedString(placement)).append("\n");
    sb.append("    forceUpdate: ").append(toIndentedString(forceUpdate)).append("\n");
    sb.append("    runtime: ").append(toIndentedString(runtime)).append("\n");
    sb.append("    networks: ").append(toIndentedString(networks)).append("\n");
    sb.append("    logDriver: ").append(toIndentedString(logDriver)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

