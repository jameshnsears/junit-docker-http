package io.swagger.model;


import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ExecStartConfig  {
  
  @ApiModelProperty(value = "Detach from the command.")
 /**
   * Detach from the command.  
  **/
  private Boolean detach = null;

  @ApiModelProperty(value = "Allocate a pseudo-TTY.")
 /**
   * Allocate a pseudo-TTY.  
  **/
  private Boolean tty = null;
 /**
   * Detach from the command.
   * @return detach
  **/
  @JsonProperty("Detach")
  public Boolean isDetach() {
    return detach;
  }

  public void setDetach(Boolean detach) {
    this.detach = detach;
  }

  public ExecStartConfig detach(Boolean detach) {
    this.detach = detach;
    return this;
  }

 /**
   * Allocate a pseudo-TTY.
   * @return tty
  **/
  @JsonProperty("Tty")
  public Boolean isTty() {
    return tty;
  }

  public void setTty(Boolean tty) {
    this.tty = tty;
  }

  public ExecStartConfig tty(Boolean tty) {
    this.tty = tty;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ExecStartConfig {\n");
    
    sb.append("    detach: ").append(toIndentedString(detach)).append("\n");
    sb.append("    tty: ").append(toIndentedString(tty)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

