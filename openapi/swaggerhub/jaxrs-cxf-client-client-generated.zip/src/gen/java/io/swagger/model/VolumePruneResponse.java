package io.swagger.model;

import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class VolumePruneResponse  {
  
  @ApiModelProperty(value = "Volumes that were deleted")
 /**
   * Volumes that were deleted  
  **/
  private List<String> volumesDeleted = null;

  @ApiModelProperty(value = "Disk space reclaimed in bytes")
 /**
   * Disk space reclaimed in bytes  
  **/
  private Long spaceReclaimed = null;
 /**
   * Volumes that were deleted
   * @return volumesDeleted
  **/
  @JsonProperty("VolumesDeleted")
  public List<String> getVolumesDeleted() {
    return volumesDeleted;
  }

  public void setVolumesDeleted(List<String> volumesDeleted) {
    this.volumesDeleted = volumesDeleted;
  }

  public VolumePruneResponse volumesDeleted(List<String> volumesDeleted) {
    this.volumesDeleted = volumesDeleted;
    return this;
  }

  public VolumePruneResponse addVolumesDeletedItem(String volumesDeletedItem) {
    this.volumesDeleted.add(volumesDeletedItem);
    return this;
  }

 /**
   * Disk space reclaimed in bytes
   * @return spaceReclaimed
  **/
  @JsonProperty("SpaceReclaimed")
  public Long getSpaceReclaimed() {
    return spaceReclaimed;
  }

  public void setSpaceReclaimed(Long spaceReclaimed) {
    this.spaceReclaimed = spaceReclaimed;
  }

  public VolumePruneResponse spaceReclaimed(Long spaceReclaimed) {
    this.spaceReclaimed = spaceReclaimed;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class VolumePruneResponse {\n");
    
    sb.append("    volumesDeleted: ").append(toIndentedString(volumesDeleted)).append("\n");
    sb.append("    spaceReclaimed: ").append(toIndentedString(spaceReclaimed)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

