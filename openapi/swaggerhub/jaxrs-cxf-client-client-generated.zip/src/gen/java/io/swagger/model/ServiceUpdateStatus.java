package io.swagger.model;

import io.swagger.annotations.ApiModel;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * The status of a service update.
 **/
@ApiModel(description="The status of a service update.")
public class ServiceUpdateStatus  {
  

@XmlType(name="StateEnum")
@XmlEnum(String.class)
public enum StateEnum {

@XmlEnumValue("updating") UPDATING(String.valueOf("updating")), @XmlEnumValue("paused") PAUSED(String.valueOf("paused")), @XmlEnumValue("completed") COMPLETED(String.valueOf("completed"));


    private String value;

    StateEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static StateEnum fromValue(String v) {
        for (StateEnum b : StateEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(value = "")
  private StateEnum state = null;

  @ApiModelProperty(value = "")
  private String startedAt = null;

  @ApiModelProperty(value = "")
  private String completedAt = null;

  @ApiModelProperty(value = "")
  private String message = null;
 /**
   * Get state
   * @return state
  **/
  @JsonProperty("State")
  public String getState() {
    if (state == null) {
      return null;
    }
    return state.value();
  }

  public void setState(StateEnum state) {
    this.state = state;
  }

  public ServiceUpdateStatus state(StateEnum state) {
    this.state = state;
    return this;
  }

 /**
   * Get startedAt
   * @return startedAt
  **/
  @JsonProperty("StartedAt")
  public String getStartedAt() {
    return startedAt;
  }

  public void setStartedAt(String startedAt) {
    this.startedAt = startedAt;
  }

  public ServiceUpdateStatus startedAt(String startedAt) {
    this.startedAt = startedAt;
    return this;
  }

 /**
   * Get completedAt
   * @return completedAt
  **/
  @JsonProperty("CompletedAt")
  public String getCompletedAt() {
    return completedAt;
  }

  public void setCompletedAt(String completedAt) {
    this.completedAt = completedAt;
  }

  public ServiceUpdateStatus completedAt(String completedAt) {
    this.completedAt = completedAt;
    return this;
  }

 /**
   * Get message
   * @return message
  **/
  @JsonProperty("Message")
  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public ServiceUpdateStatus message(String message) {
    this.message = message;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ServiceUpdateStatus {\n");
    
    sb.append("    state: ").append(toIndentedString(state)).append("\n");
    sb.append("    startedAt: ").append(toIndentedString(startedAt)).append("\n");
    sb.append("    completedAt: ").append(toIndentedString(completedAt)).append("\n");
    sb.append("    message: ").append(toIndentedString(message)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

