package io.swagger.model;

import io.swagger.model.Driver;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ConfigSpec  {
  
  @ApiModelProperty(value = "User-defined name of the config.")
 /**
   * User-defined name of the config.  
  **/
  private String name = null;

  @ApiModelProperty(value = "User-defined key/value metadata.")
 /**
   * User-defined key/value metadata.  
  **/
  private Map<String, String> labels = null;

  @ApiModelProperty(value = "Base64-url-safe-encoded ([RFC 4648](https://tools.ietf.org/html/rfc4648#section-3.2)) config data. ")
 /**
   * Base64-url-safe-encoded ([RFC 4648](https://tools.ietf.org/html/rfc4648#section-3.2)) config data.   
  **/
  private String data = null;

  @ApiModelProperty(value = "Templating driver, if applicable  Templating controls whether and how to evaluate the config payload as a template. If no driver is set, no templating is used. ")
 /**
   * Templating driver, if applicable  Templating controls whether and how to evaluate the config payload as a template. If no driver is set, no templating is used.   
  **/
  private Driver templating = null;
 /**
   * User-defined name of the config.
   * @return name
  **/
  @JsonProperty("Name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public ConfigSpec name(String name) {
    this.name = name;
    return this;
  }

 /**
   * User-defined key/value metadata.
   * @return labels
  **/
  @JsonProperty("Labels")
  public Map<String, String> getLabels() {
    return labels;
  }

  public void setLabels(Map<String, String> labels) {
    this.labels = labels;
  }

  public ConfigSpec labels(Map<String, String> labels) {
    this.labels = labels;
    return this;
  }

  public ConfigSpec putLabelsItem(String key, String labelsItem) {
    this.labels.put(key, labelsItem);
    return this;
  }

 /**
   * Base64-url-safe-encoded ([RFC 4648](https://tools.ietf.org/html/rfc4648#section-3.2)) config data. 
   * @return data
  **/
  @JsonProperty("Data")
  public String getData() {
    return data;
  }

  public void setData(String data) {
    this.data = data;
  }

  public ConfigSpec data(String data) {
    this.data = data;
    return this;
  }

 /**
   * Templating driver, if applicable  Templating controls whether and how to evaluate the config payload as a template. If no driver is set, no templating is used. 
   * @return templating
  **/
  @JsonProperty("Templating")
  public Driver getTemplating() {
    return templating;
  }

  public void setTemplating(Driver templating) {
    this.templating = templating;
  }

  public ConfigSpec templating(Driver templating) {
    this.templating = templating;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ConfigSpec {\n");
    
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    labels: ").append(toIndentedString(labels)).append("\n");
    sb.append("    data: ").append(toIndentedString(data)).append("\n");
    sb.append("    templating: ").append(toIndentedString(templating)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

