package io.swagger.model;

import io.swagger.annotations.ApiModel;
import io.swagger.model.EndpointSpec;
import io.swagger.model.ServiceSpecMode;
import io.swagger.model.ServiceSpecRollbackConfig;
import io.swagger.model.ServiceSpecUpdateConfig;
import io.swagger.model.TaskSpec;
import io.swagger.model.TaskSpecNetworks;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * User modifiable configuration for a service.
 **/
@ApiModel(description="User modifiable configuration for a service.")
public class ServiceSpec  {
  
  @ApiModelProperty(value = "Name of the service.")
 /**
   * Name of the service.  
  **/
  private String name = null;

  @ApiModelProperty(value = "User-defined key/value metadata.")
 /**
   * User-defined key/value metadata.  
  **/
  private Map<String, String> labels = null;

  @ApiModelProperty(value = "")
  private TaskSpec taskTemplate = null;

  @ApiModelProperty(value = "")
  private ServiceSpecMode mode = null;

  @ApiModelProperty(value = "")
  private ServiceSpecUpdateConfig updateConfig = null;

  @ApiModelProperty(value = "")
  private ServiceSpecRollbackConfig rollbackConfig = null;

  @ApiModelProperty(value = "Array of network names or IDs to attach the service to.")
 /**
   * Array of network names or IDs to attach the service to.  
  **/
  private List<TaskSpecNetworks> networks = null;

  @ApiModelProperty(value = "")
  private EndpointSpec endpointSpec = null;
 /**
   * Name of the service.
   * @return name
  **/
  @JsonProperty("Name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public ServiceSpec name(String name) {
    this.name = name;
    return this;
  }

 /**
   * User-defined key/value metadata.
   * @return labels
  **/
  @JsonProperty("Labels")
  public Map<String, String> getLabels() {
    return labels;
  }

  public void setLabels(Map<String, String> labels) {
    this.labels = labels;
  }

  public ServiceSpec labels(Map<String, String> labels) {
    this.labels = labels;
    return this;
  }

  public ServiceSpec putLabelsItem(String key, String labelsItem) {
    this.labels.put(key, labelsItem);
    return this;
  }

 /**
   * Get taskTemplate
   * @return taskTemplate
  **/
  @JsonProperty("TaskTemplate")
  public TaskSpec getTaskTemplate() {
    return taskTemplate;
  }

  public void setTaskTemplate(TaskSpec taskTemplate) {
    this.taskTemplate = taskTemplate;
  }

  public ServiceSpec taskTemplate(TaskSpec taskTemplate) {
    this.taskTemplate = taskTemplate;
    return this;
  }

 /**
   * Get mode
   * @return mode
  **/
  @JsonProperty("Mode")
  public ServiceSpecMode getMode() {
    return mode;
  }

  public void setMode(ServiceSpecMode mode) {
    this.mode = mode;
  }

  public ServiceSpec mode(ServiceSpecMode mode) {
    this.mode = mode;
    return this;
  }

 /**
   * Get updateConfig
   * @return updateConfig
  **/
  @JsonProperty("UpdateConfig")
  public ServiceSpecUpdateConfig getUpdateConfig() {
    return updateConfig;
  }

  public void setUpdateConfig(ServiceSpecUpdateConfig updateConfig) {
    this.updateConfig = updateConfig;
  }

  public ServiceSpec updateConfig(ServiceSpecUpdateConfig updateConfig) {
    this.updateConfig = updateConfig;
    return this;
  }

 /**
   * Get rollbackConfig
   * @return rollbackConfig
  **/
  @JsonProperty("RollbackConfig")
  public ServiceSpecRollbackConfig getRollbackConfig() {
    return rollbackConfig;
  }

  public void setRollbackConfig(ServiceSpecRollbackConfig rollbackConfig) {
    this.rollbackConfig = rollbackConfig;
  }

  public ServiceSpec rollbackConfig(ServiceSpecRollbackConfig rollbackConfig) {
    this.rollbackConfig = rollbackConfig;
    return this;
  }

 /**
   * Array of network names or IDs to attach the service to.
   * @return networks
  **/
  @JsonProperty("Networks")
  public List<TaskSpecNetworks> getNetworks() {
    return networks;
  }

  public void setNetworks(List<TaskSpecNetworks> networks) {
    this.networks = networks;
  }

  public ServiceSpec networks(List<TaskSpecNetworks> networks) {
    this.networks = networks;
    return this;
  }

  public ServiceSpec addNetworksItem(TaskSpecNetworks networksItem) {
    this.networks.add(networksItem);
    return this;
  }

 /**
   * Get endpointSpec
   * @return endpointSpec
  **/
  @JsonProperty("EndpointSpec")
  public EndpointSpec getEndpointSpec() {
    return endpointSpec;
  }

  public void setEndpointSpec(EndpointSpec endpointSpec) {
    this.endpointSpec = endpointSpec;
  }

  public ServiceSpec endpointSpec(EndpointSpec endpointSpec) {
    this.endpointSpec = endpointSpec;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ServiceSpec {\n");
    
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    labels: ").append(toIndentedString(labels)).append("\n");
    sb.append("    taskTemplate: ").append(toIndentedString(taskTemplate)).append("\n");
    sb.append("    mode: ").append(toIndentedString(mode)).append("\n");
    sb.append("    updateConfig: ").append(toIndentedString(updateConfig)).append("\n");
    sb.append("    rollbackConfig: ").append(toIndentedString(rollbackConfig)).append("\n");
    sb.append("    networks: ").append(toIndentedString(networks)).append("\n");
    sb.append("    endpointSpec: ").append(toIndentedString(endpointSpec)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

