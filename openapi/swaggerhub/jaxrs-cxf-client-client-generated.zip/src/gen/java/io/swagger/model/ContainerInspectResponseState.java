package io.swagger.model;

import io.swagger.annotations.ApiModel;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * The state of the container.
 **/
@ApiModel(description="The state of the container.")
public class ContainerInspectResponseState  {
  

@XmlType(name="StatusEnum")
@XmlEnum(String.class)
public enum StatusEnum {

@XmlEnumValue("created") CREATED(String.valueOf("created")), @XmlEnumValue("running") RUNNING(String.valueOf("running")), @XmlEnumValue("paused") PAUSED(String.valueOf("paused")), @XmlEnumValue("restarting") RESTARTING(String.valueOf("restarting")), @XmlEnumValue("removing") REMOVING(String.valueOf("removing")), @XmlEnumValue("exited") EXITED(String.valueOf("exited")), @XmlEnumValue("dead") DEAD(String.valueOf("dead"));


    private String value;

    StatusEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static StatusEnum fromValue(String v) {
        for (StatusEnum b : StatusEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(value = "The status of the container. For example, `\"running\"` or `\"exited\"`. ")
 /**
   * The status of the container. For example, `\"running\"` or `\"exited\"`.   
  **/
  private StatusEnum status = null;

  @ApiModelProperty(value = "Whether this container is running.  Note that a running container can be _paused_. The `Running` and `Paused` booleans are not mutually exclusive:  When pausing a container (on Linux), the cgroups freezer is used to suspend all processes in the container. Freezing the process requires the process to be running. As a result, paused containers are both `Running` _and_ `Paused`.  Use the `Status` field instead to determine if a container's state is \"running\". ")
 /**
   * Whether this container is running.  Note that a running container can be _paused_. The `Running` and `Paused` booleans are not mutually exclusive:  When pausing a container (on Linux), the cgroups freezer is used to suspend all processes in the container. Freezing the process requires the process to be running. As a result, paused containers are both `Running` _and_ `Paused`.  Use the `Status` field instead to determine if a container's state is \"running\".   
  **/
  private Boolean running = null;

  @ApiModelProperty(value = "Whether this container is paused.")
 /**
   * Whether this container is paused.  
  **/
  private Boolean paused = null;

  @ApiModelProperty(value = "Whether this container is restarting.")
 /**
   * Whether this container is restarting.  
  **/
  private Boolean restarting = null;

  @ApiModelProperty(value = "Whether this container has been killed because it ran out of memory.")
 /**
   * Whether this container has been killed because it ran out of memory.  
  **/
  private Boolean ooMKilled = null;

  @ApiModelProperty(value = "")
  private Boolean dead = null;

  @ApiModelProperty(value = "The process ID of this container")
 /**
   * The process ID of this container  
  **/
  private Integer pid = null;

  @ApiModelProperty(value = "The last exit code of this container")
 /**
   * The last exit code of this container  
  **/
  private Integer exitCode = null;

  @ApiModelProperty(value = "")
  private String error = null;

  @ApiModelProperty(value = "The time when this container was last started.")
 /**
   * The time when this container was last started.  
  **/
  private String startedAt = null;

  @ApiModelProperty(value = "The time when this container last exited.")
 /**
   * The time when this container last exited.  
  **/
  private String finishedAt = null;
 /**
   * The status of the container. For example, &#x60;\&quot;running\&quot;&#x60; or &#x60;\&quot;exited\&quot;&#x60;. 
   * @return status
  **/
  @JsonProperty("Status")
  public String getStatus() {
    if (status == null) {
      return null;
    }
    return status.value();
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public ContainerInspectResponseState status(StatusEnum status) {
    this.status = status;
    return this;
  }

 /**
   * Whether this container is running.  Note that a running container can be _paused_. The &#x60;Running&#x60; and &#x60;Paused&#x60; booleans are not mutually exclusive:  When pausing a container (on Linux), the cgroups freezer is used to suspend all processes in the container. Freezing the process requires the process to be running. As a result, paused containers are both &#x60;Running&#x60; _and_ &#x60;Paused&#x60;.  Use the &#x60;Status&#x60; field instead to determine if a container&#39;s state is \&quot;running\&quot;. 
   * @return running
  **/
  @JsonProperty("Running")
  public Boolean isRunning() {
    return running;
  }

  public void setRunning(Boolean running) {
    this.running = running;
  }

  public ContainerInspectResponseState running(Boolean running) {
    this.running = running;
    return this;
  }

 /**
   * Whether this container is paused.
   * @return paused
  **/
  @JsonProperty("Paused")
  public Boolean isPaused() {
    return paused;
  }

  public void setPaused(Boolean paused) {
    this.paused = paused;
  }

  public ContainerInspectResponseState paused(Boolean paused) {
    this.paused = paused;
    return this;
  }

 /**
   * Whether this container is restarting.
   * @return restarting
  **/
  @JsonProperty("Restarting")
  public Boolean isRestarting() {
    return restarting;
  }

  public void setRestarting(Boolean restarting) {
    this.restarting = restarting;
  }

  public ContainerInspectResponseState restarting(Boolean restarting) {
    this.restarting = restarting;
    return this;
  }

 /**
   * Whether this container has been killed because it ran out of memory.
   * @return ooMKilled
  **/
  @JsonProperty("OOMKilled")
  public Boolean isOoMKilled() {
    return ooMKilled;
  }

  public void setOoMKilled(Boolean ooMKilled) {
    this.ooMKilled = ooMKilled;
  }

  public ContainerInspectResponseState ooMKilled(Boolean ooMKilled) {
    this.ooMKilled = ooMKilled;
    return this;
  }

 /**
   * Get dead
   * @return dead
  **/
  @JsonProperty("Dead")
  public Boolean isDead() {
    return dead;
  }

  public void setDead(Boolean dead) {
    this.dead = dead;
  }

  public ContainerInspectResponseState dead(Boolean dead) {
    this.dead = dead;
    return this;
  }

 /**
   * The process ID of this container
   * @return pid
  **/
  @JsonProperty("Pid")
  public Integer getPid() {
    return pid;
  }

  public void setPid(Integer pid) {
    this.pid = pid;
  }

  public ContainerInspectResponseState pid(Integer pid) {
    this.pid = pid;
    return this;
  }

 /**
   * The last exit code of this container
   * @return exitCode
  **/
  @JsonProperty("ExitCode")
  public Integer getExitCode() {
    return exitCode;
  }

  public void setExitCode(Integer exitCode) {
    this.exitCode = exitCode;
  }

  public ContainerInspectResponseState exitCode(Integer exitCode) {
    this.exitCode = exitCode;
    return this;
  }

 /**
   * Get error
   * @return error
  **/
  @JsonProperty("Error")
  public String getError() {
    return error;
  }

  public void setError(String error) {
    this.error = error;
  }

  public ContainerInspectResponseState error(String error) {
    this.error = error;
    return this;
  }

 /**
   * The time when this container was last started.
   * @return startedAt
  **/
  @JsonProperty("StartedAt")
  public String getStartedAt() {
    return startedAt;
  }

  public void setStartedAt(String startedAt) {
    this.startedAt = startedAt;
  }

  public ContainerInspectResponseState startedAt(String startedAt) {
    this.startedAt = startedAt;
    return this;
  }

 /**
   * The time when this container last exited.
   * @return finishedAt
  **/
  @JsonProperty("FinishedAt")
  public String getFinishedAt() {
    return finishedAt;
  }

  public void setFinishedAt(String finishedAt) {
    this.finishedAt = finishedAt;
  }

  public ContainerInspectResponseState finishedAt(String finishedAt) {
    this.finishedAt = finishedAt;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ContainerInspectResponseState {\n");
    
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    running: ").append(toIndentedString(running)).append("\n");
    sb.append("    paused: ").append(toIndentedString(paused)).append("\n");
    sb.append("    restarting: ").append(toIndentedString(restarting)).append("\n");
    sb.append("    ooMKilled: ").append(toIndentedString(ooMKilled)).append("\n");
    sb.append("    dead: ").append(toIndentedString(dead)).append("\n");
    sb.append("    pid: ").append(toIndentedString(pid)).append("\n");
    sb.append("    exitCode: ").append(toIndentedString(exitCode)).append("\n");
    sb.append("    error: ").append(toIndentedString(error)).append("\n");
    sb.append("    startedAt: ").append(toIndentedString(startedAt)).append("\n");
    sb.append("    finishedAt: ").append(toIndentedString(finishedAt)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

