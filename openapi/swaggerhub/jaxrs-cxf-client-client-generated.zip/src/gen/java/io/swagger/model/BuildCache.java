package io.swagger.model;


import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class BuildCache  {
  
  @ApiModelProperty(value = "")
  private String ID = null;

  @ApiModelProperty(value = "")
  private String parent = null;

  @ApiModelProperty(value = "")
  private String type = null;

  @ApiModelProperty(value = "")
  private String description = null;

  @ApiModelProperty(value = "")
  private Boolean inUse = null;

  @ApiModelProperty(value = "")
  private Boolean shared = null;

  @ApiModelProperty(value = "")
  private Integer size = null;

  @ApiModelProperty(value = "")
  private Integer createdAt = null;

  @ApiModelProperty(value = "")
  private Integer lastUsedAt = null;

  @ApiModelProperty(value = "")
  private Integer usageCount = null;
 /**
   * Get ID
   * @return ID
  **/
  @JsonProperty("ID")
  public String getID() {
    return ID;
  }

  public void setID(String ID) {
    this.ID = ID;
  }

  public BuildCache ID(String ID) {
    this.ID = ID;
    return this;
  }

 /**
   * Get parent
   * @return parent
  **/
  @JsonProperty("Parent")
  public String getParent() {
    return parent;
  }

  public void setParent(String parent) {
    this.parent = parent;
  }

  public BuildCache parent(String parent) {
    this.parent = parent;
    return this;
  }

 /**
   * Get type
   * @return type
  **/
  @JsonProperty("Type")
  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public BuildCache type(String type) {
    this.type = type;
    return this;
  }

 /**
   * Get description
   * @return description
  **/
  @JsonProperty("Description")
  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public BuildCache description(String description) {
    this.description = description;
    return this;
  }

 /**
   * Get inUse
   * @return inUse
  **/
  @JsonProperty("InUse")
  public Boolean isInUse() {
    return inUse;
  }

  public void setInUse(Boolean inUse) {
    this.inUse = inUse;
  }

  public BuildCache inUse(Boolean inUse) {
    this.inUse = inUse;
    return this;
  }

 /**
   * Get shared
   * @return shared
  **/
  @JsonProperty("Shared")
  public Boolean isShared() {
    return shared;
  }

  public void setShared(Boolean shared) {
    this.shared = shared;
  }

  public BuildCache shared(Boolean shared) {
    this.shared = shared;
    return this;
  }

 /**
   * Get size
   * @return size
  **/
  @JsonProperty("Size")
  public Integer getSize() {
    return size;
  }

  public void setSize(Integer size) {
    this.size = size;
  }

  public BuildCache size(Integer size) {
    this.size = size;
    return this;
  }

 /**
   * Get createdAt
   * @return createdAt
  **/
  @JsonProperty("CreatedAt")
  public Integer getCreatedAt() {
    return createdAt;
  }

  public void setCreatedAt(Integer createdAt) {
    this.createdAt = createdAt;
  }

  public BuildCache createdAt(Integer createdAt) {
    this.createdAt = createdAt;
    return this;
  }

 /**
   * Get lastUsedAt
   * @return lastUsedAt
  **/
  @JsonProperty("LastUsedAt")
  public Integer getLastUsedAt() {
    return lastUsedAt;
  }

  public void setLastUsedAt(Integer lastUsedAt) {
    this.lastUsedAt = lastUsedAt;
  }

  public BuildCache lastUsedAt(Integer lastUsedAt) {
    this.lastUsedAt = lastUsedAt;
    return this;
  }

 /**
   * Get usageCount
   * @return usageCount
  **/
  @JsonProperty("UsageCount")
  public Integer getUsageCount() {
    return usageCount;
  }

  public void setUsageCount(Integer usageCount) {
    this.usageCount = usageCount;
  }

  public BuildCache usageCount(Integer usageCount) {
    this.usageCount = usageCount;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BuildCache {\n");
    
    sb.append("    ID: ").append(toIndentedString(ID)).append("\n");
    sb.append("    parent: ").append(toIndentedString(parent)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("    inUse: ").append(toIndentedString(inUse)).append("\n");
    sb.append("    shared: ").append(toIndentedString(shared)).append("\n");
    sb.append("    size: ").append(toIndentedString(size)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    lastUsedAt: ").append(toIndentedString(lastUsedAt)).append("\n");
    sb.append("    usageCount: ").append(toIndentedString(usageCount)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

