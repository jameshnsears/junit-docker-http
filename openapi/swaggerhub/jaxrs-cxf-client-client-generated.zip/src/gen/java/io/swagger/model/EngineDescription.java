package io.swagger.model;

import io.swagger.annotations.ApiModel;
import io.swagger.model.EngineDescriptionPlugins;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * EngineDescription provides information about an engine.
 **/
@ApiModel(description="EngineDescription provides information about an engine.")
public class EngineDescription  {
  
  @ApiModelProperty(example = "17.06.0", value = "")
  private String engineVersion = null;

  @ApiModelProperty(example = "{\"foo\":\"bar\"}", value = "")
  private Map<String, String> labels = null;

  @ApiModelProperty(example = "[{\"Type\":\"Log\",\"Name\":\"awslogs\"},{\"Type\":\"Log\",\"Name\":\"fluentd\"},{\"Type\":\"Log\",\"Name\":\"gcplogs\"},{\"Type\":\"Log\",\"Name\":\"gelf\"},{\"Type\":\"Log\",\"Name\":\"journald\"},{\"Type\":\"Log\",\"Name\":\"json-file\"},{\"Type\":\"Log\",\"Name\":\"logentries\"},{\"Type\":\"Log\",\"Name\":\"splunk\"},{\"Type\":\"Log\",\"Name\":\"syslog\"},{\"Type\":\"Network\",\"Name\":\"bridge\"},{\"Type\":\"Network\",\"Name\":\"host\"},{\"Type\":\"Network\",\"Name\":\"ipvlan\"},{\"Type\":\"Network\",\"Name\":\"macvlan\"},{\"Type\":\"Network\",\"Name\":\"null\"},{\"Type\":\"Network\",\"Name\":\"overlay\"},{\"Type\":\"Volume\",\"Name\":\"local\"},{\"Type\":\"Volume\",\"Name\":\"localhost:5000/vieux/sshfs:latest\"},{\"Type\":\"Volume\",\"Name\":\"vieux/sshfs:latest\"}]", value = "")
  private List<EngineDescriptionPlugins> plugins = null;
 /**
   * Get engineVersion
   * @return engineVersion
  **/
  @JsonProperty("EngineVersion")
  public String getEngineVersion() {
    return engineVersion;
  }

  public void setEngineVersion(String engineVersion) {
    this.engineVersion = engineVersion;
  }

  public EngineDescription engineVersion(String engineVersion) {
    this.engineVersion = engineVersion;
    return this;
  }

 /**
   * Get labels
   * @return labels
  **/
  @JsonProperty("Labels")
  public Map<String, String> getLabels() {
    return labels;
  }

  public void setLabels(Map<String, String> labels) {
    this.labels = labels;
  }

  public EngineDescription labels(Map<String, String> labels) {
    this.labels = labels;
    return this;
  }

  public EngineDescription putLabelsItem(String key, String labelsItem) {
    this.labels.put(key, labelsItem);
    return this;
  }

 /**
   * Get plugins
   * @return plugins
  **/
  @JsonProperty("Plugins")
  public List<EngineDescriptionPlugins> getPlugins() {
    return plugins;
  }

  public void setPlugins(List<EngineDescriptionPlugins> plugins) {
    this.plugins = plugins;
  }

  public EngineDescription plugins(List<EngineDescriptionPlugins> plugins) {
    this.plugins = plugins;
    return this;
  }

  public EngineDescription addPluginsItem(EngineDescriptionPlugins pluginsItem) {
    this.plugins.add(pluginsItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class EngineDescription {\n");
    
    sb.append("    engineVersion: ").append(toIndentedString(engineVersion)).append("\n");
    sb.append("    labels: ").append(toIndentedString(labels)).append("\n");
    sb.append("    plugins: ").append(toIndentedString(plugins)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

