package io.swagger.model;

import io.swagger.annotations.ApiModel;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * Optional configuration for the `tmpfs` type.
 **/
@ApiModel(description="Optional configuration for the `tmpfs` type.")
public class MountTmpfsOptions  {
  
  @ApiModelProperty(value = "The size for the tmpfs mount in bytes.")
 /**
   * The size for the tmpfs mount in bytes.  
  **/
  private Long sizeBytes = null;

  @ApiModelProperty(value = "The permission mode for the tmpfs mount in an integer.")
 /**
   * The permission mode for the tmpfs mount in an integer.  
  **/
  private Integer mode = null;
 /**
   * The size for the tmpfs mount in bytes.
   * @return sizeBytes
  **/
  @JsonProperty("SizeBytes")
  public Long getSizeBytes() {
    return sizeBytes;
  }

  public void setSizeBytes(Long sizeBytes) {
    this.sizeBytes = sizeBytes;
  }

  public MountTmpfsOptions sizeBytes(Long sizeBytes) {
    this.sizeBytes = sizeBytes;
    return this;
  }

 /**
   * The permission mode for the tmpfs mount in an integer.
   * @return mode
  **/
  @JsonProperty("Mode")
  public Integer getMode() {
    return mode;
  }

  public void setMode(Integer mode) {
    this.mode = mode;
  }

  public MountTmpfsOptions mode(Integer mode) {
    this.mode = mode;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class MountTmpfsOptions {\n");
    
    sb.append("    sizeBytes: ").append(toIndentedString(sizeBytes)).append("\n");
    sb.append("    mode: ").append(toIndentedString(mode)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

