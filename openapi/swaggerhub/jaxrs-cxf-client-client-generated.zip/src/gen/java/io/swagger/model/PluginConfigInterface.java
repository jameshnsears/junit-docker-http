package io.swagger.model;

import io.swagger.annotations.ApiModel;
import io.swagger.model.PluginInterfaceType;
import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * The interface between Docker and the plugin
 **/
@ApiModel(description="The interface between Docker and the plugin")
public class PluginConfigInterface  {
  
  @ApiModelProperty(example = "[\"docker.volumedriver/1.0\"]", required = true, value = "")
  private List<PluginInterfaceType> types = new ArrayList<PluginInterfaceType>();

  @ApiModelProperty(example = "plugins.sock", required = true, value = "")
  private String socket = null;


@XmlType(name="ProtocolSchemeEnum")
@XmlEnum(String.class)
public enum ProtocolSchemeEnum {

@XmlEnumValue("") EMPTY(String.valueOf("")), @XmlEnumValue("moby.plugins.http/v1") MOBY_PLUGINS_HTTP_V1(String.valueOf("moby.plugins.http/v1"));


    private String value;

    ProtocolSchemeEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static ProtocolSchemeEnum fromValue(String v) {
        for (ProtocolSchemeEnum b : ProtocolSchemeEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "some.protocol/v1.0", value = "Protocol to use for clients connecting to the plugin.")
 /**
   * Protocol to use for clients connecting to the plugin.  
  **/
  private ProtocolSchemeEnum protocolScheme = null;
 /**
   * Get types
   * @return types
  **/
  @JsonProperty("Types")
  public List<PluginInterfaceType> getTypes() {
    return types;
  }

  public void setTypes(List<PluginInterfaceType> types) {
    this.types = types;
  }

  public PluginConfigInterface types(List<PluginInterfaceType> types) {
    this.types = types;
    return this;
  }

  public PluginConfigInterface addTypesItem(PluginInterfaceType typesItem) {
    this.types.add(typesItem);
    return this;
  }

 /**
   * Get socket
   * @return socket
  **/
  @JsonProperty("Socket")
  public String getSocket() {
    return socket;
  }

  public void setSocket(String socket) {
    this.socket = socket;
  }

  public PluginConfigInterface socket(String socket) {
    this.socket = socket;
    return this;
  }

 /**
   * Protocol to use for clients connecting to the plugin.
   * @return protocolScheme
  **/
  @JsonProperty("ProtocolScheme")
  public String getProtocolScheme() {
    if (protocolScheme == null) {
      return null;
    }
    return protocolScheme.value();
  }

  public void setProtocolScheme(ProtocolSchemeEnum protocolScheme) {
    this.protocolScheme = protocolScheme;
  }

  public PluginConfigInterface protocolScheme(ProtocolSchemeEnum protocolScheme) {
    this.protocolScheme = protocolScheme;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PluginConfigInterface {\n");
    
    sb.append("    types: ").append(toIndentedString(types)).append("\n");
    sb.append("    socket: ").append(toIndentedString(socket)).append("\n");
    sb.append("    protocolScheme: ").append(toIndentedString(protocolScheme)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

