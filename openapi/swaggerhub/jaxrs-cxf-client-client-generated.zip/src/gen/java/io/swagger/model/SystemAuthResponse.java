package io.swagger.model;


import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class SystemAuthResponse  {
  
  @ApiModelProperty(required = true, value = "The status of the authentication")
 /**
   * The status of the authentication  
  **/
  private String status = null;

  @ApiModelProperty(value = "An opaque token used to authenticate a user after a successful login")
 /**
   * An opaque token used to authenticate a user after a successful login  
  **/
  private String identityToken = null;
 /**
   * The status of the authentication
   * @return status
  **/
  @JsonProperty("Status")
  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public SystemAuthResponse status(String status) {
    this.status = status;
    return this;
  }

 /**
   * An opaque token used to authenticate a user after a successful login
   * @return identityToken
  **/
  @JsonProperty("IdentityToken")
  public String getIdentityToken() {
    return identityToken;
  }

  public void setIdentityToken(String identityToken) {
    this.identityToken = identityToken;
  }

  public SystemAuthResponse identityToken(String identityToken) {
    this.identityToken = identityToken;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SystemAuthResponse {\n");
    
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    identityToken: ").append(toIndentedString(identityToken)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

