package io.swagger.model;

import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class TaskSpecNetworks  {
  
  @ApiModelProperty(value = "")
  private String target = null;

  @ApiModelProperty(value = "")
  private List<String> aliases = null;
 /**
   * Get target
   * @return target
  **/
  @JsonProperty("Target")
  public String getTarget() {
    return target;
  }

  public void setTarget(String target) {
    this.target = target;
  }

  public TaskSpecNetworks target(String target) {
    this.target = target;
    return this;
  }

 /**
   * Get aliases
   * @return aliases
  **/
  @JsonProperty("Aliases")
  public List<String> getAliases() {
    return aliases;
  }

  public void setAliases(List<String> aliases) {
    this.aliases = aliases;
  }

  public TaskSpecNetworks aliases(List<String> aliases) {
    this.aliases = aliases;
    return this;
  }

  public TaskSpecNetworks addAliasesItem(String aliasesItem) {
    this.aliases.add(aliasesItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TaskSpecNetworks {\n");
    
    sb.append("    target: ").append(toIndentedString(target)).append("\n");
    sb.append("    aliases: ").append(toIndentedString(aliases)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

