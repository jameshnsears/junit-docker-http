package io.swagger.model;

import io.swagger.annotations.ApiModel;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * PortBinding represents a binding between a host IP address and a host port. 
 **/
@ApiModel(description="PortBinding represents a binding between a host IP address and a host port. ")
public class PortBinding  {
  
  @ApiModelProperty(example = "127.0.0.1", value = "Host IP address that the container's port is mapped to.")
 /**
   * Host IP address that the container's port is mapped to.  
  **/
  private String hostIp = null;

  @ApiModelProperty(example = "4443", value = "Host port number that the container's port is mapped to.")
 /**
   * Host port number that the container's port is mapped to.  
  **/
  private String hostPort = null;
 /**
   * Host IP address that the container&#39;s port is mapped to.
   * @return hostIp
  **/
  @JsonProperty("HostIp")
  public String getHostIp() {
    return hostIp;
  }

  public void setHostIp(String hostIp) {
    this.hostIp = hostIp;
  }

  public PortBinding hostIp(String hostIp) {
    this.hostIp = hostIp;
    return this;
  }

 /**
   * Host port number that the container&#39;s port is mapped to.
   * @return hostPort
  **/
  @JsonProperty("HostPort")
  public String getHostPort() {
    return hostPort;
  }

  public void setHostPort(String hostPort) {
    this.hostPort = hostPort;
  }

  public PortBinding hostPort(String hostPort) {
    this.hostPort = hostPort;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PortBinding {\n");
    
    sb.append("    hostIp: ").append(toIndentedString(hostIp)).append("\n");
    sb.append("    hostPort: ").append(toIndentedString(hostPort)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

