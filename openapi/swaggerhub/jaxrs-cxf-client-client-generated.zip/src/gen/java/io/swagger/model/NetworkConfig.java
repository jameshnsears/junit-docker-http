package io.swagger.model;

import io.swagger.model.IPAM;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class NetworkConfig  {
  
  @ApiModelProperty(required = true, value = "The network's name.")
 /**
   * The network's name.  
  **/
  private String name = null;

  @ApiModelProperty(value = "Check for networks with duplicate names. Since Network is primarily keyed based on a random ID and not on the name, and network name is strictly a user-friendly alias to the network which is uniquely identified using ID, there is no guaranteed way to check for duplicates. CheckDuplicate is there to provide a best effort checking of any networks which has the same name but it is not guaranteed to catch all name collisions.")
 /**
   * Check for networks with duplicate names. Since Network is primarily keyed based on a random ID and not on the name, and network name is strictly a user-friendly alias to the network which is uniquely identified using ID, there is no guaranteed way to check for duplicates. CheckDuplicate is there to provide a best effort checking of any networks which has the same name but it is not guaranteed to catch all name collisions.  
  **/
  private Boolean checkDuplicate = null;

  @ApiModelProperty(value = "Name of the network driver plugin to use.")
 /**
   * Name of the network driver plugin to use.  
  **/
  private String driver = "bridge";

  @ApiModelProperty(value = "Restrict external access to the network.")
 /**
   * Restrict external access to the network.  
  **/
  private Boolean internal = null;

  @ApiModelProperty(value = "Globally scoped network is manually attachable by regular containers from workers in swarm mode.")
 /**
   * Globally scoped network is manually attachable by regular containers from workers in swarm mode.  
  **/
  private Boolean attachable = null;

  @ApiModelProperty(value = "Ingress network is the network which provides the routing-mesh in swarm mode.")
 /**
   * Ingress network is the network which provides the routing-mesh in swarm mode.  
  **/
  private Boolean ingress = null;

  @ApiModelProperty(value = "Optional custom IP scheme for the network.")
 /**
   * Optional custom IP scheme for the network.  
  **/
  private IPAM IPAM = null;

  @ApiModelProperty(value = "Enable IPv6 on the network.")
 /**
   * Enable IPv6 on the network.  
  **/
  private Boolean enableIPv6 = null;

  @ApiModelProperty(value = "Network specific options to be used by the drivers.")
 /**
   * Network specific options to be used by the drivers.  
  **/
  private Map<String, String> options = null;

  @ApiModelProperty(value = "User-defined key/value metadata.")
 /**
   * User-defined key/value metadata.  
  **/
  private Map<String, String> labels = null;
 /**
   * The network&#39;s name.
   * @return name
  **/
  @JsonProperty("Name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public NetworkConfig name(String name) {
    this.name = name;
    return this;
  }

 /**
   * Check for networks with duplicate names. Since Network is primarily keyed based on a random ID and not on the name, and network name is strictly a user-friendly alias to the network which is uniquely identified using ID, there is no guaranteed way to check for duplicates. CheckDuplicate is there to provide a best effort checking of any networks which has the same name but it is not guaranteed to catch all name collisions.
   * @return checkDuplicate
  **/
  @JsonProperty("CheckDuplicate")
  public Boolean isCheckDuplicate() {
    return checkDuplicate;
  }

  public void setCheckDuplicate(Boolean checkDuplicate) {
    this.checkDuplicate = checkDuplicate;
  }

  public NetworkConfig checkDuplicate(Boolean checkDuplicate) {
    this.checkDuplicate = checkDuplicate;
    return this;
  }

 /**
   * Name of the network driver plugin to use.
   * @return driver
  **/
  @JsonProperty("Driver")
  public String getDriver() {
    return driver;
  }

  public void setDriver(String driver) {
    this.driver = driver;
  }

  public NetworkConfig driver(String driver) {
    this.driver = driver;
    return this;
  }

 /**
   * Restrict external access to the network.
   * @return internal
  **/
  @JsonProperty("Internal")
  public Boolean isInternal() {
    return internal;
  }

  public void setInternal(Boolean internal) {
    this.internal = internal;
  }

  public NetworkConfig internal(Boolean internal) {
    this.internal = internal;
    return this;
  }

 /**
   * Globally scoped network is manually attachable by regular containers from workers in swarm mode.
   * @return attachable
  **/
  @JsonProperty("Attachable")
  public Boolean isAttachable() {
    return attachable;
  }

  public void setAttachable(Boolean attachable) {
    this.attachable = attachable;
  }

  public NetworkConfig attachable(Boolean attachable) {
    this.attachable = attachable;
    return this;
  }

 /**
   * Ingress network is the network which provides the routing-mesh in swarm mode.
   * @return ingress
  **/
  @JsonProperty("Ingress")
  public Boolean isIngress() {
    return ingress;
  }

  public void setIngress(Boolean ingress) {
    this.ingress = ingress;
  }

  public NetworkConfig ingress(Boolean ingress) {
    this.ingress = ingress;
    return this;
  }

 /**
   * Optional custom IP scheme for the network.
   * @return IPAM
  **/
  @JsonProperty("IPAM")
  public IPAM getIPAM() {
    return IPAM;
  }

  public void setIPAM(IPAM IPAM) {
    this.IPAM = IPAM;
  }

  public NetworkConfig IPAM(IPAM IPAM) {
    this.IPAM = IPAM;
    return this;
  }

 /**
   * Enable IPv6 on the network.
   * @return enableIPv6
  **/
  @JsonProperty("EnableIPv6")
  public Boolean isEnableIPv6() {
    return enableIPv6;
  }

  public void setEnableIPv6(Boolean enableIPv6) {
    this.enableIPv6 = enableIPv6;
  }

  public NetworkConfig enableIPv6(Boolean enableIPv6) {
    this.enableIPv6 = enableIPv6;
    return this;
  }

 /**
   * Network specific options to be used by the drivers.
   * @return options
  **/
  @JsonProperty("Options")
  public Map<String, String> getOptions() {
    return options;
  }

  public void setOptions(Map<String, String> options) {
    this.options = options;
  }

  public NetworkConfig options(Map<String, String> options) {
    this.options = options;
    return this;
  }

  public NetworkConfig putOptionsItem(String key, String optionsItem) {
    this.options.put(key, optionsItem);
    return this;
  }

 /**
   * User-defined key/value metadata.
   * @return labels
  **/
  @JsonProperty("Labels")
  public Map<String, String> getLabels() {
    return labels;
  }

  public void setLabels(Map<String, String> labels) {
    this.labels = labels;
  }

  public NetworkConfig labels(Map<String, String> labels) {
    this.labels = labels;
    return this;
  }

  public NetworkConfig putLabelsItem(String key, String labelsItem) {
    this.labels.put(key, labelsItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class NetworkConfig {\n");
    
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    checkDuplicate: ").append(toIndentedString(checkDuplicate)).append("\n");
    sb.append("    driver: ").append(toIndentedString(driver)).append("\n");
    sb.append("    internal: ").append(toIndentedString(internal)).append("\n");
    sb.append("    attachable: ").append(toIndentedString(attachable)).append("\n");
    sb.append("    ingress: ").append(toIndentedString(ingress)).append("\n");
    sb.append("    IPAM: ").append(toIndentedString(IPAM)).append("\n");
    sb.append("    enableIPv6: ").append(toIndentedString(enableIPv6)).append("\n");
    sb.append("    options: ").append(toIndentedString(options)).append("\n");
    sb.append("    labels: ").append(toIndentedString(labels)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

