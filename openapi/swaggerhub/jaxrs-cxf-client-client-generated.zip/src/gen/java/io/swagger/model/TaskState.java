package io.swagger.model;



/**
 * Gets or Sets TaskState
 */
public enum TaskState {
  
  NEW("new"),
  
  ALLOCATED("allocated"),
  
  PENDING("pending"),
  
  ASSIGNED("assigned"),
  
  ACCEPTED("accepted"),
  
  PREPARING("preparing"),
  
  READY("ready"),
  
  STARTING("starting"),
  
  RUNNING("running"),
  
  COMPLETE("complete"),
  
  SHUTDOWN("shutdown"),
  
  FAILED("failed"),
  
  REJECTED("rejected"),
  
  REMOVE("remove"),
  
  ORPHANED("orphaned");

  private String value;

  TaskState(String value) {
    this.value = value;
  }

  @Override
  public String toString() {
    return String.valueOf(value);
  }

  public static TaskState fromValue(String text) {
    for (TaskState b : TaskState.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
  
}

