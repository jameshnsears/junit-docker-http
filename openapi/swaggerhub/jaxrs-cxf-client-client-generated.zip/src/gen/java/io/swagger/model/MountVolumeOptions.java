package io.swagger.model;

import io.swagger.annotations.ApiModel;
import io.swagger.model.MountVolumeOptionsDriverConfig;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * Optional configuration for the `volume` type.
 **/
@ApiModel(description="Optional configuration for the `volume` type.")
public class MountVolumeOptions  {
  
  @ApiModelProperty(value = "Populate volume with data from the target.")
 /**
   * Populate volume with data from the target.  
  **/
  private Boolean noCopy = false;

  @ApiModelProperty(value = "User-defined key/value metadata.")
 /**
   * User-defined key/value metadata.  
  **/
  private Map<String, String> labels = null;

  @ApiModelProperty(value = "")
  private MountVolumeOptionsDriverConfig driverConfig = null;
 /**
   * Populate volume with data from the target.
   * @return noCopy
  **/
  @JsonProperty("NoCopy")
  public Boolean isNoCopy() {
    return noCopy;
  }

  public void setNoCopy(Boolean noCopy) {
    this.noCopy = noCopy;
  }

  public MountVolumeOptions noCopy(Boolean noCopy) {
    this.noCopy = noCopy;
    return this;
  }

 /**
   * User-defined key/value metadata.
   * @return labels
  **/
  @JsonProperty("Labels")
  public Map<String, String> getLabels() {
    return labels;
  }

  public void setLabels(Map<String, String> labels) {
    this.labels = labels;
  }

  public MountVolumeOptions labels(Map<String, String> labels) {
    this.labels = labels;
    return this;
  }

  public MountVolumeOptions putLabelsItem(String key, String labelsItem) {
    this.labels.put(key, labelsItem);
    return this;
  }

 /**
   * Get driverConfig
   * @return driverConfig
  **/
  @JsonProperty("DriverConfig")
  public MountVolumeOptionsDriverConfig getDriverConfig() {
    return driverConfig;
  }

  public void setDriverConfig(MountVolumeOptionsDriverConfig driverConfig) {
    this.driverConfig = driverConfig;
  }

  public MountVolumeOptions driverConfig(MountVolumeOptionsDriverConfig driverConfig) {
    this.driverConfig = driverConfig;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class MountVolumeOptions {\n");
    
    sb.append("    noCopy: ").append(toIndentedString(noCopy)).append("\n");
    sb.append("    labels: ").append(toIndentedString(labels)).append("\n");
    sb.append("    driverConfig: ").append(toIndentedString(driverConfig)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

