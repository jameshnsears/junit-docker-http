package io.swagger.model;

import io.swagger.annotations.ApiModel;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * Information about the issuer of leaf TLS certificates and the trusted root CA certificate
 **/
@ApiModel(description="Information about the issuer of leaf TLS certificates and the trusted root CA certificate")
public class TLSInfo  {
  
  @ApiModelProperty(value = "The root CA certificate(s) that are used to validate leaf TLS certificates")
 /**
   * The root CA certificate(s) that are used to validate leaf TLS certificates  
  **/
  private String trustRoot = null;

  @ApiModelProperty(value = "The base64-url-safe-encoded raw subject bytes of the issuer")
 /**
   * The base64-url-safe-encoded raw subject bytes of the issuer  
  **/
  private String certIssuerSubject = null;

  @ApiModelProperty(value = "The base64-url-safe-encoded raw public key bytes of the issuer")
 /**
   * The base64-url-safe-encoded raw public key bytes of the issuer  
  **/
  private String certIssuerPublicKey = null;
 /**
   * The root CA certificate(s) that are used to validate leaf TLS certificates
   * @return trustRoot
  **/
  @JsonProperty("TrustRoot")
  public String getTrustRoot() {
    return trustRoot;
  }

  public void setTrustRoot(String trustRoot) {
    this.trustRoot = trustRoot;
  }

  public TLSInfo trustRoot(String trustRoot) {
    this.trustRoot = trustRoot;
    return this;
  }

 /**
   * The base64-url-safe-encoded raw subject bytes of the issuer
   * @return certIssuerSubject
  **/
  @JsonProperty("CertIssuerSubject")
  public String getCertIssuerSubject() {
    return certIssuerSubject;
  }

  public void setCertIssuerSubject(String certIssuerSubject) {
    this.certIssuerSubject = certIssuerSubject;
  }

  public TLSInfo certIssuerSubject(String certIssuerSubject) {
    this.certIssuerSubject = certIssuerSubject;
    return this;
  }

 /**
   * The base64-url-safe-encoded raw public key bytes of the issuer
   * @return certIssuerPublicKey
  **/
  @JsonProperty("CertIssuerPublicKey")
  public String getCertIssuerPublicKey() {
    return certIssuerPublicKey;
  }

  public void setCertIssuerPublicKey(String certIssuerPublicKey) {
    this.certIssuerPublicKey = certIssuerPublicKey;
  }

  public TLSInfo certIssuerPublicKey(String certIssuerPublicKey) {
    this.certIssuerPublicKey = certIssuerPublicKey;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TLSInfo {\n");
    
    sb.append("    trustRoot: ").append(toIndentedString(trustRoot)).append("\n");
    sb.append("    certIssuerSubject: ").append(toIndentedString(certIssuerSubject)).append("\n");
    sb.append("    certIssuerPublicKey: ").append(toIndentedString(certIssuerPublicKey)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

