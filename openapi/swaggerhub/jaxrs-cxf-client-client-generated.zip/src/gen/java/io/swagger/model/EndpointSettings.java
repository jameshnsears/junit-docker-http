package io.swagger.model;

import io.swagger.annotations.ApiModel;
import io.swagger.model.EndpointIPAMConfig;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * Configuration for a network endpoint.
 **/
@ApiModel(description="Configuration for a network endpoint.")
public class EndpointSettings  {
  
  @ApiModelProperty(value = "")
  private EndpointIPAMConfig ipAMConfig = null;

  @ApiModelProperty(example = "[\"container_1\",\"container_2\"]", value = "")
  private List<String> links = null;

  @ApiModelProperty(example = "[\"server_x\",\"server_y\"]", value = "")
  private List<String> aliases = null;

  @ApiModelProperty(example = "08754567f1f40222263eab4102e1c733ae697e8e354aa9cd6e18d7402835292a", value = "Unique ID of the network. ")
 /**
   * Unique ID of the network.   
  **/
  private String networkID = null;

  @ApiModelProperty(example = "b88f5b905aabf2893f3cbc4ee42d1ea7980bbc0a92e2c8922b1e1795298afb0b", value = "Unique ID for the service endpoint in a Sandbox. ")
 /**
   * Unique ID for the service endpoint in a Sandbox.   
  **/
  private String endpointID = null;

  @ApiModelProperty(example = "172.17.0.1", value = "Gateway address for this network. ")
 /**
   * Gateway address for this network.   
  **/
  private String gateway = null;

  @ApiModelProperty(example = "172.17.0.4", value = "IPv4 address. ")
 /**
   * IPv4 address.   
  **/
  private String ipAddress = null;

  @ApiModelProperty(example = "16", value = "Mask length of the IPv4 address. ")
 /**
   * Mask length of the IPv4 address.   
  **/
  private Integer ipPrefixLen = null;

  @ApiModelProperty(example = "2001:db8:2::100", value = "IPv6 gateway address. ")
 /**
   * IPv6 gateway address.   
  **/
  private String ipv6Gateway = null;

  @ApiModelProperty(example = "2001:db8::5689", value = "Global IPv6 address. ")
 /**
   * Global IPv6 address.   
  **/
  private String globalIPv6Address = null;

  @ApiModelProperty(example = "64", value = "Mask length of the global IPv6 address. ")
 /**
   * Mask length of the global IPv6 address.   
  **/
  private Long globalIPv6PrefixLen = null;

  @ApiModelProperty(example = "02:42:ac:11:00:04", value = "MAC address for the endpoint on this network. ")
 /**
   * MAC address for the endpoint on this network.   
  **/
  private String macAddress = null;

  @ApiModelProperty(example = "{\"com.example.some-label\":\"some-value\",\"com.example.some-other-label\":\"some-other-value\"}", value = "DriverOpts is a mapping of driver options and values. These options are passed directly to the driver and are driver specific. ")
 /**
   * DriverOpts is a mapping of driver options and values. These options are passed directly to the driver and are driver specific.   
  **/
  private Map<String, String> driverOpts = null;
 /**
   * Get ipAMConfig
   * @return ipAMConfig
  **/
  @JsonProperty("IPAMConfig")
  public EndpointIPAMConfig getIpAMConfig() {
    return ipAMConfig;
  }

  public void setIpAMConfig(EndpointIPAMConfig ipAMConfig) {
    this.ipAMConfig = ipAMConfig;
  }

  public EndpointSettings ipAMConfig(EndpointIPAMConfig ipAMConfig) {
    this.ipAMConfig = ipAMConfig;
    return this;
  }

 /**
   * Get links
   * @return links
  **/
  @JsonProperty("Links")
  public List<String> getLinks() {
    return links;
  }

  public void setLinks(List<String> links) {
    this.links = links;
  }

  public EndpointSettings links(List<String> links) {
    this.links = links;
    return this;
  }

  public EndpointSettings addLinksItem(String linksItem) {
    this.links.add(linksItem);
    return this;
  }

 /**
   * Get aliases
   * @return aliases
  **/
  @JsonProperty("Aliases")
  public List<String> getAliases() {
    return aliases;
  }

  public void setAliases(List<String> aliases) {
    this.aliases = aliases;
  }

  public EndpointSettings aliases(List<String> aliases) {
    this.aliases = aliases;
    return this;
  }

  public EndpointSettings addAliasesItem(String aliasesItem) {
    this.aliases.add(aliasesItem);
    return this;
  }

 /**
   * Unique ID of the network. 
   * @return networkID
  **/
  @JsonProperty("NetworkID")
  public String getNetworkID() {
    return networkID;
  }

  public void setNetworkID(String networkID) {
    this.networkID = networkID;
  }

  public EndpointSettings networkID(String networkID) {
    this.networkID = networkID;
    return this;
  }

 /**
   * Unique ID for the service endpoint in a Sandbox. 
   * @return endpointID
  **/
  @JsonProperty("EndpointID")
  public String getEndpointID() {
    return endpointID;
  }

  public void setEndpointID(String endpointID) {
    this.endpointID = endpointID;
  }

  public EndpointSettings endpointID(String endpointID) {
    this.endpointID = endpointID;
    return this;
  }

 /**
   * Gateway address for this network. 
   * @return gateway
  **/
  @JsonProperty("Gateway")
  public String getGateway() {
    return gateway;
  }

  public void setGateway(String gateway) {
    this.gateway = gateway;
  }

  public EndpointSettings gateway(String gateway) {
    this.gateway = gateway;
    return this;
  }

 /**
   * IPv4 address. 
   * @return ipAddress
  **/
  @JsonProperty("IPAddress")
  public String getIpAddress() {
    return ipAddress;
  }

  public void setIpAddress(String ipAddress) {
    this.ipAddress = ipAddress;
  }

  public EndpointSettings ipAddress(String ipAddress) {
    this.ipAddress = ipAddress;
    return this;
  }

 /**
   * Mask length of the IPv4 address. 
   * @return ipPrefixLen
  **/
  @JsonProperty("IPPrefixLen")
  public Integer getIpPrefixLen() {
    return ipPrefixLen;
  }

  public void setIpPrefixLen(Integer ipPrefixLen) {
    this.ipPrefixLen = ipPrefixLen;
  }

  public EndpointSettings ipPrefixLen(Integer ipPrefixLen) {
    this.ipPrefixLen = ipPrefixLen;
    return this;
  }

 /**
   * IPv6 gateway address. 
   * @return ipv6Gateway
  **/
  @JsonProperty("IPv6Gateway")
  public String getIpv6Gateway() {
    return ipv6Gateway;
  }

  public void setIpv6Gateway(String ipv6Gateway) {
    this.ipv6Gateway = ipv6Gateway;
  }

  public EndpointSettings ipv6Gateway(String ipv6Gateway) {
    this.ipv6Gateway = ipv6Gateway;
    return this;
  }

 /**
   * Global IPv6 address. 
   * @return globalIPv6Address
  **/
  @JsonProperty("GlobalIPv6Address")
  public String getGlobalIPv6Address() {
    return globalIPv6Address;
  }

  public void setGlobalIPv6Address(String globalIPv6Address) {
    this.globalIPv6Address = globalIPv6Address;
  }

  public EndpointSettings globalIPv6Address(String globalIPv6Address) {
    this.globalIPv6Address = globalIPv6Address;
    return this;
  }

 /**
   * Mask length of the global IPv6 address. 
   * @return globalIPv6PrefixLen
  **/
  @JsonProperty("GlobalIPv6PrefixLen")
  public Long getGlobalIPv6PrefixLen() {
    return globalIPv6PrefixLen;
  }

  public void setGlobalIPv6PrefixLen(Long globalIPv6PrefixLen) {
    this.globalIPv6PrefixLen = globalIPv6PrefixLen;
  }

  public EndpointSettings globalIPv6PrefixLen(Long globalIPv6PrefixLen) {
    this.globalIPv6PrefixLen = globalIPv6PrefixLen;
    return this;
  }

 /**
   * MAC address for the endpoint on this network. 
   * @return macAddress
  **/
  @JsonProperty("MacAddress")
  public String getMacAddress() {
    return macAddress;
  }

  public void setMacAddress(String macAddress) {
    this.macAddress = macAddress;
  }

  public EndpointSettings macAddress(String macAddress) {
    this.macAddress = macAddress;
    return this;
  }

 /**
   * DriverOpts is a mapping of driver options and values. These options are passed directly to the driver and are driver specific. 
   * @return driverOpts
  **/
  @JsonProperty("DriverOpts")
  public Map<String, String> getDriverOpts() {
    return driverOpts;
  }

  public void setDriverOpts(Map<String, String> driverOpts) {
    this.driverOpts = driverOpts;
  }

  public EndpointSettings driverOpts(Map<String, String> driverOpts) {
    this.driverOpts = driverOpts;
    return this;
  }

  public EndpointSettings putDriverOptsItem(String key, String driverOptsItem) {
    this.driverOpts.put(key, driverOptsItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class EndpointSettings {\n");
    
    sb.append("    ipAMConfig: ").append(toIndentedString(ipAMConfig)).append("\n");
    sb.append("    links: ").append(toIndentedString(links)).append("\n");
    sb.append("    aliases: ").append(toIndentedString(aliases)).append("\n");
    sb.append("    networkID: ").append(toIndentedString(networkID)).append("\n");
    sb.append("    endpointID: ").append(toIndentedString(endpointID)).append("\n");
    sb.append("    gateway: ").append(toIndentedString(gateway)).append("\n");
    sb.append("    ipAddress: ").append(toIndentedString(ipAddress)).append("\n");
    sb.append("    ipPrefixLen: ").append(toIndentedString(ipPrefixLen)).append("\n");
    sb.append("    ipv6Gateway: ").append(toIndentedString(ipv6Gateway)).append("\n");
    sb.append("    globalIPv6Address: ").append(toIndentedString(globalIPv6Address)).append("\n");
    sb.append("    globalIPv6PrefixLen: ").append(toIndentedString(globalIPv6PrefixLen)).append("\n");
    sb.append("    macAddress: ").append(toIndentedString(macAddress)).append("\n");
    sb.append("    driverOpts: ").append(toIndentedString(driverOpts)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

