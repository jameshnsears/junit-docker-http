package io.swagger.model;

import io.swagger.model.TaskSpecContainerSpecFile;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class TaskSpecContainerSpecSecrets  {
  
  @ApiModelProperty(value = "")
  private TaskSpecContainerSpecFile file = null;

  @ApiModelProperty(value = "SecretID represents the ID of the specific secret that we're referencing.")
 /**
   * SecretID represents the ID of the specific secret that we're referencing.  
  **/
  private String secretID = null;

  @ApiModelProperty(value = "SecretName is the name of the secret that this references, but this is just provided for lookup/display purposes. The secret in the reference will be identified by its ID. ")
 /**
   * SecretName is the name of the secret that this references, but this is just provided for lookup/display purposes. The secret in the reference will be identified by its ID.   
  **/
  private String secretName = null;
 /**
   * Get file
   * @return file
  **/
  @JsonProperty("File")
  public TaskSpecContainerSpecFile getFile() {
    return file;
  }

  public void setFile(TaskSpecContainerSpecFile file) {
    this.file = file;
  }

  public TaskSpecContainerSpecSecrets file(TaskSpecContainerSpecFile file) {
    this.file = file;
    return this;
  }

 /**
   * SecretID represents the ID of the specific secret that we&#39;re referencing.
   * @return secretID
  **/
  @JsonProperty("SecretID")
  public String getSecretID() {
    return secretID;
  }

  public void setSecretID(String secretID) {
    this.secretID = secretID;
  }

  public TaskSpecContainerSpecSecrets secretID(String secretID) {
    this.secretID = secretID;
    return this;
  }

 /**
   * SecretName is the name of the secret that this references, but this is just provided for lookup/display purposes. The secret in the reference will be identified by its ID. 
   * @return secretName
  **/
  @JsonProperty("SecretName")
  public String getSecretName() {
    return secretName;
  }

  public void setSecretName(String secretName) {
    this.secretName = secretName;
  }

  public TaskSpecContainerSpecSecrets secretName(String secretName) {
    this.secretName = secretName;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TaskSpecContainerSpecSecrets {\n");
    
    sb.append("    file: ").append(toIndentedString(file)).append("\n");
    sb.append("    secretID: ").append(toIndentedString(secretID)).append("\n");
    sb.append("    secretName: ").append(toIndentedString(secretName)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

