package io.swagger.model;

import io.swagger.annotations.ApiModel;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * Volume configuration
 **/
@ApiModel(description="Volume configuration")
public class VolumeConfig  {
  
  @ApiModelProperty(value = "The new volume's name. If not specified, Docker generates a name.")
 /**
   * The new volume's name. If not specified, Docker generates a name.  
  **/
  private String name = null;

  @ApiModelProperty(value = "Name of the volume driver to use.")
 /**
   * Name of the volume driver to use.  
  **/
  private String driver = "local";

  @ApiModelProperty(value = "A mapping of driver options and values. These options are passed directly to the driver and are driver specific.")
 /**
   * A mapping of driver options and values. These options are passed directly to the driver and are driver specific.  
  **/
  private Map<String, String> driverOpts = null;

  @ApiModelProperty(value = "User-defined key/value metadata.")
 /**
   * User-defined key/value metadata.  
  **/
  private Map<String, String> labels = null;
 /**
   * The new volume&#39;s name. If not specified, Docker generates a name.
   * @return name
  **/
  @JsonProperty("Name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public VolumeConfig name(String name) {
    this.name = name;
    return this;
  }

 /**
   * Name of the volume driver to use.
   * @return driver
  **/
  @JsonProperty("Driver")
  public String getDriver() {
    return driver;
  }

  public void setDriver(String driver) {
    this.driver = driver;
  }

  public VolumeConfig driver(String driver) {
    this.driver = driver;
    return this;
  }

 /**
   * A mapping of driver options and values. These options are passed directly to the driver and are driver specific.
   * @return driverOpts
  **/
  @JsonProperty("DriverOpts")
  public Map<String, String> getDriverOpts() {
    return driverOpts;
  }

  public void setDriverOpts(Map<String, String> driverOpts) {
    this.driverOpts = driverOpts;
  }

  public VolumeConfig driverOpts(Map<String, String> driverOpts) {
    this.driverOpts = driverOpts;
    return this;
  }

  public VolumeConfig putDriverOptsItem(String key, String driverOptsItem) {
    this.driverOpts.put(key, driverOptsItem);
    return this;
  }

 /**
   * User-defined key/value metadata.
   * @return labels
  **/
  @JsonProperty("Labels")
  public Map<String, String> getLabels() {
    return labels;
  }

  public void setLabels(Map<String, String> labels) {
    this.labels = labels;
  }

  public VolumeConfig labels(Map<String, String> labels) {
    this.labels = labels;
    return this;
  }

  public VolumeConfig putLabelsItem(String key, String labelsItem) {
    this.labels.put(key, labelsItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class VolumeConfig {\n");
    
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    driver: ").append(toIndentedString(driver)).append("\n");
    sb.append("    driverOpts: ").append(toIndentedString(driverOpts)).append("\n");
    sb.append("    labels: ").append(toIndentedString(labels)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

