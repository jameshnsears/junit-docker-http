package io.swagger.model;

import io.swagger.annotations.ApiModel;
import io.swagger.model.EndpointPortConfig;
import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * Properties that can be configured to access and load balance a service.
 **/
@ApiModel(description="Properties that can be configured to access and load balance a service.")
public class EndpointSpec  {
  

@XmlType(name="ModeEnum")
@XmlEnum(String.class)
public enum ModeEnum {

@XmlEnumValue("vip") VIP(String.valueOf("vip")), @XmlEnumValue("dnsrr") DNSRR(String.valueOf("dnsrr"));


    private String value;

    ModeEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static ModeEnum fromValue(String v) {
        for (ModeEnum b : ModeEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(value = "The mode of resolution to use for internal load balancing between tasks.")
 /**
   * The mode of resolution to use for internal load balancing between tasks.  
  **/
  private ModeEnum mode = ModeEnum.VIP;

  @ApiModelProperty(value = "List of exposed ports that this service is accessible on from the outside. Ports can only be provided if `vip` resolution mode is used.")
 /**
   * List of exposed ports that this service is accessible on from the outside. Ports can only be provided if `vip` resolution mode is used.  
  **/
  private List<EndpointPortConfig> ports = null;
 /**
   * The mode of resolution to use for internal load balancing between tasks.
   * @return mode
  **/
  @JsonProperty("Mode")
  public String getMode() {
    if (mode == null) {
      return null;
    }
    return mode.value();
  }

  public void setMode(ModeEnum mode) {
    this.mode = mode;
  }

  public EndpointSpec mode(ModeEnum mode) {
    this.mode = mode;
    return this;
  }

 /**
   * List of exposed ports that this service is accessible on from the outside. Ports can only be provided if &#x60;vip&#x60; resolution mode is used.
   * @return ports
  **/
  @JsonProperty("Ports")
  public List<EndpointPortConfig> getPorts() {
    return ports;
  }

  public void setPorts(List<EndpointPortConfig> ports) {
    this.ports = ports;
  }

  public EndpointSpec ports(List<EndpointPortConfig> ports) {
    this.ports = ports;
    return this;
  }

  public EndpointSpec addPortsItem(EndpointPortConfig portsItem) {
    this.ports.add(portsItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class EndpointSpec {\n");
    
    sb.append("    mode: ").append(toIndentedString(mode)).append("\n");
    sb.append("    ports: ").append(toIndentedString(ports)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

