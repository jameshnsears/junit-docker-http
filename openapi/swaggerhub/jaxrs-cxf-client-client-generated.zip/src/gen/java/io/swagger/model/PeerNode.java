package io.swagger.model;

import io.swagger.annotations.ApiModel;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * Represents a peer-node in the swarm
 **/
@ApiModel(description="Represents a peer-node in the swarm")
public class PeerNode  {
  
  @ApiModelProperty(value = "Unique identifier of for this node in the swarm.")
 /**
   * Unique identifier of for this node in the swarm.  
  **/
  private String nodeID = null;

  @ApiModelProperty(value = "IP address and ports at which this node can be reached. ")
 /**
   * IP address and ports at which this node can be reached.   
  **/
  private String addr = null;
 /**
   * Unique identifier of for this node in the swarm.
   * @return nodeID
  **/
  @JsonProperty("NodeID")
  public String getNodeID() {
    return nodeID;
  }

  public void setNodeID(String nodeID) {
    this.nodeID = nodeID;
  }

  public PeerNode nodeID(String nodeID) {
    this.nodeID = nodeID;
    return this;
  }

 /**
   * IP address and ports at which this node can be reached. 
   * @return addr
  **/
  @JsonProperty("Addr")
  public String getAddr() {
    return addr;
  }

  public void setAddr(String addr) {
    this.addr = addr;
  }

  public PeerNode addr(String addr) {
    this.addr = addr;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PeerNode {\n");
    
    sb.append("    nodeID: ").append(toIndentedString(nodeID)).append("\n");
    sb.append("    addr: ").append(toIndentedString(addr)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

