package io.swagger.model;

import io.swagger.model.SystemEventsResponseActor;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class SystemEventsResponse  {
  
  @ApiModelProperty(value = "The type of object emitting the event")
 /**
   * The type of object emitting the event  
  **/
  private String type = null;

  @ApiModelProperty(value = "The type of event")
 /**
   * The type of event  
  **/
  private String action = null;

  @ApiModelProperty(value = "")
  private SystemEventsResponseActor actor = null;

  @ApiModelProperty(value = "Timestamp of event")
 /**
   * Timestamp of event  
  **/
  private Integer time = null;

  @ApiModelProperty(value = "Timestamp of event, with nanosecond accuracy")
 /**
   * Timestamp of event, with nanosecond accuracy  
  **/
  private Long timeNano = null;
 /**
   * The type of object emitting the event
   * @return type
  **/
  @JsonProperty("Type")
  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public SystemEventsResponse type(String type) {
    this.type = type;
    return this;
  }

 /**
   * The type of event
   * @return action
  **/
  @JsonProperty("Action")
  public String getAction() {
    return action;
  }

  public void setAction(String action) {
    this.action = action;
  }

  public SystemEventsResponse action(String action) {
    this.action = action;
    return this;
  }

 /**
   * Get actor
   * @return actor
  **/
  @JsonProperty("Actor")
  public SystemEventsResponseActor getActor() {
    return actor;
  }

  public void setActor(SystemEventsResponseActor actor) {
    this.actor = actor;
  }

  public SystemEventsResponse actor(SystemEventsResponseActor actor) {
    this.actor = actor;
    return this;
  }

 /**
   * Timestamp of event
   * @return time
  **/
  @JsonProperty("time")
  public Integer getTime() {
    return time;
  }

  public void setTime(Integer time) {
    this.time = time;
  }

  public SystemEventsResponse time(Integer time) {
    this.time = time;
    return this;
  }

 /**
   * Timestamp of event, with nanosecond accuracy
   * @return timeNano
  **/
  @JsonProperty("timeNano")
  public Long getTimeNano() {
    return timeNano;
  }

  public void setTimeNano(Long timeNano) {
    this.timeNano = timeNano;
  }

  public SystemEventsResponse timeNano(Long timeNano) {
    this.timeNano = timeNano;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SystemEventsResponse {\n");
    
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    action: ").append(toIndentedString(action)).append("\n");
    sb.append("    actor: ").append(toIndentedString(actor)).append("\n");
    sb.append("    time: ").append(toIndentedString(time)).append("\n");
    sb.append("    timeNano: ").append(toIndentedString(timeNano)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

