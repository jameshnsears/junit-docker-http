package io.swagger.model;

import io.swagger.model.GenericResources;
import io.swagger.model.ObjectVersion;
import io.swagger.model.TaskSpec;
import io.swagger.model.TaskState;
import io.swagger.model.TaskStatus;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Task  {
  
  @ApiModelProperty(value = "The ID of the task.")
 /**
   * The ID of the task.  
  **/
  private String ID = null;

  @ApiModelProperty(value = "")
  private ObjectVersion version = null;

  @ApiModelProperty(value = "")
  private String createdAt = null;

  @ApiModelProperty(value = "")
  private String updatedAt = null;

  @ApiModelProperty(value = "Name of the task.")
 /**
   * Name of the task.  
  **/
  private String name = null;

  @ApiModelProperty(value = "User-defined key/value metadata.")
 /**
   * User-defined key/value metadata.  
  **/
  private Map<String, String> labels = null;

  @ApiModelProperty(value = "")
  private TaskSpec spec = null;

  @ApiModelProperty(value = "The ID of the service this task is part of.")
 /**
   * The ID of the service this task is part of.  
  **/
  private String serviceID = null;

  @ApiModelProperty(value = "")
  private Integer slot = null;

  @ApiModelProperty(value = "The ID of the node that this task is on.")
 /**
   * The ID of the node that this task is on.  
  **/
  private String nodeID = null;

  @ApiModelProperty(value = "")
  private GenericResources assignedGenericResources = null;

  @ApiModelProperty(value = "")
  private TaskStatus status = null;

  @ApiModelProperty(value = "")
  private TaskState desiredState = null;
 /**
   * The ID of the task.
   * @return ID
  **/
  @JsonProperty("ID")
  public String getID() {
    return ID;
  }

  public void setID(String ID) {
    this.ID = ID;
  }

  public Task ID(String ID) {
    this.ID = ID;
    return this;
  }

 /**
   * Get version
   * @return version
  **/
  @JsonProperty("Version")
  public ObjectVersion getVersion() {
    return version;
  }

  public void setVersion(ObjectVersion version) {
    this.version = version;
  }

  public Task version(ObjectVersion version) {
    this.version = version;
    return this;
  }

 /**
   * Get createdAt
   * @return createdAt
  **/
  @JsonProperty("CreatedAt")
  public String getCreatedAt() {
    return createdAt;
  }

  public void setCreatedAt(String createdAt) {
    this.createdAt = createdAt;
  }

  public Task createdAt(String createdAt) {
    this.createdAt = createdAt;
    return this;
  }

 /**
   * Get updatedAt
   * @return updatedAt
  **/
  @JsonProperty("UpdatedAt")
  public String getUpdatedAt() {
    return updatedAt;
  }

  public void setUpdatedAt(String updatedAt) {
    this.updatedAt = updatedAt;
  }

  public Task updatedAt(String updatedAt) {
    this.updatedAt = updatedAt;
    return this;
  }

 /**
   * Name of the task.
   * @return name
  **/
  @JsonProperty("Name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Task name(String name) {
    this.name = name;
    return this;
  }

 /**
   * User-defined key/value metadata.
   * @return labels
  **/
  @JsonProperty("Labels")
  public Map<String, String> getLabels() {
    return labels;
  }

  public void setLabels(Map<String, String> labels) {
    this.labels = labels;
  }

  public Task labels(Map<String, String> labels) {
    this.labels = labels;
    return this;
  }

  public Task putLabelsItem(String key, String labelsItem) {
    this.labels.put(key, labelsItem);
    return this;
  }

 /**
   * Get spec
   * @return spec
  **/
  @JsonProperty("Spec")
  public TaskSpec getSpec() {
    return spec;
  }

  public void setSpec(TaskSpec spec) {
    this.spec = spec;
  }

  public Task spec(TaskSpec spec) {
    this.spec = spec;
    return this;
  }

 /**
   * The ID of the service this task is part of.
   * @return serviceID
  **/
  @JsonProperty("ServiceID")
  public String getServiceID() {
    return serviceID;
  }

  public void setServiceID(String serviceID) {
    this.serviceID = serviceID;
  }

  public Task serviceID(String serviceID) {
    this.serviceID = serviceID;
    return this;
  }

 /**
   * Get slot
   * @return slot
  **/
  @JsonProperty("Slot")
  public Integer getSlot() {
    return slot;
  }

  public void setSlot(Integer slot) {
    this.slot = slot;
  }

  public Task slot(Integer slot) {
    this.slot = slot;
    return this;
  }

 /**
   * The ID of the node that this task is on.
   * @return nodeID
  **/
  @JsonProperty("NodeID")
  public String getNodeID() {
    return nodeID;
  }

  public void setNodeID(String nodeID) {
    this.nodeID = nodeID;
  }

  public Task nodeID(String nodeID) {
    this.nodeID = nodeID;
    return this;
  }

 /**
   * Get assignedGenericResources
   * @return assignedGenericResources
  **/
  @JsonProperty("AssignedGenericResources")
  public GenericResources getAssignedGenericResources() {
    return assignedGenericResources;
  }

  public void setAssignedGenericResources(GenericResources assignedGenericResources) {
    this.assignedGenericResources = assignedGenericResources;
  }

  public Task assignedGenericResources(GenericResources assignedGenericResources) {
    this.assignedGenericResources = assignedGenericResources;
    return this;
  }

 /**
   * Get status
   * @return status
  **/
  @JsonProperty("Status")
  public TaskStatus getStatus() {
    return status;
  }

  public void setStatus(TaskStatus status) {
    this.status = status;
  }

  public Task status(TaskStatus status) {
    this.status = status;
    return this;
  }

 /**
   * Get desiredState
   * @return desiredState
  **/
  @JsonProperty("DesiredState")
  public TaskState getDesiredState() {
    return desiredState;
  }

  public void setDesiredState(TaskState desiredState) {
    this.desiredState = desiredState;
  }

  public Task desiredState(TaskState desiredState) {
    this.desiredState = desiredState;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Task {\n");
    
    sb.append("    ID: ").append(toIndentedString(ID)).append("\n");
    sb.append("    version: ").append(toIndentedString(version)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    labels: ").append(toIndentedString(labels)).append("\n");
    sb.append("    spec: ").append(toIndentedString(spec)).append("\n");
    sb.append("    serviceID: ").append(toIndentedString(serviceID)).append("\n");
    sb.append("    slot: ").append(toIndentedString(slot)).append("\n");
    sb.append("    nodeID: ").append(toIndentedString(nodeID)).append("\n");
    sb.append("    assignedGenericResources: ").append(toIndentedString(assignedGenericResources)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    desiredState: ").append(toIndentedString(desiredState)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

