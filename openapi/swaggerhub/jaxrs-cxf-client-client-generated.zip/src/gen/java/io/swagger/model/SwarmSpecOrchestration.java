package io.swagger.model;

import io.swagger.annotations.ApiModel;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * Orchestration configuration.
 **/
@ApiModel(description="Orchestration configuration.")
public class SwarmSpecOrchestration  {
  
  @ApiModelProperty(example = "10", value = "The number of historic tasks to keep per instance or node. If negative, never remove completed or failed tasks.")
 /**
   * The number of historic tasks to keep per instance or node. If negative, never remove completed or failed tasks.  
  **/
  private Long taskHistoryRetentionLimit = null;
 /**
   * The number of historic tasks to keep per instance or node. If negative, never remove completed or failed tasks.
   * @return taskHistoryRetentionLimit
  **/
  @JsonProperty("TaskHistoryRetentionLimit")
  public Long getTaskHistoryRetentionLimit() {
    return taskHistoryRetentionLimit;
  }

  public void setTaskHistoryRetentionLimit(Long taskHistoryRetentionLimit) {
    this.taskHistoryRetentionLimit = taskHistoryRetentionLimit;
  }

  public SwarmSpecOrchestration taskHistoryRetentionLimit(Long taskHistoryRetentionLimit) {
    this.taskHistoryRetentionLimit = taskHistoryRetentionLimit;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SwarmSpecOrchestration {\n");
    
    sb.append("    taskHistoryRetentionLimit: ").append(toIndentedString(taskHistoryRetentionLimit)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

