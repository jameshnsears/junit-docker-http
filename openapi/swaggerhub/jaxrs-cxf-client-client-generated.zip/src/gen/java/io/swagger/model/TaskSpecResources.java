package io.swagger.model;

import io.swagger.annotations.ApiModel;
import io.swagger.model.ResourceObject;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * Resource requirements which apply to each individual container created as part of the service.
 **/
@ApiModel(description="Resource requirements which apply to each individual container created as part of the service.")
public class TaskSpecResources  {
  
  @ApiModelProperty(value = "Define resources limits.")
 /**
   * Define resources limits.  
  **/
  private ResourceObject limits = null;

  @ApiModelProperty(value = "Define resources reservation.")
 /**
   * Define resources reservation.  
  **/
  private ResourceObject reservation = null;
 /**
   * Define resources limits.
   * @return limits
  **/
  @JsonProperty("Limits")
  public ResourceObject getLimits() {
    return limits;
  }

  public void setLimits(ResourceObject limits) {
    this.limits = limits;
  }

  public TaskSpecResources limits(ResourceObject limits) {
    this.limits = limits;
    return this;
  }

 /**
   * Define resources reservation.
   * @return reservation
  **/
  @JsonProperty("Reservation")
  public ResourceObject getReservation() {
    return reservation;
  }

  public void setReservation(ResourceObject reservation) {
    this.reservation = reservation;
  }

  public TaskSpecResources reservation(ResourceObject reservation) {
    this.reservation = reservation;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TaskSpecResources {\n");
    
    sb.append("    limits: ").append(toIndentedString(limits)).append("\n");
    sb.append("    reservation: ").append(toIndentedString(reservation)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

