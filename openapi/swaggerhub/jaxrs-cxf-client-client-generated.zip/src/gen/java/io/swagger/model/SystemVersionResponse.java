package io.swagger.model;

import io.swagger.model.SystemVersionResponseComponents;
import io.swagger.model.SystemVersionResponsePlatform;
import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class SystemVersionResponse  {
  
  @ApiModelProperty(value = "")
  private SystemVersionResponsePlatform platform = null;

  @ApiModelProperty(value = "")
  private List<SystemVersionResponseComponents> components = null;

  @ApiModelProperty(value = "")
  private String version = null;

  @ApiModelProperty(value = "")
  private String apiVersion = null;

  @ApiModelProperty(value = "")
  private String minAPIVersion = null;

  @ApiModelProperty(value = "")
  private String gitCommit = null;

  @ApiModelProperty(value = "")
  private String goVersion = null;

  @ApiModelProperty(value = "")
  private String os = null;

  @ApiModelProperty(value = "")
  private String arch = null;

  @ApiModelProperty(value = "")
  private String kernelVersion = null;

  @ApiModelProperty(value = "")
  private Boolean experimental = null;

  @ApiModelProperty(value = "")
  private String buildTime = null;
 /**
   * Get platform
   * @return platform
  **/
  @JsonProperty("Platform")
  public SystemVersionResponsePlatform getPlatform() {
    return platform;
  }

  public void setPlatform(SystemVersionResponsePlatform platform) {
    this.platform = platform;
  }

  public SystemVersionResponse platform(SystemVersionResponsePlatform platform) {
    this.platform = platform;
    return this;
  }

 /**
   * Get components
   * @return components
  **/
  @JsonProperty("Components")
  public List<SystemVersionResponseComponents> getComponents() {
    return components;
  }

  public void setComponents(List<SystemVersionResponseComponents> components) {
    this.components = components;
  }

  public SystemVersionResponse components(List<SystemVersionResponseComponents> components) {
    this.components = components;
    return this;
  }

  public SystemVersionResponse addComponentsItem(SystemVersionResponseComponents componentsItem) {
    this.components.add(componentsItem);
    return this;
  }

 /**
   * Get version
   * @return version
  **/
  @JsonProperty("Version")
  public String getVersion() {
    return version;
  }

  public void setVersion(String version) {
    this.version = version;
  }

  public SystemVersionResponse version(String version) {
    this.version = version;
    return this;
  }

 /**
   * Get apiVersion
   * @return apiVersion
  **/
  @JsonProperty("ApiVersion")
  public String getApiVersion() {
    return apiVersion;
  }

  public void setApiVersion(String apiVersion) {
    this.apiVersion = apiVersion;
  }

  public SystemVersionResponse apiVersion(String apiVersion) {
    this.apiVersion = apiVersion;
    return this;
  }

 /**
   * Get minAPIVersion
   * @return minAPIVersion
  **/
  @JsonProperty("MinAPIVersion")
  public String getMinAPIVersion() {
    return minAPIVersion;
  }

  public void setMinAPIVersion(String minAPIVersion) {
    this.minAPIVersion = minAPIVersion;
  }

  public SystemVersionResponse minAPIVersion(String minAPIVersion) {
    this.minAPIVersion = minAPIVersion;
    return this;
  }

 /**
   * Get gitCommit
   * @return gitCommit
  **/
  @JsonProperty("GitCommit")
  public String getGitCommit() {
    return gitCommit;
  }

  public void setGitCommit(String gitCommit) {
    this.gitCommit = gitCommit;
  }

  public SystemVersionResponse gitCommit(String gitCommit) {
    this.gitCommit = gitCommit;
    return this;
  }

 /**
   * Get goVersion
   * @return goVersion
  **/
  @JsonProperty("GoVersion")
  public String getGoVersion() {
    return goVersion;
  }

  public void setGoVersion(String goVersion) {
    this.goVersion = goVersion;
  }

  public SystemVersionResponse goVersion(String goVersion) {
    this.goVersion = goVersion;
    return this;
  }

 /**
   * Get os
   * @return os
  **/
  @JsonProperty("Os")
  public String getOs() {
    return os;
  }

  public void setOs(String os) {
    this.os = os;
  }

  public SystemVersionResponse os(String os) {
    this.os = os;
    return this;
  }

 /**
   * Get arch
   * @return arch
  **/
  @JsonProperty("Arch")
  public String getArch() {
    return arch;
  }

  public void setArch(String arch) {
    this.arch = arch;
  }

  public SystemVersionResponse arch(String arch) {
    this.arch = arch;
    return this;
  }

 /**
   * Get kernelVersion
   * @return kernelVersion
  **/
  @JsonProperty("KernelVersion")
  public String getKernelVersion() {
    return kernelVersion;
  }

  public void setKernelVersion(String kernelVersion) {
    this.kernelVersion = kernelVersion;
  }

  public SystemVersionResponse kernelVersion(String kernelVersion) {
    this.kernelVersion = kernelVersion;
    return this;
  }

 /**
   * Get experimental
   * @return experimental
  **/
  @JsonProperty("Experimental")
  public Boolean isExperimental() {
    return experimental;
  }

  public void setExperimental(Boolean experimental) {
    this.experimental = experimental;
  }

  public SystemVersionResponse experimental(Boolean experimental) {
    this.experimental = experimental;
    return this;
  }

 /**
   * Get buildTime
   * @return buildTime
  **/
  @JsonProperty("BuildTime")
  public String getBuildTime() {
    return buildTime;
  }

  public void setBuildTime(String buildTime) {
    this.buildTime = buildTime;
  }

  public SystemVersionResponse buildTime(String buildTime) {
    this.buildTime = buildTime;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SystemVersionResponse {\n");
    
    sb.append("    platform: ").append(toIndentedString(platform)).append("\n");
    sb.append("    components: ").append(toIndentedString(components)).append("\n");
    sb.append("    version: ").append(toIndentedString(version)).append("\n");
    sb.append("    apiVersion: ").append(toIndentedString(apiVersion)).append("\n");
    sb.append("    minAPIVersion: ").append(toIndentedString(minAPIVersion)).append("\n");
    sb.append("    gitCommit: ").append(toIndentedString(gitCommit)).append("\n");
    sb.append("    goVersion: ").append(toIndentedString(goVersion)).append("\n");
    sb.append("    os: ").append(toIndentedString(os)).append("\n");
    sb.append("    arch: ").append(toIndentedString(arch)).append("\n");
    sb.append("    kernelVersion: ").append(toIndentedString(kernelVersion)).append("\n");
    sb.append("    experimental: ").append(toIndentedString(experimental)).append("\n");
    sb.append("    buildTime: ").append(toIndentedString(buildTime)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

