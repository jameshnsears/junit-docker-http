package io.swagger.model;

import io.swagger.annotations.ApiModel;
import io.swagger.model.NodeState;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * NodeStatus represents the status of a node.  It provides the current status of the node, as seen by the manager. 
 **/
@ApiModel(description="NodeStatus represents the status of a node.  It provides the current status of the node, as seen by the manager. ")
public class NodeStatus  {
  
  @ApiModelProperty(value = "")
  private NodeState state = null;

  @ApiModelProperty(example = "", value = "")
  private String message = null;

  @ApiModelProperty(example = "172.17.0.2", value = "IP address of the node.")
 /**
   * IP address of the node.  
  **/
  private String addr = null;
 /**
   * Get state
   * @return state
  **/
  @JsonProperty("State")
  public NodeState getState() {
    return state;
  }

  public void setState(NodeState state) {
    this.state = state;
  }

  public NodeStatus state(NodeState state) {
    this.state = state;
    return this;
  }

 /**
   * Get message
   * @return message
  **/
  @JsonProperty("Message")
  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public NodeStatus message(String message) {
    this.message = message;
    return this;
  }

 /**
   * IP address of the node.
   * @return addr
  **/
  @JsonProperty("Addr")
  public String getAddr() {
    return addr;
  }

  public void setAddr(String addr) {
    this.addr = addr;
  }

  public NodeStatus addr(String addr) {
    this.addr = addr;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class NodeStatus {\n");
    
    sb.append("    state: ").append(toIndentedString(state)).append("\n");
    sb.append("    message: ").append(toIndentedString(message)).append("\n");
    sb.append("    addr: ").append(toIndentedString(addr)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

