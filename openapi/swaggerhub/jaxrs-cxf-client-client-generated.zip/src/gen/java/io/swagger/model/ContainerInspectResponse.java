package io.swagger.model;

import io.swagger.model.ContainerConfig;
import io.swagger.model.ContainerInspectResponseState;
import io.swagger.model.GraphDriverData;
import io.swagger.model.HostConfig;
import io.swagger.model.MountPoint;
import io.swagger.model.NetworkSettings;
import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ContainerInspectResponse  {
  
  @ApiModelProperty(value = "The ID of the container")
 /**
   * The ID of the container  
  **/
  private String id = null;

  @ApiModelProperty(value = "The time the container was created")
 /**
   * The time the container was created  
  **/
  private String created = null;

  @ApiModelProperty(value = "The path to the command being run")
 /**
   * The path to the command being run  
  **/
  private String path = null;

  @ApiModelProperty(value = "The arguments to the command being run")
 /**
   * The arguments to the command being run  
  **/
  private List<String> args = null;

  @ApiModelProperty(value = "")
  private ContainerInspectResponseState state = null;

  @ApiModelProperty(value = "The container's image")
 /**
   * The container's image  
  **/
  private String image = null;

  @ApiModelProperty(value = "")
  private String resolvConfPath = null;

  @ApiModelProperty(value = "")
  private String hostnamePath = null;

  @ApiModelProperty(value = "")
  private String hostsPath = null;

  @ApiModelProperty(value = "")
  private String logPath = null;

  @ApiModelProperty(value = "TODO")
 /**
   * TODO  
  **/
  private Object node = null;

  @ApiModelProperty(value = "")
  private String name = null;

  @ApiModelProperty(value = "")
  private Integer restartCount = null;

  @ApiModelProperty(value = "")
  private String driver = null;

  @ApiModelProperty(value = "")
  private String mountLabel = null;

  @ApiModelProperty(value = "")
  private String processLabel = null;

  @ApiModelProperty(value = "")
  private String appArmorProfile = null;

  @ApiModelProperty(value = "IDs of exec instances that are running in the container.")
 /**
   * IDs of exec instances that are running in the container.  
  **/
  private List<String> execIDs = null;

  @ApiModelProperty(value = "")
  private HostConfig hostConfig = null;

  @ApiModelProperty(value = "")
  private GraphDriverData graphDriver = null;

  @ApiModelProperty(value = "The size of files that have been created or changed by this container.")
 /**
   * The size of files that have been created or changed by this container.  
  **/
  private Long sizeRw = null;

  @ApiModelProperty(value = "The total size of all the files in this container.")
 /**
   * The total size of all the files in this container.  
  **/
  private Long sizeRootFs = null;

  @ApiModelProperty(value = "")
  private List<MountPoint> mounts = null;

  @ApiModelProperty(value = "")
  private ContainerConfig config = null;

  @ApiModelProperty(value = "")
  private NetworkSettings networkSettings = null;
 /**
   * The ID of the container
   * @return id
  **/
  @JsonProperty("Id")
  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public ContainerInspectResponse id(String id) {
    this.id = id;
    return this;
  }

 /**
   * The time the container was created
   * @return created
  **/
  @JsonProperty("Created")
  public String getCreated() {
    return created;
  }

  public void setCreated(String created) {
    this.created = created;
  }

  public ContainerInspectResponse created(String created) {
    this.created = created;
    return this;
  }

 /**
   * The path to the command being run
   * @return path
  **/
  @JsonProperty("Path")
  public String getPath() {
    return path;
  }

  public void setPath(String path) {
    this.path = path;
  }

  public ContainerInspectResponse path(String path) {
    this.path = path;
    return this;
  }

 /**
   * The arguments to the command being run
   * @return args
  **/
  @JsonProperty("Args")
  public List<String> getArgs() {
    return args;
  }

  public void setArgs(List<String> args) {
    this.args = args;
  }

  public ContainerInspectResponse args(List<String> args) {
    this.args = args;
    return this;
  }

  public ContainerInspectResponse addArgsItem(String argsItem) {
    this.args.add(argsItem);
    return this;
  }

 /**
   * Get state
   * @return state
  **/
  @JsonProperty("State")
  public ContainerInspectResponseState getState() {
    return state;
  }

  public void setState(ContainerInspectResponseState state) {
    this.state = state;
  }

  public ContainerInspectResponse state(ContainerInspectResponseState state) {
    this.state = state;
    return this;
  }

 /**
   * The container&#39;s image
   * @return image
  **/
  @JsonProperty("Image")
  public String getImage() {
    return image;
  }

  public void setImage(String image) {
    this.image = image;
  }

  public ContainerInspectResponse image(String image) {
    this.image = image;
    return this;
  }

 /**
   * Get resolvConfPath
   * @return resolvConfPath
  **/
  @JsonProperty("ResolvConfPath")
  public String getResolvConfPath() {
    return resolvConfPath;
  }

  public void setResolvConfPath(String resolvConfPath) {
    this.resolvConfPath = resolvConfPath;
  }

  public ContainerInspectResponse resolvConfPath(String resolvConfPath) {
    this.resolvConfPath = resolvConfPath;
    return this;
  }

 /**
   * Get hostnamePath
   * @return hostnamePath
  **/
  @JsonProperty("HostnamePath")
  public String getHostnamePath() {
    return hostnamePath;
  }

  public void setHostnamePath(String hostnamePath) {
    this.hostnamePath = hostnamePath;
  }

  public ContainerInspectResponse hostnamePath(String hostnamePath) {
    this.hostnamePath = hostnamePath;
    return this;
  }

 /**
   * Get hostsPath
   * @return hostsPath
  **/
  @JsonProperty("HostsPath")
  public String getHostsPath() {
    return hostsPath;
  }

  public void setHostsPath(String hostsPath) {
    this.hostsPath = hostsPath;
  }

  public ContainerInspectResponse hostsPath(String hostsPath) {
    this.hostsPath = hostsPath;
    return this;
  }

 /**
   * Get logPath
   * @return logPath
  **/
  @JsonProperty("LogPath")
  public String getLogPath() {
    return logPath;
  }

  public void setLogPath(String logPath) {
    this.logPath = logPath;
  }

  public ContainerInspectResponse logPath(String logPath) {
    this.logPath = logPath;
    return this;
  }

 /**
   * TODO
   * @return node
  **/
  @JsonProperty("Node")
  public Object getNode() {
    return node;
  }

  public void setNode(Object node) {
    this.node = node;
  }

  public ContainerInspectResponse node(Object node) {
    this.node = node;
    return this;
  }

 /**
   * Get name
   * @return name
  **/
  @JsonProperty("Name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public ContainerInspectResponse name(String name) {
    this.name = name;
    return this;
  }

 /**
   * Get restartCount
   * @return restartCount
  **/
  @JsonProperty("RestartCount")
  public Integer getRestartCount() {
    return restartCount;
  }

  public void setRestartCount(Integer restartCount) {
    this.restartCount = restartCount;
  }

  public ContainerInspectResponse restartCount(Integer restartCount) {
    this.restartCount = restartCount;
    return this;
  }

 /**
   * Get driver
   * @return driver
  **/
  @JsonProperty("Driver")
  public String getDriver() {
    return driver;
  }

  public void setDriver(String driver) {
    this.driver = driver;
  }

  public ContainerInspectResponse driver(String driver) {
    this.driver = driver;
    return this;
  }

 /**
   * Get mountLabel
   * @return mountLabel
  **/
  @JsonProperty("MountLabel")
  public String getMountLabel() {
    return mountLabel;
  }

  public void setMountLabel(String mountLabel) {
    this.mountLabel = mountLabel;
  }

  public ContainerInspectResponse mountLabel(String mountLabel) {
    this.mountLabel = mountLabel;
    return this;
  }

 /**
   * Get processLabel
   * @return processLabel
  **/
  @JsonProperty("ProcessLabel")
  public String getProcessLabel() {
    return processLabel;
  }

  public void setProcessLabel(String processLabel) {
    this.processLabel = processLabel;
  }

  public ContainerInspectResponse processLabel(String processLabel) {
    this.processLabel = processLabel;
    return this;
  }

 /**
   * Get appArmorProfile
   * @return appArmorProfile
  **/
  @JsonProperty("AppArmorProfile")
  public String getAppArmorProfile() {
    return appArmorProfile;
  }

  public void setAppArmorProfile(String appArmorProfile) {
    this.appArmorProfile = appArmorProfile;
  }

  public ContainerInspectResponse appArmorProfile(String appArmorProfile) {
    this.appArmorProfile = appArmorProfile;
    return this;
  }

 /**
   * IDs of exec instances that are running in the container.
   * @return execIDs
  **/
  @JsonProperty("ExecIDs")
  public List<String> getExecIDs() {
    return execIDs;
  }

  public void setExecIDs(List<String> execIDs) {
    this.execIDs = execIDs;
  }

  public ContainerInspectResponse execIDs(List<String> execIDs) {
    this.execIDs = execIDs;
    return this;
  }

  public ContainerInspectResponse addExecIDsItem(String execIDsItem) {
    this.execIDs.add(execIDsItem);
    return this;
  }

 /**
   * Get hostConfig
   * @return hostConfig
  **/
  @JsonProperty("HostConfig")
  public HostConfig getHostConfig() {
    return hostConfig;
  }

  public void setHostConfig(HostConfig hostConfig) {
    this.hostConfig = hostConfig;
  }

  public ContainerInspectResponse hostConfig(HostConfig hostConfig) {
    this.hostConfig = hostConfig;
    return this;
  }

 /**
   * Get graphDriver
   * @return graphDriver
  **/
  @JsonProperty("GraphDriver")
  public GraphDriverData getGraphDriver() {
    return graphDriver;
  }

  public void setGraphDriver(GraphDriverData graphDriver) {
    this.graphDriver = graphDriver;
  }

  public ContainerInspectResponse graphDriver(GraphDriverData graphDriver) {
    this.graphDriver = graphDriver;
    return this;
  }

 /**
   * The size of files that have been created or changed by this container.
   * @return sizeRw
  **/
  @JsonProperty("SizeRw")
  public Long getSizeRw() {
    return sizeRw;
  }

  public void setSizeRw(Long sizeRw) {
    this.sizeRw = sizeRw;
  }

  public ContainerInspectResponse sizeRw(Long sizeRw) {
    this.sizeRw = sizeRw;
    return this;
  }

 /**
   * The total size of all the files in this container.
   * @return sizeRootFs
  **/
  @JsonProperty("SizeRootFs")
  public Long getSizeRootFs() {
    return sizeRootFs;
  }

  public void setSizeRootFs(Long sizeRootFs) {
    this.sizeRootFs = sizeRootFs;
  }

  public ContainerInspectResponse sizeRootFs(Long sizeRootFs) {
    this.sizeRootFs = sizeRootFs;
    return this;
  }

 /**
   * Get mounts
   * @return mounts
  **/
  @JsonProperty("Mounts")
  public List<MountPoint> getMounts() {
    return mounts;
  }

  public void setMounts(List<MountPoint> mounts) {
    this.mounts = mounts;
  }

  public ContainerInspectResponse mounts(List<MountPoint> mounts) {
    this.mounts = mounts;
    return this;
  }

  public ContainerInspectResponse addMountsItem(MountPoint mountsItem) {
    this.mounts.add(mountsItem);
    return this;
  }

 /**
   * Get config
   * @return config
  **/
  @JsonProperty("Config")
  public ContainerConfig getConfig() {
    return config;
  }

  public void setConfig(ContainerConfig config) {
    this.config = config;
  }

  public ContainerInspectResponse config(ContainerConfig config) {
    this.config = config;
    return this;
  }

 /**
   * Get networkSettings
   * @return networkSettings
  **/
  @JsonProperty("NetworkSettings")
  public NetworkSettings getNetworkSettings() {
    return networkSettings;
  }

  public void setNetworkSettings(NetworkSettings networkSettings) {
    this.networkSettings = networkSettings;
  }

  public ContainerInspectResponse networkSettings(NetworkSettings networkSettings) {
    this.networkSettings = networkSettings;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ContainerInspectResponse {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    created: ").append(toIndentedString(created)).append("\n");
    sb.append("    path: ").append(toIndentedString(path)).append("\n");
    sb.append("    args: ").append(toIndentedString(args)).append("\n");
    sb.append("    state: ").append(toIndentedString(state)).append("\n");
    sb.append("    image: ").append(toIndentedString(image)).append("\n");
    sb.append("    resolvConfPath: ").append(toIndentedString(resolvConfPath)).append("\n");
    sb.append("    hostnamePath: ").append(toIndentedString(hostnamePath)).append("\n");
    sb.append("    hostsPath: ").append(toIndentedString(hostsPath)).append("\n");
    sb.append("    logPath: ").append(toIndentedString(logPath)).append("\n");
    sb.append("    node: ").append(toIndentedString(node)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    restartCount: ").append(toIndentedString(restartCount)).append("\n");
    sb.append("    driver: ").append(toIndentedString(driver)).append("\n");
    sb.append("    mountLabel: ").append(toIndentedString(mountLabel)).append("\n");
    sb.append("    processLabel: ").append(toIndentedString(processLabel)).append("\n");
    sb.append("    appArmorProfile: ").append(toIndentedString(appArmorProfile)).append("\n");
    sb.append("    execIDs: ").append(toIndentedString(execIDs)).append("\n");
    sb.append("    hostConfig: ").append(toIndentedString(hostConfig)).append("\n");
    sb.append("    graphDriver: ").append(toIndentedString(graphDriver)).append("\n");
    sb.append("    sizeRw: ").append(toIndentedString(sizeRw)).append("\n");
    sb.append("    sizeRootFs: ").append(toIndentedString(sizeRootFs)).append("\n");
    sb.append("    mounts: ").append(toIndentedString(mounts)).append("\n");
    sb.append("    config: ").append(toIndentedString(config)).append("\n");
    sb.append("    networkSettings: ").append(toIndentedString(networkSettings)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

