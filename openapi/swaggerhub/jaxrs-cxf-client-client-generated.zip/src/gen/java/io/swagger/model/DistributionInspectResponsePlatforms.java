package io.swagger.model;

import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class DistributionInspectResponsePlatforms  {
  
  @ApiModelProperty(value = "")
  private String architecture = null;

  @ApiModelProperty(value = "")
  private String OS = null;

  @ApiModelProperty(value = "")
  private String osVersion = null;

  @ApiModelProperty(value = "")
  private List<String> osFeatures = null;

  @ApiModelProperty(value = "")
  private String variant = null;

  @ApiModelProperty(value = "")
  private List<String> features = null;
 /**
   * Get architecture
   * @return architecture
  **/
  @JsonProperty("Architecture")
  public String getArchitecture() {
    return architecture;
  }

  public void setArchitecture(String architecture) {
    this.architecture = architecture;
  }

  public DistributionInspectResponsePlatforms architecture(String architecture) {
    this.architecture = architecture;
    return this;
  }

 /**
   * Get OS
   * @return OS
  **/
  @JsonProperty("OS")
  public String getOS() {
    return OS;
  }

  public void setOS(String OS) {
    this.OS = OS;
  }

  public DistributionInspectResponsePlatforms OS(String OS) {
    this.OS = OS;
    return this;
  }

 /**
   * Get osVersion
   * @return osVersion
  **/
  @JsonProperty("OSVersion")
  public String getOsVersion() {
    return osVersion;
  }

  public void setOsVersion(String osVersion) {
    this.osVersion = osVersion;
  }

  public DistributionInspectResponsePlatforms osVersion(String osVersion) {
    this.osVersion = osVersion;
    return this;
  }

 /**
   * Get osFeatures
   * @return osFeatures
  **/
  @JsonProperty("OSFeatures")
  public List<String> getOsFeatures() {
    return osFeatures;
  }

  public void setOsFeatures(List<String> osFeatures) {
    this.osFeatures = osFeatures;
  }

  public DistributionInspectResponsePlatforms osFeatures(List<String> osFeatures) {
    this.osFeatures = osFeatures;
    return this;
  }

  public DistributionInspectResponsePlatforms addOsFeaturesItem(String osFeaturesItem) {
    this.osFeatures.add(osFeaturesItem);
    return this;
  }

 /**
   * Get variant
   * @return variant
  **/
  @JsonProperty("Variant")
  public String getVariant() {
    return variant;
  }

  public void setVariant(String variant) {
    this.variant = variant;
  }

  public DistributionInspectResponsePlatforms variant(String variant) {
    this.variant = variant;
    return this;
  }

 /**
   * Get features
   * @return features
  **/
  @JsonProperty("Features")
  public List<String> getFeatures() {
    return features;
  }

  public void setFeatures(List<String> features) {
    this.features = features;
  }

  public DistributionInspectResponsePlatforms features(List<String> features) {
    this.features = features;
    return this;
  }

  public DistributionInspectResponsePlatforms addFeaturesItem(String featuresItem) {
    this.features.add(featuresItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class DistributionInspectResponsePlatforms {\n");
    
    sb.append("    architecture: ").append(toIndentedString(architecture)).append("\n");
    sb.append("    OS: ").append(toIndentedString(OS)).append("\n");
    sb.append("    osVersion: ").append(toIndentedString(osVersion)).append("\n");
    sb.append("    osFeatures: ").append(toIndentedString(osFeatures)).append("\n");
    sb.append("    variant: ").append(toIndentedString(variant)).append("\n");
    sb.append("    features: ").append(toIndentedString(features)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

