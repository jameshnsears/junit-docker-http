package io.swagger.model;

import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ProcessConfig  {
  
  @ApiModelProperty(value = "")
  private Boolean privileged = null;

  @ApiModelProperty(value = "")
  private String user = null;

  @ApiModelProperty(value = "")
  private Boolean tty = null;

  @ApiModelProperty(value = "")
  private String entrypoint = null;

  @ApiModelProperty(value = "")
  private List<String> arguments = null;
 /**
   * Get privileged
   * @return privileged
  **/
  @JsonProperty("privileged")
  public Boolean isPrivileged() {
    return privileged;
  }

  public void setPrivileged(Boolean privileged) {
    this.privileged = privileged;
  }

  public ProcessConfig privileged(Boolean privileged) {
    this.privileged = privileged;
    return this;
  }

 /**
   * Get user
   * @return user
  **/
  @JsonProperty("user")
  public String getUser() {
    return user;
  }

  public void setUser(String user) {
    this.user = user;
  }

  public ProcessConfig user(String user) {
    this.user = user;
    return this;
  }

 /**
   * Get tty
   * @return tty
  **/
  @JsonProperty("tty")
  public Boolean isTty() {
    return tty;
  }

  public void setTty(Boolean tty) {
    this.tty = tty;
  }

  public ProcessConfig tty(Boolean tty) {
    this.tty = tty;
    return this;
  }

 /**
   * Get entrypoint
   * @return entrypoint
  **/
  @JsonProperty("entrypoint")
  public String getEntrypoint() {
    return entrypoint;
  }

  public void setEntrypoint(String entrypoint) {
    this.entrypoint = entrypoint;
  }

  public ProcessConfig entrypoint(String entrypoint) {
    this.entrypoint = entrypoint;
    return this;
  }

 /**
   * Get arguments
   * @return arguments
  **/
  @JsonProperty("arguments")
  public List<String> getArguments() {
    return arguments;
  }

  public void setArguments(List<String> arguments) {
    this.arguments = arguments;
  }

  public ProcessConfig arguments(List<String> arguments) {
    this.arguments = arguments;
    return this;
  }

  public ProcessConfig addArgumentsItem(String argumentsItem) {
    this.arguments.add(argumentsItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ProcessConfig {\n");
    
    sb.append("    privileged: ").append(toIndentedString(privileged)).append("\n");
    sb.append("    user: ").append(toIndentedString(user)).append("\n");
    sb.append("    tty: ").append(toIndentedString(tty)).append("\n");
    sb.append("    entrypoint: ").append(toIndentedString(entrypoint)).append("\n");
    sb.append("    arguments: ").append(toIndentedString(arguments)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

