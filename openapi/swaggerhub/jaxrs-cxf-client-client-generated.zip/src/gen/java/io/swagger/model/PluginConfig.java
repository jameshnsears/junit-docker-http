package io.swagger.model;

import io.swagger.annotations.ApiModel;
import io.swagger.model.PluginConfigArgs;
import io.swagger.model.PluginConfigInterface;
import io.swagger.model.PluginConfigLinux;
import io.swagger.model.PluginConfigNetwork;
import io.swagger.model.PluginConfigRootfs;
import io.swagger.model.PluginConfigUser;
import io.swagger.model.PluginEnv;
import io.swagger.model.PluginMount;
import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * The config of a plugin.
 **/
@ApiModel(description="The config of a plugin.")
public class PluginConfig  {
  
  @ApiModelProperty(example = "17.06.0-ce", value = "Docker Version used to create the plugin")
 /**
   * Docker Version used to create the plugin  
  **/
  private String dockerVersion = null;

  @ApiModelProperty(example = "A sample volume plugin for Docker", required = true, value = "")
  private String description = null;

  @ApiModelProperty(example = "https://docs.docker.com/engine/extend/plugins/", required = true, value = "")
  private String documentation = null;

  @ApiModelProperty(required = true, value = "")
  private PluginConfigInterface _interface = null;

  @ApiModelProperty(example = "[\"/usr/bin/sample-volume-plugin\",\"/data\"]", required = true, value = "")
  private List<String> entrypoint = new ArrayList<String>();

  @ApiModelProperty(example = "/bin/", required = true, value = "")
  private String workDir = null;

  @ApiModelProperty(value = "")
  private PluginConfigUser user = null;

  @ApiModelProperty(required = true, value = "")
  private PluginConfigNetwork network = null;

  @ApiModelProperty(required = true, value = "")
  private PluginConfigLinux linux = null;

  @ApiModelProperty(example = "/mnt/volumes", required = true, value = "")
  private String propagatedMount = null;

  @ApiModelProperty(example = "false", required = true, value = "")
  private Boolean ipcHost = null;

  @ApiModelProperty(example = "false", required = true, value = "")
  private Boolean pidHost = null;

  @ApiModelProperty(required = true, value = "")
  private List<PluginMount> mounts = new ArrayList<PluginMount>();

  @ApiModelProperty(example = "[{\"Name\":\"DEBUG\",\"Description\":\"If set, prints debug messages\",\"Value\":\"0\"}]", required = true, value = "")
  private List<PluginEnv> env = new ArrayList<PluginEnv>();

  @ApiModelProperty(required = true, value = "")
  private PluginConfigArgs args = null;

  @ApiModelProperty(value = "")
  private PluginConfigRootfs rootfs = null;
 /**
   * Docker Version used to create the plugin
   * @return dockerVersion
  **/
  @JsonProperty("DockerVersion")
  public String getDockerVersion() {
    return dockerVersion;
  }

  public void setDockerVersion(String dockerVersion) {
    this.dockerVersion = dockerVersion;
  }

  public PluginConfig dockerVersion(String dockerVersion) {
    this.dockerVersion = dockerVersion;
    return this;
  }

 /**
   * Get description
   * @return description
  **/
  @JsonProperty("Description")
  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public PluginConfig description(String description) {
    this.description = description;
    return this;
  }

 /**
   * Get documentation
   * @return documentation
  **/
  @JsonProperty("Documentation")
  public String getDocumentation() {
    return documentation;
  }

  public void setDocumentation(String documentation) {
    this.documentation = documentation;
  }

  public PluginConfig documentation(String documentation) {
    this.documentation = documentation;
    return this;
  }

 /**
   * Get _interface
   * @return _interface
  **/
  @JsonProperty("Interface")
  public PluginConfigInterface getInterface() {
    return _interface;
  }

  public void setInterface(PluginConfigInterface _interface) {
    this._interface = _interface;
  }

  public PluginConfig _interface(PluginConfigInterface _interface) {
    this._interface = _interface;
    return this;
  }

 /**
   * Get entrypoint
   * @return entrypoint
  **/
  @JsonProperty("Entrypoint")
  public List<String> getEntrypoint() {
    return entrypoint;
  }

  public void setEntrypoint(List<String> entrypoint) {
    this.entrypoint = entrypoint;
  }

  public PluginConfig entrypoint(List<String> entrypoint) {
    this.entrypoint = entrypoint;
    return this;
  }

  public PluginConfig addEntrypointItem(String entrypointItem) {
    this.entrypoint.add(entrypointItem);
    return this;
  }

 /**
   * Get workDir
   * @return workDir
  **/
  @JsonProperty("WorkDir")
  public String getWorkDir() {
    return workDir;
  }

  public void setWorkDir(String workDir) {
    this.workDir = workDir;
  }

  public PluginConfig workDir(String workDir) {
    this.workDir = workDir;
    return this;
  }

 /**
   * Get user
   * @return user
  **/
  @JsonProperty("User")
  public PluginConfigUser getUser() {
    return user;
  }

  public void setUser(PluginConfigUser user) {
    this.user = user;
  }

  public PluginConfig user(PluginConfigUser user) {
    this.user = user;
    return this;
  }

 /**
   * Get network
   * @return network
  **/
  @JsonProperty("Network")
  public PluginConfigNetwork getNetwork() {
    return network;
  }

  public void setNetwork(PluginConfigNetwork network) {
    this.network = network;
  }

  public PluginConfig network(PluginConfigNetwork network) {
    this.network = network;
    return this;
  }

 /**
   * Get linux
   * @return linux
  **/
  @JsonProperty("Linux")
  public PluginConfigLinux getLinux() {
    return linux;
  }

  public void setLinux(PluginConfigLinux linux) {
    this.linux = linux;
  }

  public PluginConfig linux(PluginConfigLinux linux) {
    this.linux = linux;
    return this;
  }

 /**
   * Get propagatedMount
   * @return propagatedMount
  **/
  @JsonProperty("PropagatedMount")
  public String getPropagatedMount() {
    return propagatedMount;
  }

  public void setPropagatedMount(String propagatedMount) {
    this.propagatedMount = propagatedMount;
  }

  public PluginConfig propagatedMount(String propagatedMount) {
    this.propagatedMount = propagatedMount;
    return this;
  }

 /**
   * Get ipcHost
   * @return ipcHost
  **/
  @JsonProperty("IpcHost")
  public Boolean isIpcHost() {
    return ipcHost;
  }

  public void setIpcHost(Boolean ipcHost) {
    this.ipcHost = ipcHost;
  }

  public PluginConfig ipcHost(Boolean ipcHost) {
    this.ipcHost = ipcHost;
    return this;
  }

 /**
   * Get pidHost
   * @return pidHost
  **/
  @JsonProperty("PidHost")
  public Boolean isPidHost() {
    return pidHost;
  }

  public void setPidHost(Boolean pidHost) {
    this.pidHost = pidHost;
  }

  public PluginConfig pidHost(Boolean pidHost) {
    this.pidHost = pidHost;
    return this;
  }

 /**
   * Get mounts
   * @return mounts
  **/
  @JsonProperty("Mounts")
  public List<PluginMount> getMounts() {
    return mounts;
  }

  public void setMounts(List<PluginMount> mounts) {
    this.mounts = mounts;
  }

  public PluginConfig mounts(List<PluginMount> mounts) {
    this.mounts = mounts;
    return this;
  }

  public PluginConfig addMountsItem(PluginMount mountsItem) {
    this.mounts.add(mountsItem);
    return this;
  }

 /**
   * Get env
   * @return env
  **/
  @JsonProperty("Env")
  public List<PluginEnv> getEnv() {
    return env;
  }

  public void setEnv(List<PluginEnv> env) {
    this.env = env;
  }

  public PluginConfig env(List<PluginEnv> env) {
    this.env = env;
    return this;
  }

  public PluginConfig addEnvItem(PluginEnv envItem) {
    this.env.add(envItem);
    return this;
  }

 /**
   * Get args
   * @return args
  **/
  @JsonProperty("Args")
  public PluginConfigArgs getArgs() {
    return args;
  }

  public void setArgs(PluginConfigArgs args) {
    this.args = args;
  }

  public PluginConfig args(PluginConfigArgs args) {
    this.args = args;
    return this;
  }

 /**
   * Get rootfs
   * @return rootfs
  **/
  @JsonProperty("rootfs")
  public PluginConfigRootfs getRootfs() {
    return rootfs;
  }

  public void setRootfs(PluginConfigRootfs rootfs) {
    this.rootfs = rootfs;
  }

  public PluginConfig rootfs(PluginConfigRootfs rootfs) {
    this.rootfs = rootfs;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PluginConfig {\n");
    
    sb.append("    dockerVersion: ").append(toIndentedString(dockerVersion)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("    documentation: ").append(toIndentedString(documentation)).append("\n");
    sb.append("    _interface: ").append(toIndentedString(_interface)).append("\n");
    sb.append("    entrypoint: ").append(toIndentedString(entrypoint)).append("\n");
    sb.append("    workDir: ").append(toIndentedString(workDir)).append("\n");
    sb.append("    user: ").append(toIndentedString(user)).append("\n");
    sb.append("    network: ").append(toIndentedString(network)).append("\n");
    sb.append("    linux: ").append(toIndentedString(linux)).append("\n");
    sb.append("    propagatedMount: ").append(toIndentedString(propagatedMount)).append("\n");
    sb.append("    ipcHost: ").append(toIndentedString(ipcHost)).append("\n");
    sb.append("    pidHost: ").append(toIndentedString(pidHost)).append("\n");
    sb.append("    mounts: ").append(toIndentedString(mounts)).append("\n");
    sb.append("    env: ").append(toIndentedString(env)).append("\n");
    sb.append("    args: ").append(toIndentedString(args)).append("\n");
    sb.append("    rootfs: ").append(toIndentedString(rootfs)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

