package io.swagger.model;

import io.swagger.annotations.ApiModel;
import io.swagger.model.IndexInfo;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * RegistryServiceConfig stores daemon registry services configuration. 
 **/
@ApiModel(description="RegistryServiceConfig stores daemon registry services configuration. ")
public class RegistryServiceConfig  {
  
  @ApiModelProperty(example = "[\"::1/128\",\"127.0.0.0/8\"]", value = "List of IP ranges to which nondistributable artifacts can be pushed, using the CIDR syntax [RFC 4632](https://tools.ietf.org/html/4632).  Some images (for example, Windows base images) contain artifacts whose distribution is restricted by license. When these images are pushed to a registry, restricted artifacts are not included.  This configuration override this behavior, and enables the daemon to push nondistributable artifacts to all registries whose resolved IP address is within the subnet described by the CIDR syntax.  This option is useful when pushing images containing nondistributable artifacts to a registry on an air-gapped network so hosts on that network can pull the images without connecting to another server.  > **Warning**: Nondistributable artifacts typically have restrictions > on how and where they can be distributed and shared. Only use this > feature to push artifacts to private registries and ensure that you > are in compliance with any terms that cover redistributing > nondistributable artifacts. ")
 /**
   * List of IP ranges to which nondistributable artifacts can be pushed, using the CIDR syntax [RFC 4632](https://tools.ietf.org/html/4632).  Some images (for example, Windows base images) contain artifacts whose distribution is restricted by license. When these images are pushed to a registry, restricted artifacts are not included.  This configuration override this behavior, and enables the daemon to push nondistributable artifacts to all registries whose resolved IP address is within the subnet described by the CIDR syntax.  This option is useful when pushing images containing nondistributable artifacts to a registry on an air-gapped network so hosts on that network can pull the images without connecting to another server.  > **Warning**: Nondistributable artifacts typically have restrictions > on how and where they can be distributed and shared. Only use this > feature to push artifacts to private registries and ensure that you > are in compliance with any terms that cover redistributing > nondistributable artifacts.   
  **/
  private List<String> allowNondistributableArtifactsCIDRs = null;

  @ApiModelProperty(example = "[\"registry.internal.corp.example.com:3000\",\"[2001:db8:a0b:12f0::1]:443\"]", value = "List of registry hostnames to which nondistributable artifacts can be pushed, using the format `<hostname>[:<port>]` or `<IP address>[:<port>]`.  Some images (for example, Windows base images) contain artifacts whose distribution is restricted by license. When these images are pushed to a registry, restricted artifacts are not included.  This configuration override this behavior for the specified registries.  This option is useful when pushing images containing nondistributable artifacts to a registry on an air-gapped network so hosts on that network can pull the images without connecting to another server.  > **Warning**: Nondistributable artifacts typically have restrictions > on how and where they can be distributed and shared. Only use this > feature to push artifacts to private registries and ensure that you > are in compliance with any terms that cover redistributing > nondistributable artifacts. ")
 /**
   * List of registry hostnames to which nondistributable artifacts can be pushed, using the format `<hostname>[:<port>]` or `<IP address>[:<port>]`.  Some images (for example, Windows base images) contain artifacts whose distribution is restricted by license. When these images are pushed to a registry, restricted artifacts are not included.  This configuration override this behavior for the specified registries.  This option is useful when pushing images containing nondistributable artifacts to a registry on an air-gapped network so hosts on that network can pull the images without connecting to another server.  > **Warning**: Nondistributable artifacts typically have restrictions > on how and where they can be distributed and shared. Only use this > feature to push artifacts to private registries and ensure that you > are in compliance with any terms that cover redistributing > nondistributable artifacts.   
  **/
  private List<String> allowNondistributableArtifactsHostnames = null;

  @ApiModelProperty(example = "[\"::1/128\",\"127.0.0.0/8\"]", value = "List of IP ranges of insecure registries, using the CIDR syntax ([RFC 4632](https://tools.ietf.org/html/4632)). Insecure registries accept un-encrypted (HTTP) and/or untrusted (HTTPS with certificates from unknown CAs) communication.  By default, local registries (`127.0.0.0/8`) are configured as insecure. All other registries are secure. Communicating with an insecure registry is not possible if the daemon assumes that registry is secure.  This configuration override this behavior, insecure communication with registries whose resolved IP address is within the subnet described by the CIDR syntax.  Registries can also be marked insecure by hostname. Those registries are listed under `IndexConfigs` and have their `Secure` field set to `false`.  > **Warning**: Using this option can be useful when running a local > registry, but introduces security vulnerabilities. This option > should therefore ONLY be used for testing purposes. For increased > security, users should add their CA to their system's list of trusted > CAs instead of enabling this option. ")
 /**
   * List of IP ranges of insecure registries, using the CIDR syntax ([RFC 4632](https://tools.ietf.org/html/4632)). Insecure registries accept un-encrypted (HTTP) and/or untrusted (HTTPS with certificates from unknown CAs) communication.  By default, local registries (`127.0.0.0/8`) are configured as insecure. All other registries are secure. Communicating with an insecure registry is not possible if the daemon assumes that registry is secure.  This configuration override this behavior, insecure communication with registries whose resolved IP address is within the subnet described by the CIDR syntax.  Registries can also be marked insecure by hostname. Those registries are listed under `IndexConfigs` and have their `Secure` field set to `false`.  > **Warning**: Using this option can be useful when running a local > registry, but introduces security vulnerabilities. This option > should therefore ONLY be used for testing purposes. For increased > security, users should add their CA to their system's list of trusted > CAs instead of enabling this option.   
  **/
  private List<String> insecureRegistryCIDRs = null;

  @ApiModelProperty(example = "{\"127.0.0.1:5000\":{\"Name\":\"127.0.0.1:5000\",\"Mirrors\":[],\"Secure\":false,\"Official\":false},\"[2001:db8:a0b:12f0::1]:80\":{\"Name\":\"[2001:db8:a0b:12f0::1]:80\",\"Mirrors\":[],\"Secure\":false,\"Official\":false},\"docker.io\":{\"Name\":\"docker.io\",\"Mirrors\":[\"https://hub-mirror.corp.example.com:5000/\"],\"Secure\":true,\"Official\":true},\"registry.internal.corp.example.com:3000\":{\"Name\":\"registry.internal.corp.example.com:3000\",\"Mirrors\":[],\"Secure\":false,\"Official\":false}}", value = "")
  private Map<String, IndexInfo> indexConfigs = null;

  @ApiModelProperty(example = "[\"https://hub-mirror.corp.example.com:5000/\",\"https://[2001:db8:a0b:12f0::1]/\"]", value = "List of registry URLs that act as a mirror for the official (`docker.io`) registry. ")
 /**
   * List of registry URLs that act as a mirror for the official (`docker.io`) registry.   
  **/
  private List<String> mirrors = null;
 /**
   * List of IP ranges to which nondistributable artifacts can be pushed, using the CIDR syntax [RFC 4632](https://tools.ietf.org/html/4632).  Some images (for example, Windows base images) contain artifacts whose distribution is restricted by license. When these images are pushed to a registry, restricted artifacts are not included.  This configuration override this behavior, and enables the daemon to push nondistributable artifacts to all registries whose resolved IP address is within the subnet described by the CIDR syntax.  This option is useful when pushing images containing nondistributable artifacts to a registry on an air-gapped network so hosts on that network can pull the images without connecting to another server.  &gt; **Warning**: Nondistributable artifacts typically have restrictions &gt; on how and where they can be distributed and shared. Only use this &gt; feature to push artifacts to private registries and ensure that you &gt; are in compliance with any terms that cover redistributing &gt; nondistributable artifacts. 
   * @return allowNondistributableArtifactsCIDRs
  **/
  @JsonProperty("AllowNondistributableArtifactsCIDRs")
  public List<String> getAllowNondistributableArtifactsCIDRs() {
    return allowNondistributableArtifactsCIDRs;
  }

  public void setAllowNondistributableArtifactsCIDRs(List<String> allowNondistributableArtifactsCIDRs) {
    this.allowNondistributableArtifactsCIDRs = allowNondistributableArtifactsCIDRs;
  }

  public RegistryServiceConfig allowNondistributableArtifactsCIDRs(List<String> allowNondistributableArtifactsCIDRs) {
    this.allowNondistributableArtifactsCIDRs = allowNondistributableArtifactsCIDRs;
    return this;
  }

  public RegistryServiceConfig addAllowNondistributableArtifactsCIDRsItem(String allowNondistributableArtifactsCIDRsItem) {
    this.allowNondistributableArtifactsCIDRs.add(allowNondistributableArtifactsCIDRsItem);
    return this;
  }

 /**
   * List of registry hostnames to which nondistributable artifacts can be pushed, using the format &#x60;&lt;hostname&gt;[:&lt;port&gt;]&#x60; or &#x60;&lt;IP address&gt;[:&lt;port&gt;]&#x60;.  Some images (for example, Windows base images) contain artifacts whose distribution is restricted by license. When these images are pushed to a registry, restricted artifacts are not included.  This configuration override this behavior for the specified registries.  This option is useful when pushing images containing nondistributable artifacts to a registry on an air-gapped network so hosts on that network can pull the images without connecting to another server.  &gt; **Warning**: Nondistributable artifacts typically have restrictions &gt; on how and where they can be distributed and shared. Only use this &gt; feature to push artifacts to private registries and ensure that you &gt; are in compliance with any terms that cover redistributing &gt; nondistributable artifacts. 
   * @return allowNondistributableArtifactsHostnames
  **/
  @JsonProperty("AllowNondistributableArtifactsHostnames")
  public List<String> getAllowNondistributableArtifactsHostnames() {
    return allowNondistributableArtifactsHostnames;
  }

  public void setAllowNondistributableArtifactsHostnames(List<String> allowNondistributableArtifactsHostnames) {
    this.allowNondistributableArtifactsHostnames = allowNondistributableArtifactsHostnames;
  }

  public RegistryServiceConfig allowNondistributableArtifactsHostnames(List<String> allowNondistributableArtifactsHostnames) {
    this.allowNondistributableArtifactsHostnames = allowNondistributableArtifactsHostnames;
    return this;
  }

  public RegistryServiceConfig addAllowNondistributableArtifactsHostnamesItem(String allowNondistributableArtifactsHostnamesItem) {
    this.allowNondistributableArtifactsHostnames.add(allowNondistributableArtifactsHostnamesItem);
    return this;
  }

 /**
   * List of IP ranges of insecure registries, using the CIDR syntax ([RFC 4632](https://tools.ietf.org/html/4632)). Insecure registries accept un-encrypted (HTTP) and/or untrusted (HTTPS with certificates from unknown CAs) communication.  By default, local registries (&#x60;127.0.0.0/8&#x60;) are configured as insecure. All other registries are secure. Communicating with an insecure registry is not possible if the daemon assumes that registry is secure.  This configuration override this behavior, insecure communication with registries whose resolved IP address is within the subnet described by the CIDR syntax.  Registries can also be marked insecure by hostname. Those registries are listed under &#x60;IndexConfigs&#x60; and have their &#x60;Secure&#x60; field set to &#x60;false&#x60;.  &gt; **Warning**: Using this option can be useful when running a local &gt; registry, but introduces security vulnerabilities. This option &gt; should therefore ONLY be used for testing purposes. For increased &gt; security, users should add their CA to their system&#39;s list of trusted &gt; CAs instead of enabling this option. 
   * @return insecureRegistryCIDRs
  **/
  @JsonProperty("InsecureRegistryCIDRs")
  public List<String> getInsecureRegistryCIDRs() {
    return insecureRegistryCIDRs;
  }

  public void setInsecureRegistryCIDRs(List<String> insecureRegistryCIDRs) {
    this.insecureRegistryCIDRs = insecureRegistryCIDRs;
  }

  public RegistryServiceConfig insecureRegistryCIDRs(List<String> insecureRegistryCIDRs) {
    this.insecureRegistryCIDRs = insecureRegistryCIDRs;
    return this;
  }

  public RegistryServiceConfig addInsecureRegistryCIDRsItem(String insecureRegistryCIDRsItem) {
    this.insecureRegistryCIDRs.add(insecureRegistryCIDRsItem);
    return this;
  }

 /**
   * Get indexConfigs
   * @return indexConfigs
  **/
  @JsonProperty("IndexConfigs")
  public Map<String, IndexInfo> getIndexConfigs() {
    return indexConfigs;
  }

  public void setIndexConfigs(Map<String, IndexInfo> indexConfigs) {
    this.indexConfigs = indexConfigs;
  }

  public RegistryServiceConfig indexConfigs(Map<String, IndexInfo> indexConfigs) {
    this.indexConfigs = indexConfigs;
    return this;
  }

  public RegistryServiceConfig putIndexConfigsItem(String key, IndexInfo indexConfigsItem) {
    this.indexConfigs.put(key, indexConfigsItem);
    return this;
  }

 /**
   * List of registry URLs that act as a mirror for the official (&#x60;docker.io&#x60;) registry. 
   * @return mirrors
  **/
  @JsonProperty("Mirrors")
  public List<String> getMirrors() {
    return mirrors;
  }

  public void setMirrors(List<String> mirrors) {
    this.mirrors = mirrors;
  }

  public RegistryServiceConfig mirrors(List<String> mirrors) {
    this.mirrors = mirrors;
    return this;
  }

  public RegistryServiceConfig addMirrorsItem(String mirrorsItem) {
    this.mirrors.add(mirrorsItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RegistryServiceConfig {\n");
    
    sb.append("    allowNondistributableArtifactsCIDRs: ").append(toIndentedString(allowNondistributableArtifactsCIDRs)).append("\n");
    sb.append("    allowNondistributableArtifactsHostnames: ").append(toIndentedString(allowNondistributableArtifactsHostnames)).append("\n");
    sb.append("    insecureRegistryCIDRs: ").append(toIndentedString(insecureRegistryCIDRs)).append("\n");
    sb.append("    indexConfigs: ").append(toIndentedString(indexConfigs)).append("\n");
    sb.append("    mirrors: ").append(toIndentedString(mirrors)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

