package io.swagger.model;

import io.swagger.annotations.ApiModel;
import io.swagger.model.Body;
import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * Plugin spec for the service.  *(Experimental release only.)*  <p><br /></p>  > **Note**: ContainerSpec, NetworkAttachmentSpec, and PluginSpec are > mutually exclusive. PluginSpec is only used when the Runtime field > is set to `plugin`. NetworkAttachmentSpec is used when the Runtime > field is set to `attachment`. 
 **/
@ApiModel(description="Plugin spec for the service.  *(Experimental release only.)*  <p><br /></p>  > **Note**: ContainerSpec, NetworkAttachmentSpec, and PluginSpec are > mutually exclusive. PluginSpec is only used when the Runtime field > is set to `plugin`. NetworkAttachmentSpec is used when the Runtime > field is set to `attachment`. ")
public class TaskSpecPluginSpec  {
  
  @ApiModelProperty(value = "The name or 'alias' to use for the plugin.")
 /**
   * The name or 'alias' to use for the plugin.  
  **/
  private String name = null;

  @ApiModelProperty(value = "The plugin image reference to use.")
 /**
   * The plugin image reference to use.  
  **/
  private String remote = null;

  @ApiModelProperty(value = "Disable the plugin once scheduled.")
 /**
   * Disable the plugin once scheduled.  
  **/
  private Boolean disabled = null;

  @ApiModelProperty(value = "")
  private List<Body> pluginPrivilege = null;
 /**
   * The name or &#39;alias&#39; to use for the plugin.
   * @return name
  **/
  @JsonProperty("Name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public TaskSpecPluginSpec name(String name) {
    this.name = name;
    return this;
  }

 /**
   * The plugin image reference to use.
   * @return remote
  **/
  @JsonProperty("Remote")
  public String getRemote() {
    return remote;
  }

  public void setRemote(String remote) {
    this.remote = remote;
  }

  public TaskSpecPluginSpec remote(String remote) {
    this.remote = remote;
    return this;
  }

 /**
   * Disable the plugin once scheduled.
   * @return disabled
  **/
  @JsonProperty("Disabled")
  public Boolean isDisabled() {
    return disabled;
  }

  public void setDisabled(Boolean disabled) {
    this.disabled = disabled;
  }

  public TaskSpecPluginSpec disabled(Boolean disabled) {
    this.disabled = disabled;
    return this;
  }

 /**
   * Get pluginPrivilege
   * @return pluginPrivilege
  **/
  @JsonProperty("PluginPrivilege")
  public List<Body> getPluginPrivilege() {
    return pluginPrivilege;
  }

  public void setPluginPrivilege(List<Body> pluginPrivilege) {
    this.pluginPrivilege = pluginPrivilege;
  }

  public TaskSpecPluginSpec pluginPrivilege(List<Body> pluginPrivilege) {
    this.pluginPrivilege = pluginPrivilege;
    return this;
  }

  public TaskSpecPluginSpec addPluginPrivilegeItem(Body pluginPrivilegeItem) {
    this.pluginPrivilege.add(pluginPrivilegeItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TaskSpecPluginSpec {\n");
    
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    remote: ").append(toIndentedString(remote)).append("\n");
    sb.append("    disabled: ").append(toIndentedString(disabled)).append("\n");
    sb.append("    pluginPrivilege: ").append(toIndentedString(pluginPrivilege)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

