package io.swagger.model;

import io.swagger.annotations.ApiModel;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * An open port on a container
 **/
@ApiModel(description="An open port on a container")
public class Port  {
  
  @ApiModelProperty(value = "Host IP address that the container's port is mapped to")
 /**
   * Host IP address that the container's port is mapped to  
  **/
  private String IP = null;

  @ApiModelProperty(required = true, value = "Port on the container")
 /**
   * Port on the container  
  **/
  private Integer privatePort = null;

  @ApiModelProperty(value = "Port exposed on the host")
 /**
   * Port exposed on the host  
  **/
  private Integer publicPort = null;


@XmlType(name="TypeEnum")
@XmlEnum(String.class)
public enum TypeEnum {

@XmlEnumValue("tcp") TCP(String.valueOf("tcp")), @XmlEnumValue("udp") UDP(String.valueOf("udp")), @XmlEnumValue("sctp") SCTP(String.valueOf("sctp"));


    private String value;

    TypeEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static TypeEnum fromValue(String v) {
        for (TypeEnum b : TypeEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(required = true, value = "")
  private TypeEnum type = null;
 /**
   * Host IP address that the container&#39;s port is mapped to
   * @return IP
  **/
  @JsonProperty("IP")
  public String getIP() {
    return IP;
  }

  public void setIP(String IP) {
    this.IP = IP;
  }

  public Port IP(String IP) {
    this.IP = IP;
    return this;
  }

 /**
   * Port on the container
   * @return privatePort
  **/
  @JsonProperty("PrivatePort")
  public Integer getPrivatePort() {
    return privatePort;
  }

  public void setPrivatePort(Integer privatePort) {
    this.privatePort = privatePort;
  }

  public Port privatePort(Integer privatePort) {
    this.privatePort = privatePort;
    return this;
  }

 /**
   * Port exposed on the host
   * @return publicPort
  **/
  @JsonProperty("PublicPort")
  public Integer getPublicPort() {
    return publicPort;
  }

  public void setPublicPort(Integer publicPort) {
    this.publicPort = publicPort;
  }

  public Port publicPort(Integer publicPort) {
    this.publicPort = publicPort;
    return this;
  }

 /**
   * Get type
   * @return type
  **/
  @JsonProperty("Type")
  public String getType() {
    if (type == null) {
      return null;
    }
    return type.value();
  }

  public void setType(TypeEnum type) {
    this.type = type;
  }

  public Port type(TypeEnum type) {
    this.type = type;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Port {\n");
    
    sb.append("    IP: ").append(toIndentedString(IP)).append("\n");
    sb.append("    privatePort: ").append(toIndentedString(privatePort)).append("\n");
    sb.append("    publicPort: ").append(toIndentedString(publicPort)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

