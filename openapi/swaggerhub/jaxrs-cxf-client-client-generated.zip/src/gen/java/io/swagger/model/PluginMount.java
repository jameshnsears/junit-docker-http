package io.swagger.model;

import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class PluginMount  {
  
  @ApiModelProperty(example = "some-mount", required = true, value = "")
  private String name = null;

  @ApiModelProperty(example = "This is a mount that's used by the plugin.", required = true, value = "")
  private String description = null;

  @ApiModelProperty(required = true, value = "")
  private List<String> settable = new ArrayList<String>();

  @ApiModelProperty(example = "/var/lib/docker/plugins/", required = true, value = "")
  private String source = null;

  @ApiModelProperty(example = "/mnt/state", required = true, value = "")
  private String destination = null;

  @ApiModelProperty(example = "bind", required = true, value = "")
  private String type = null;

  @ApiModelProperty(example = "[\"rbind\",\"rw\"]", required = true, value = "")
  private List<String> options = new ArrayList<String>();
 /**
   * Get name
   * @return name
  **/
  @JsonProperty("Name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public PluginMount name(String name) {
    this.name = name;
    return this;
  }

 /**
   * Get description
   * @return description
  **/
  @JsonProperty("Description")
  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public PluginMount description(String description) {
    this.description = description;
    return this;
  }

 /**
   * Get settable
   * @return settable
  **/
  @JsonProperty("Settable")
  public List<String> getSettable() {
    return settable;
  }

  public void setSettable(List<String> settable) {
    this.settable = settable;
  }

  public PluginMount settable(List<String> settable) {
    this.settable = settable;
    return this;
  }

  public PluginMount addSettableItem(String settableItem) {
    this.settable.add(settableItem);
    return this;
  }

 /**
   * Get source
   * @return source
  **/
  @JsonProperty("Source")
  public String getSource() {
    return source;
  }

  public void setSource(String source) {
    this.source = source;
  }

  public PluginMount source(String source) {
    this.source = source;
    return this;
  }

 /**
   * Get destination
   * @return destination
  **/
  @JsonProperty("Destination")
  public String getDestination() {
    return destination;
  }

  public void setDestination(String destination) {
    this.destination = destination;
  }

  public PluginMount destination(String destination) {
    this.destination = destination;
    return this;
  }

 /**
   * Get type
   * @return type
  **/
  @JsonProperty("Type")
  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public PluginMount type(String type) {
    this.type = type;
    return this;
  }

 /**
   * Get options
   * @return options
  **/
  @JsonProperty("Options")
  public List<String> getOptions() {
    return options;
  }

  public void setOptions(List<String> options) {
    this.options = options;
  }

  public PluginMount options(List<String> options) {
    this.options = options;
    return this;
  }

  public PluginMount addOptionsItem(String optionsItem) {
    this.options.add(optionsItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PluginMount {\n");
    
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("    settable: ").append(toIndentedString(settable)).append("\n");
    sb.append("    source: ").append(toIndentedString(source)).append("\n");
    sb.append("    destination: ").append(toIndentedString(destination)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    options: ").append(toIndentedString(options)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

