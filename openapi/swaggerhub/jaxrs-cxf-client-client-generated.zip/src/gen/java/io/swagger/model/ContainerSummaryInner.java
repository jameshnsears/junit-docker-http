package io.swagger.model;

import io.swagger.model.ContainerSummaryInnerHostConfig;
import io.swagger.model.ContainerSummaryInnerNetworkSettings;
import io.swagger.model.Mount;
import io.swagger.model.Port;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ContainerSummaryInner  {
  
  @ApiModelProperty(value = "The ID of this container")
 /**
   * The ID of this container  
  **/
  private String id = null;

  @ApiModelProperty(value = "The names that this container has been given")
 /**
   * The names that this container has been given  
  **/
  private List<String> names = null;

  @ApiModelProperty(value = "The name of the image used when creating this container")
 /**
   * The name of the image used when creating this container  
  **/
  private String image = null;

  @ApiModelProperty(value = "The ID of the image that this container was created from")
 /**
   * The ID of the image that this container was created from  
  **/
  private String imageID = null;

  @ApiModelProperty(value = "Command to run when starting the container")
 /**
   * Command to run when starting the container  
  **/
  private String command = null;

  @ApiModelProperty(value = "When the container was created")
 /**
   * When the container was created  
  **/
  private Long created = null;

  @ApiModelProperty(value = "The ports exposed by this container")
 /**
   * The ports exposed by this container  
  **/
  private List<Port> ports = null;

  @ApiModelProperty(value = "The size of files that have been created or changed by this container")
 /**
   * The size of files that have been created or changed by this container  
  **/
  private Long sizeRw = null;

  @ApiModelProperty(value = "The total size of all the files in this container")
 /**
   * The total size of all the files in this container  
  **/
  private Long sizeRootFs = null;

  @ApiModelProperty(value = "User-defined key/value metadata.")
 /**
   * User-defined key/value metadata.  
  **/
  private Map<String, String> labels = null;

  @ApiModelProperty(value = "The state of this container (e.g. `Exited`)")
 /**
   * The state of this container (e.g. `Exited`)  
  **/
  private String state = null;

  @ApiModelProperty(value = "Additional human-readable status of this container (e.g. `Exit 0`)")
 /**
   * Additional human-readable status of this container (e.g. `Exit 0`)  
  **/
  private String status = null;

  @ApiModelProperty(value = "")
  private ContainerSummaryInnerHostConfig hostConfig = null;

  @ApiModelProperty(value = "")
  private ContainerSummaryInnerNetworkSettings networkSettings = null;

  @ApiModelProperty(value = "")
  private List<Mount> mounts = null;
 /**
   * The ID of this container
   * @return id
  **/
  @JsonProperty("Id")
  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public ContainerSummaryInner id(String id) {
    this.id = id;
    return this;
  }

 /**
   * The names that this container has been given
   * @return names
  **/
  @JsonProperty("Names")
  public List<String> getNames() {
    return names;
  }

  public void setNames(List<String> names) {
    this.names = names;
  }

  public ContainerSummaryInner names(List<String> names) {
    this.names = names;
    return this;
  }

  public ContainerSummaryInner addNamesItem(String namesItem) {
    this.names.add(namesItem);
    return this;
  }

 /**
   * The name of the image used when creating this container
   * @return image
  **/
  @JsonProperty("Image")
  public String getImage() {
    return image;
  }

  public void setImage(String image) {
    this.image = image;
  }

  public ContainerSummaryInner image(String image) {
    this.image = image;
    return this;
  }

 /**
   * The ID of the image that this container was created from
   * @return imageID
  **/
  @JsonProperty("ImageID")
  public String getImageID() {
    return imageID;
  }

  public void setImageID(String imageID) {
    this.imageID = imageID;
  }

  public ContainerSummaryInner imageID(String imageID) {
    this.imageID = imageID;
    return this;
  }

 /**
   * Command to run when starting the container
   * @return command
  **/
  @JsonProperty("Command")
  public String getCommand() {
    return command;
  }

  public void setCommand(String command) {
    this.command = command;
  }

  public ContainerSummaryInner command(String command) {
    this.command = command;
    return this;
  }

 /**
   * When the container was created
   * @return created
  **/
  @JsonProperty("Created")
  public Long getCreated() {
    return created;
  }

  public void setCreated(Long created) {
    this.created = created;
  }

  public ContainerSummaryInner created(Long created) {
    this.created = created;
    return this;
  }

 /**
   * The ports exposed by this container
   * @return ports
  **/
  @JsonProperty("Ports")
  public List<Port> getPorts() {
    return ports;
  }

  public void setPorts(List<Port> ports) {
    this.ports = ports;
  }

  public ContainerSummaryInner ports(List<Port> ports) {
    this.ports = ports;
    return this;
  }

  public ContainerSummaryInner addPortsItem(Port portsItem) {
    this.ports.add(portsItem);
    return this;
  }

 /**
   * The size of files that have been created or changed by this container
   * @return sizeRw
  **/
  @JsonProperty("SizeRw")
  public Long getSizeRw() {
    return sizeRw;
  }

  public void setSizeRw(Long sizeRw) {
    this.sizeRw = sizeRw;
  }

  public ContainerSummaryInner sizeRw(Long sizeRw) {
    this.sizeRw = sizeRw;
    return this;
  }

 /**
   * The total size of all the files in this container
   * @return sizeRootFs
  **/
  @JsonProperty("SizeRootFs")
  public Long getSizeRootFs() {
    return sizeRootFs;
  }

  public void setSizeRootFs(Long sizeRootFs) {
    this.sizeRootFs = sizeRootFs;
  }

  public ContainerSummaryInner sizeRootFs(Long sizeRootFs) {
    this.sizeRootFs = sizeRootFs;
    return this;
  }

 /**
   * User-defined key/value metadata.
   * @return labels
  **/
  @JsonProperty("Labels")
  public Map<String, String> getLabels() {
    return labels;
  }

  public void setLabels(Map<String, String> labels) {
    this.labels = labels;
  }

  public ContainerSummaryInner labels(Map<String, String> labels) {
    this.labels = labels;
    return this;
  }

  public ContainerSummaryInner putLabelsItem(String key, String labelsItem) {
    this.labels.put(key, labelsItem);
    return this;
  }

 /**
   * The state of this container (e.g. &#x60;Exited&#x60;)
   * @return state
  **/
  @JsonProperty("State")
  public String getState() {
    return state;
  }

  public void setState(String state) {
    this.state = state;
  }

  public ContainerSummaryInner state(String state) {
    this.state = state;
    return this;
  }

 /**
   * Additional human-readable status of this container (e.g. &#x60;Exit 0&#x60;)
   * @return status
  **/
  @JsonProperty("Status")
  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public ContainerSummaryInner status(String status) {
    this.status = status;
    return this;
  }

 /**
   * Get hostConfig
   * @return hostConfig
  **/
  @JsonProperty("HostConfig")
  public ContainerSummaryInnerHostConfig getHostConfig() {
    return hostConfig;
  }

  public void setHostConfig(ContainerSummaryInnerHostConfig hostConfig) {
    this.hostConfig = hostConfig;
  }

  public ContainerSummaryInner hostConfig(ContainerSummaryInnerHostConfig hostConfig) {
    this.hostConfig = hostConfig;
    return this;
  }

 /**
   * Get networkSettings
   * @return networkSettings
  **/
  @JsonProperty("NetworkSettings")
  public ContainerSummaryInnerNetworkSettings getNetworkSettings() {
    return networkSettings;
  }

  public void setNetworkSettings(ContainerSummaryInnerNetworkSettings networkSettings) {
    this.networkSettings = networkSettings;
  }

  public ContainerSummaryInner networkSettings(ContainerSummaryInnerNetworkSettings networkSettings) {
    this.networkSettings = networkSettings;
    return this;
  }

 /**
   * Get mounts
   * @return mounts
  **/
  @JsonProperty("Mounts")
  public List<Mount> getMounts() {
    return mounts;
  }

  public void setMounts(List<Mount> mounts) {
    this.mounts = mounts;
  }

  public ContainerSummaryInner mounts(List<Mount> mounts) {
    this.mounts = mounts;
    return this;
  }

  public ContainerSummaryInner addMountsItem(Mount mountsItem) {
    this.mounts.add(mountsItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ContainerSummaryInner {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    names: ").append(toIndentedString(names)).append("\n");
    sb.append("    image: ").append(toIndentedString(image)).append("\n");
    sb.append("    imageID: ").append(toIndentedString(imageID)).append("\n");
    sb.append("    command: ").append(toIndentedString(command)).append("\n");
    sb.append("    created: ").append(toIndentedString(created)).append("\n");
    sb.append("    ports: ").append(toIndentedString(ports)).append("\n");
    sb.append("    sizeRw: ").append(toIndentedString(sizeRw)).append("\n");
    sb.append("    sizeRootFs: ").append(toIndentedString(sizeRootFs)).append("\n");
    sb.append("    labels: ").append(toIndentedString(labels)).append("\n");
    sb.append("    state: ").append(toIndentedString(state)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    hostConfig: ").append(toIndentedString(hostConfig)).append("\n");
    sb.append("    networkSettings: ").append(toIndentedString(networkSettings)).append("\n");
    sb.append("    mounts: ").append(toIndentedString(mounts)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

