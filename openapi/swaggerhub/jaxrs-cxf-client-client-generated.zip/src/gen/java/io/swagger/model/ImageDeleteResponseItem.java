package io.swagger.model;


import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ImageDeleteResponseItem  {
  
  @ApiModelProperty(value = "The image ID of an image that was untagged")
 /**
   * The image ID of an image that was untagged  
  **/
  private String untagged = null;

  @ApiModelProperty(value = "The image ID of an image that was deleted")
 /**
   * The image ID of an image that was deleted  
  **/
  private String deleted = null;
 /**
   * The image ID of an image that was untagged
   * @return untagged
  **/
  @JsonProperty("Untagged")
  public String getUntagged() {
    return untagged;
  }

  public void setUntagged(String untagged) {
    this.untagged = untagged;
  }

  public ImageDeleteResponseItem untagged(String untagged) {
    this.untagged = untagged;
    return this;
  }

 /**
   * The image ID of an image that was deleted
   * @return deleted
  **/
  @JsonProperty("Deleted")
  public String getDeleted() {
    return deleted;
  }

  public void setDeleted(String deleted) {
    this.deleted = deleted;
  }

  public ImageDeleteResponseItem deleted(String deleted) {
    this.deleted = deleted;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ImageDeleteResponseItem {\n");
    
    sb.append("    untagged: ").append(toIndentedString(untagged)).append("\n");
    sb.append("    deleted: ").append(toIndentedString(deleted)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

