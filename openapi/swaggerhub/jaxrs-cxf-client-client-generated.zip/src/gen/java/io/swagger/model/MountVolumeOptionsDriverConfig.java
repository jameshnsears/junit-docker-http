package io.swagger.model;

import io.swagger.annotations.ApiModel;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * Map of driver specific options
 **/
@ApiModel(description="Map of driver specific options")
public class MountVolumeOptionsDriverConfig  {
  
  @ApiModelProperty(value = "Name of the driver to use to create the volume.")
 /**
   * Name of the driver to use to create the volume.  
  **/
  private String name = null;

  @ApiModelProperty(value = "key/value map of driver specific options.")
 /**
   * key/value map of driver specific options.  
  **/
  private Map<String, String> options = null;
 /**
   * Name of the driver to use to create the volume.
   * @return name
  **/
  @JsonProperty("Name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public MountVolumeOptionsDriverConfig name(String name) {
    this.name = name;
    return this;
  }

 /**
   * key/value map of driver specific options.
   * @return options
  **/
  @JsonProperty("Options")
  public Map<String, String> getOptions() {
    return options;
  }

  public void setOptions(Map<String, String> options) {
    this.options = options;
  }

  public MountVolumeOptionsDriverConfig options(Map<String, String> options) {
    this.options = options;
    return this;
  }

  public MountVolumeOptionsDriverConfig putOptionsItem(String key, String optionsItem) {
    this.options.put(key, optionsItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class MountVolumeOptionsDriverConfig {\n");
    
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    options: ").append(toIndentedString(options)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

