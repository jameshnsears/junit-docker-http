package io.swagger.model;

import io.swagger.annotations.ApiModel;
import io.swagger.model.PluginDevice;
import io.swagger.model.PluginMount;
import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * Settings that can be modified by users.
 **/
@ApiModel(description="Settings that can be modified by users.")
public class PluginSettings  {
  
  @ApiModelProperty(required = true, value = "")
  private List<PluginMount> mounts = new ArrayList<PluginMount>();

  @ApiModelProperty(example = "[\"DEBUG=0\"]", required = true, value = "")
  private List<String> env = new ArrayList<String>();

  @ApiModelProperty(required = true, value = "")
  private List<String> args = new ArrayList<String>();

  @ApiModelProperty(required = true, value = "")
  private List<PluginDevice> devices = new ArrayList<PluginDevice>();
 /**
   * Get mounts
   * @return mounts
  **/
  @JsonProperty("Mounts")
  public List<PluginMount> getMounts() {
    return mounts;
  }

  public void setMounts(List<PluginMount> mounts) {
    this.mounts = mounts;
  }

  public PluginSettings mounts(List<PluginMount> mounts) {
    this.mounts = mounts;
    return this;
  }

  public PluginSettings addMountsItem(PluginMount mountsItem) {
    this.mounts.add(mountsItem);
    return this;
  }

 /**
   * Get env
   * @return env
  **/
  @JsonProperty("Env")
  public List<String> getEnv() {
    return env;
  }

  public void setEnv(List<String> env) {
    this.env = env;
  }

  public PluginSettings env(List<String> env) {
    this.env = env;
    return this;
  }

  public PluginSettings addEnvItem(String envItem) {
    this.env.add(envItem);
    return this;
  }

 /**
   * Get args
   * @return args
  **/
  @JsonProperty("Args")
  public List<String> getArgs() {
    return args;
  }

  public void setArgs(List<String> args) {
    this.args = args;
  }

  public PluginSettings args(List<String> args) {
    this.args = args;
    return this;
  }

  public PluginSettings addArgsItem(String argsItem) {
    this.args.add(argsItem);
    return this;
  }

 /**
   * Get devices
   * @return devices
  **/
  @JsonProperty("Devices")
  public List<PluginDevice> getDevices() {
    return devices;
  }

  public void setDevices(List<PluginDevice> devices) {
    this.devices = devices;
  }

  public PluginSettings devices(List<PluginDevice> devices) {
    this.devices = devices;
    return this;
  }

  public PluginSettings addDevicesItem(PluginDevice devicesItem) {
    this.devices.add(devicesItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PluginSettings {\n");
    
    sb.append("    mounts: ").append(toIndentedString(mounts)).append("\n");
    sb.append("    env: ").append(toIndentedString(env)).append("\n");
    sb.append("    args: ").append(toIndentedString(args)).append("\n");
    sb.append("    devices: ").append(toIndentedString(devices)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

