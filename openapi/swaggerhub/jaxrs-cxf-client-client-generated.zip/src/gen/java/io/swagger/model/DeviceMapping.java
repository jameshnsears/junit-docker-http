package io.swagger.model;

import io.swagger.annotations.ApiModel;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * A device mapping between the host and container
 **/
@ApiModel(description="A device mapping between the host and container")
public class DeviceMapping  {
  
  @ApiModelProperty(value = "")
  private String pathOnHost = null;

  @ApiModelProperty(value = "")
  private String pathInContainer = null;

  @ApiModelProperty(value = "")
  private String cgroupPermissions = null;
 /**
   * Get pathOnHost
   * @return pathOnHost
  **/
  @JsonProperty("PathOnHost")
  public String getPathOnHost() {
    return pathOnHost;
  }

  public void setPathOnHost(String pathOnHost) {
    this.pathOnHost = pathOnHost;
  }

  public DeviceMapping pathOnHost(String pathOnHost) {
    this.pathOnHost = pathOnHost;
    return this;
  }

 /**
   * Get pathInContainer
   * @return pathInContainer
  **/
  @JsonProperty("PathInContainer")
  public String getPathInContainer() {
    return pathInContainer;
  }

  public void setPathInContainer(String pathInContainer) {
    this.pathInContainer = pathInContainer;
  }

  public DeviceMapping pathInContainer(String pathInContainer) {
    this.pathInContainer = pathInContainer;
    return this;
  }

 /**
   * Get cgroupPermissions
   * @return cgroupPermissions
  **/
  @JsonProperty("CgroupPermissions")
  public String getCgroupPermissions() {
    return cgroupPermissions;
  }

  public void setCgroupPermissions(String cgroupPermissions) {
    this.cgroupPermissions = cgroupPermissions;
  }

  public DeviceMapping cgroupPermissions(String cgroupPermissions) {
    this.cgroupPermissions = cgroupPermissions;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class DeviceMapping {\n");
    
    sb.append("    pathOnHost: ").append(toIndentedString(pathOnHost)).append("\n");
    sb.append("    pathInContainer: ").append(toIndentedString(pathInContainer)).append("\n");
    sb.append("    cgroupPermissions: ").append(toIndentedString(cgroupPermissions)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

