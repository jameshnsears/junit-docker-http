package io.swagger.model;

import io.swagger.annotations.ApiModel;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * Usage details about the volume. This information is used by the `GET /system/df` endpoint, and omitted in other endpoints. 
 **/
@ApiModel(description="Usage details about the volume. This information is used by the `GET /system/df` endpoint, and omitted in other endpoints. ")
public class VolumeUsageData  {
  
  @ApiModelProperty(required = true, value = "Amount of disk space used by the volume (in bytes). This information is only available for volumes created with the `\"local\"` volume driver. For volumes created with other volume drivers, this field is set to `-1` (\"not available\") ")
 /**
   * Amount of disk space used by the volume (in bytes). This information is only available for volumes created with the `\"local\"` volume driver. For volumes created with other volume drivers, this field is set to `-1` (\"not available\")   
  **/
  private Integer size = null;

  @ApiModelProperty(required = true, value = "The number of containers referencing this volume. This field is set to `-1` if the reference-count is not available. ")
 /**
   * The number of containers referencing this volume. This field is set to `-1` if the reference-count is not available.   
  **/
  private Integer refCount = null;
 /**
   * Amount of disk space used by the volume (in bytes). This information is only available for volumes created with the &#x60;\&quot;local\&quot;&#x60; volume driver. For volumes created with other volume drivers, this field is set to &#x60;-1&#x60; (\&quot;not available\&quot;) 
   * @return size
  **/
  @JsonProperty("Size")
  public Integer getSize() {
    return size;
  }

  public void setSize(Integer size) {
    this.size = size;
  }

  public VolumeUsageData size(Integer size) {
    this.size = size;
    return this;
  }

 /**
   * The number of containers referencing this volume. This field is set to &#x60;-1&#x60; if the reference-count is not available. 
   * @return refCount
  **/
  @JsonProperty("RefCount")
  public Integer getRefCount() {
    return refCount;
  }

  public void setRefCount(Integer refCount) {
    this.refCount = refCount;
  }

  public VolumeUsageData refCount(Integer refCount) {
    this.refCount = refCount;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class VolumeUsageData {\n");
    
    sb.append("    size: ").append(toIndentedString(size)).append("\n");
    sb.append("    refCount: ").append(toIndentedString(refCount)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

