package io.swagger.model;

import io.swagger.annotations.ApiModel;


/**
 * NodeState represents the state of a node.
 */
public enum NodeState {
  
  UNKNOWN("unknown"),
  
  DOWN("down"),
  
  READY("ready"),
  
  DISCONNECTED("disconnected");

  private String value;

  NodeState(String value) {
    this.value = value;
  }

  @Override
  public String toString() {
    return String.valueOf(value);
  }

  public static NodeState fromValue(String text) {
    for (NodeState b : NodeState.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
  
}

