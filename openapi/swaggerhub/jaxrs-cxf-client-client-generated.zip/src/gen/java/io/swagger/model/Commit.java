package io.swagger.model;

import io.swagger.annotations.ApiModel;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * Commit holds the Git-commit (SHA1) that a binary was built from, as reported in the version-string of external tools, such as `containerd`, or `runC`. 
 **/
@ApiModel(description="Commit holds the Git-commit (SHA1) that a binary was built from, as reported in the version-string of external tools, such as `containerd`, or `runC`. ")
public class Commit  {
  
  @ApiModelProperty(example = "cfb82a876ecc11b5ca0977d1733adbe58599088a", value = "Actual commit ID of external tool.")
 /**
   * Actual commit ID of external tool.  
  **/
  private String ID = null;

  @ApiModelProperty(example = "2d41c047c83e09a6d61d464906feb2a2f3c52aa4", value = "Commit ID of external tool expected by dockerd as set at build time. ")
 /**
   * Commit ID of external tool expected by dockerd as set at build time.   
  **/
  private String expected = null;
 /**
   * Actual commit ID of external tool.
   * @return ID
  **/
  @JsonProperty("ID")
  public String getID() {
    return ID;
  }

  public void setID(String ID) {
    this.ID = ID;
  }

  public Commit ID(String ID) {
    this.ID = ID;
    return this;
  }

 /**
   * Commit ID of external tool expected by dockerd as set at build time. 
   * @return expected
  **/
  @JsonProperty("Expected")
  public String getExpected() {
    return expected;
  }

  public void setExpected(String expected) {
    this.expected = expected;
  }

  public Commit expected(String expected) {
    this.expected = expected;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Commit {\n");
    
    sb.append("    ID: ").append(toIndentedString(ID)).append("\n");
    sb.append("    expected: ").append(toIndentedString(expected)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

