package io.swagger.model;

import io.swagger.model.VolumeUsageData;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Volume  {
  
  @ApiModelProperty(required = true, value = "Name of the volume.")
 /**
   * Name of the volume.  
  **/
  private String name = null;

  @ApiModelProperty(required = true, value = "Name of the volume driver used by the volume.")
 /**
   * Name of the volume driver used by the volume.  
  **/
  private String driver = null;

  @ApiModelProperty(required = true, value = "Mount path of the volume on the host.")
 /**
   * Mount path of the volume on the host.  
  **/
  private String mountpoint = null;

  @ApiModelProperty(value = "Date/Time the volume was created.")
 /**
   * Date/Time the volume was created.  
  **/
  private String createdAt = null;

  @ApiModelProperty(value = "Low-level details about the volume, provided by the volume driver. Details are returned as a map with key/value pairs: `{\"key\":\"value\",\"key2\":\"value2\"}`.  The `Status` field is optional, and is omitted if the volume driver does not support this feature. ")
 /**
   * Low-level details about the volume, provided by the volume driver. Details are returned as a map with key/value pairs: `{\"key\":\"value\",\"key2\":\"value2\"}`.  The `Status` field is optional, and is omitted if the volume driver does not support this feature.   
  **/
  private Map<String, Object> status = null;

  @ApiModelProperty(required = true, value = "User-defined key/value metadata.")
 /**
   * User-defined key/value metadata.  
  **/
  private Map<String, String> labels = new HashMap<String, String>();


@XmlType(name="ScopeEnum")
@XmlEnum(String.class)
public enum ScopeEnum {

@XmlEnumValue("local") LOCAL(String.valueOf("local")), @XmlEnumValue("global") GLOBAL(String.valueOf("global"));


    private String value;

    ScopeEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static ScopeEnum fromValue(String v) {
        for (ScopeEnum b : ScopeEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(required = true, value = "The level at which the volume exists. Either `global` for cluster-wide, or `local` for machine level.")
 /**
   * The level at which the volume exists. Either `global` for cluster-wide, or `local` for machine level.  
  **/
  private ScopeEnum scope = ScopeEnum.LOCAL;

  @ApiModelProperty(required = true, value = "The driver specific options used when creating the volume.")
 /**
   * The driver specific options used when creating the volume.  
  **/
  private Map<String, String> options = new HashMap<String, String>();

  @ApiModelProperty(value = "")
  private VolumeUsageData usageData = null;
 /**
   * Name of the volume.
   * @return name
  **/
  @JsonProperty("Name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Volume name(String name) {
    this.name = name;
    return this;
  }

 /**
   * Name of the volume driver used by the volume.
   * @return driver
  **/
  @JsonProperty("Driver")
  public String getDriver() {
    return driver;
  }

  public void setDriver(String driver) {
    this.driver = driver;
  }

  public Volume driver(String driver) {
    this.driver = driver;
    return this;
  }

 /**
   * Mount path of the volume on the host.
   * @return mountpoint
  **/
  @JsonProperty("Mountpoint")
  public String getMountpoint() {
    return mountpoint;
  }

  public void setMountpoint(String mountpoint) {
    this.mountpoint = mountpoint;
  }

  public Volume mountpoint(String mountpoint) {
    this.mountpoint = mountpoint;
    return this;
  }

 /**
   * Date/Time the volume was created.
   * @return createdAt
  **/
  @JsonProperty("CreatedAt")
  public String getCreatedAt() {
    return createdAt;
  }

  public void setCreatedAt(String createdAt) {
    this.createdAt = createdAt;
  }

  public Volume createdAt(String createdAt) {
    this.createdAt = createdAt;
    return this;
  }

 /**
   * Low-level details about the volume, provided by the volume driver. Details are returned as a map with key/value pairs: &#x60;{\&quot;key\&quot;:\&quot;value\&quot;,\&quot;key2\&quot;:\&quot;value2\&quot;}&#x60;.  The &#x60;Status&#x60; field is optional, and is omitted if the volume driver does not support this feature. 
   * @return status
  **/
  @JsonProperty("Status")
  public Map<String, Object> getStatus() {
    return status;
  }

  public void setStatus(Map<String, Object> status) {
    this.status = status;
  }

  public Volume status(Map<String, Object> status) {
    this.status = status;
    return this;
  }

  public Volume putStatusItem(String key, Object statusItem) {
    this.status.put(key, statusItem);
    return this;
  }

 /**
   * User-defined key/value metadata.
   * @return labels
  **/
  @JsonProperty("Labels")
  public Map<String, String> getLabels() {
    return labels;
  }

  public void setLabels(Map<String, String> labels) {
    this.labels = labels;
  }

  public Volume labels(Map<String, String> labels) {
    this.labels = labels;
    return this;
  }

  public Volume putLabelsItem(String key, String labelsItem) {
    this.labels.put(key, labelsItem);
    return this;
  }

 /**
   * The level at which the volume exists. Either &#x60;global&#x60; for cluster-wide, or &#x60;local&#x60; for machine level.
   * @return scope
  **/
  @JsonProperty("Scope")
  public String getScope() {
    if (scope == null) {
      return null;
    }
    return scope.value();
  }

  public void setScope(ScopeEnum scope) {
    this.scope = scope;
  }

  public Volume scope(ScopeEnum scope) {
    this.scope = scope;
    return this;
  }

 /**
   * The driver specific options used when creating the volume.
   * @return options
  **/
  @JsonProperty("Options")
  public Map<String, String> getOptions() {
    return options;
  }

  public void setOptions(Map<String, String> options) {
    this.options = options;
  }

  public Volume options(Map<String, String> options) {
    this.options = options;
    return this;
  }

  public Volume putOptionsItem(String key, String optionsItem) {
    this.options.put(key, optionsItem);
    return this;
  }

 /**
   * Get usageData
   * @return usageData
  **/
  @JsonProperty("UsageData")
  public VolumeUsageData getUsageData() {
    return usageData;
  }

  public void setUsageData(VolumeUsageData usageData) {
    this.usageData = usageData;
  }

  public Volume usageData(VolumeUsageData usageData) {
    this.usageData = usageData;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Volume {\n");
    
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    driver: ").append(toIndentedString(driver)).append("\n");
    sb.append("    mountpoint: ").append(toIndentedString(mountpoint)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    labels: ").append(toIndentedString(labels)).append("\n");
    sb.append("    scope: ").append(toIndentedString(scope)).append("\n");
    sb.append("    options: ").append(toIndentedString(options)).append("\n");
    sb.append("    usageData: ").append(toIndentedString(usageData)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

