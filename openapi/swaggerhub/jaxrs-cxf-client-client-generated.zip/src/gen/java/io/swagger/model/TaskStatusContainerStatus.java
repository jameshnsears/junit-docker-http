package io.swagger.model;


import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class TaskStatusContainerStatus  {
  
  @ApiModelProperty(value = "")
  private String containerID = null;

  @ApiModelProperty(value = "")
  private Integer PID = null;

  @ApiModelProperty(value = "")
  private Integer exitCode = null;
 /**
   * Get containerID
   * @return containerID
  **/
  @JsonProperty("ContainerID")
  public String getContainerID() {
    return containerID;
  }

  public void setContainerID(String containerID) {
    this.containerID = containerID;
  }

  public TaskStatusContainerStatus containerID(String containerID) {
    this.containerID = containerID;
    return this;
  }

 /**
   * Get PID
   * @return PID
  **/
  @JsonProperty("PID")
  public Integer getPID() {
    return PID;
  }

  public void setPID(Integer PID) {
    this.PID = PID;
  }

  public TaskStatusContainerStatus PID(Integer PID) {
    this.PID = PID;
    return this;
  }

 /**
   * Get exitCode
   * @return exitCode
  **/
  @JsonProperty("ExitCode")
  public Integer getExitCode() {
    return exitCode;
  }

  public void setExitCode(Integer exitCode) {
    this.exitCode = exitCode;
  }

  public TaskStatusContainerStatus exitCode(Integer exitCode) {
    this.exitCode = exitCode;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TaskStatusContainerStatus {\n");
    
    sb.append("    containerID: ").append(toIndentedString(containerID)).append("\n");
    sb.append("    PID: ").append(toIndentedString(PID)).append("\n");
    sb.append("    exitCode: ").append(toIndentedString(exitCode)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

