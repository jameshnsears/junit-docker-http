package io.swagger.model;

import io.swagger.annotations.ApiModel;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * The behavior to apply when the container exits. The default is not to restart.  An ever increasing delay (double the previous delay, starting at 100ms) is added before each restart to prevent flooding the server. 
 **/
@ApiModel(description="The behavior to apply when the container exits. The default is not to restart.  An ever increasing delay (double the previous delay, starting at 100ms) is added before each restart to prevent flooding the server. ")
public class RestartPolicy  {
  

@XmlType(name="NameEnum")
@XmlEnum(String.class)
public enum NameEnum {

@XmlEnumValue("") EMPTY(String.valueOf("")), @XmlEnumValue("always") ALWAYS(String.valueOf("always")), @XmlEnumValue("unless-stopped") UNLESS_STOPPED(String.valueOf("unless-stopped")), @XmlEnumValue("on-failure") ON_FAILURE(String.valueOf("on-failure"));


    private String value;

    NameEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static NameEnum fromValue(String v) {
        for (NameEnum b : NameEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(value = "- Empty string means not to restart - `always` Always restart - `unless-stopped` Restart always except when the user has manually stopped the container - `on-failure` Restart only when the container exit code is non-zero ")
 /**
   * - Empty string means not to restart - `always` Always restart - `unless-stopped` Restart always except when the user has manually stopped the container - `on-failure` Restart only when the container exit code is non-zero   
  **/
  private NameEnum name = null;

  @ApiModelProperty(value = "If `on-failure` is used, the number of times to retry before giving up")
 /**
   * If `on-failure` is used, the number of times to retry before giving up  
  **/
  private Integer maximumRetryCount = null;
 /**
   * - Empty string means not to restart - &#x60;always&#x60; Always restart - &#x60;unless-stopped&#x60; Restart always except when the user has manually stopped the container - &#x60;on-failure&#x60; Restart only when the container exit code is non-zero 
   * @return name
  **/
  @JsonProperty("Name")
  public String getName() {
    if (name == null) {
      return null;
    }
    return name.value();
  }

  public void setName(NameEnum name) {
    this.name = name;
  }

  public RestartPolicy name(NameEnum name) {
    this.name = name;
    return this;
  }

 /**
   * If &#x60;on-failure&#x60; is used, the number of times to retry before giving up
   * @return maximumRetryCount
  **/
  @JsonProperty("MaximumRetryCount")
  public Integer getMaximumRetryCount() {
    return maximumRetryCount;
  }

  public void setMaximumRetryCount(Integer maximumRetryCount) {
    this.maximumRetryCount = maximumRetryCount;
  }

  public RestartPolicy maximumRetryCount(Integer maximumRetryCount) {
    this.maximumRetryCount = maximumRetryCount;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RestartPolicy {\n");
    
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    maximumRetryCount: ").append(toIndentedString(maximumRetryCount)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

