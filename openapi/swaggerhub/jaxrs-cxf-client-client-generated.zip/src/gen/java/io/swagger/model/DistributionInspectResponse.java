package io.swagger.model;

import io.swagger.model.DistributionInspectResponseDescriptor;
import io.swagger.model.DistributionInspectResponsePlatforms;
import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class DistributionInspectResponse  {
  
  @ApiModelProperty(required = true, value = "")
  private DistributionInspectResponseDescriptor descriptor = null;

  @ApiModelProperty(required = true, value = "An array containing all platforms supported by the image")
 /**
   * An array containing all platforms supported by the image  
  **/
  private List<DistributionInspectResponsePlatforms> platforms = new ArrayList<DistributionInspectResponsePlatforms>();
 /**
   * Get descriptor
   * @return descriptor
  **/
  @JsonProperty("Descriptor")
  public DistributionInspectResponseDescriptor getDescriptor() {
    return descriptor;
  }

  public void setDescriptor(DistributionInspectResponseDescriptor descriptor) {
    this.descriptor = descriptor;
  }

  public DistributionInspectResponse descriptor(DistributionInspectResponseDescriptor descriptor) {
    this.descriptor = descriptor;
    return this;
  }

 /**
   * An array containing all platforms supported by the image
   * @return platforms
  **/
  @JsonProperty("Platforms")
  public List<DistributionInspectResponsePlatforms> getPlatforms() {
    return platforms;
  }

  public void setPlatforms(List<DistributionInspectResponsePlatforms> platforms) {
    this.platforms = platforms;
  }

  public DistributionInspectResponse platforms(List<DistributionInspectResponsePlatforms> platforms) {
    this.platforms = platforms;
    return this;
  }

  public DistributionInspectResponse addPlatformsItem(DistributionInspectResponsePlatforms platformsItem) {
    this.platforms.add(platformsItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class DistributionInspectResponse {\n");
    
    sb.append("    descriptor: ").append(toIndentedString(descriptor)).append("\n");
    sb.append("    platforms: ").append(toIndentedString(platforms)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

