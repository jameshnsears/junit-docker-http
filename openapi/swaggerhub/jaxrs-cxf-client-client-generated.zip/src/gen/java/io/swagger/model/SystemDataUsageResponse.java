package io.swagger.model;

import io.swagger.model.BuildCache;
import io.swagger.model.ContainerSummary;
import io.swagger.model.ImageSummary;
import io.swagger.model.Volume;
import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class SystemDataUsageResponse  {
  
  @ApiModelProperty(value = "")
  private Long layersSize = null;

  @ApiModelProperty(value = "")
  private List<ImageSummary> images = null;

  @ApiModelProperty(value = "")
  private List<ContainerSummary> containers = null;

  @ApiModelProperty(value = "")
  private List<Volume> volumes = null;

  @ApiModelProperty(value = "")
  private List<BuildCache> buildCache = null;
 /**
   * Get layersSize
   * @return layersSize
  **/
  @JsonProperty("LayersSize")
  public Long getLayersSize() {
    return layersSize;
  }

  public void setLayersSize(Long layersSize) {
    this.layersSize = layersSize;
  }

  public SystemDataUsageResponse layersSize(Long layersSize) {
    this.layersSize = layersSize;
    return this;
  }

 /**
   * Get images
   * @return images
  **/
  @JsonProperty("Images")
  public List<ImageSummary> getImages() {
    return images;
  }

  public void setImages(List<ImageSummary> images) {
    this.images = images;
  }

  public SystemDataUsageResponse images(List<ImageSummary> images) {
    this.images = images;
    return this;
  }

  public SystemDataUsageResponse addImagesItem(ImageSummary imagesItem) {
    this.images.add(imagesItem);
    return this;
  }

 /**
   * Get containers
   * @return containers
  **/
  @JsonProperty("Containers")
  public List<ContainerSummary> getContainers() {
    return containers;
  }

  public void setContainers(List<ContainerSummary> containers) {
    this.containers = containers;
  }

  public SystemDataUsageResponse containers(List<ContainerSummary> containers) {
    this.containers = containers;
    return this;
  }

  public SystemDataUsageResponse addContainersItem(ContainerSummary containersItem) {
    this.containers.add(containersItem);
    return this;
  }

 /**
   * Get volumes
   * @return volumes
  **/
  @JsonProperty("Volumes")
  public List<Volume> getVolumes() {
    return volumes;
  }

  public void setVolumes(List<Volume> volumes) {
    this.volumes = volumes;
  }

  public SystemDataUsageResponse volumes(List<Volume> volumes) {
    this.volumes = volumes;
    return this;
  }

  public SystemDataUsageResponse addVolumesItem(Volume volumesItem) {
    this.volumes.add(volumesItem);
    return this;
  }

 /**
   * Get buildCache
   * @return buildCache
  **/
  @JsonProperty("BuildCache")
  public List<BuildCache> getBuildCache() {
    return buildCache;
  }

  public void setBuildCache(List<BuildCache> buildCache) {
    this.buildCache = buildCache;
  }

  public SystemDataUsageResponse buildCache(List<BuildCache> buildCache) {
    this.buildCache = buildCache;
    return this;
  }

  public SystemDataUsageResponse addBuildCacheItem(BuildCache buildCacheItem) {
    this.buildCache.add(buildCacheItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SystemDataUsageResponse {\n");
    
    sb.append("    layersSize: ").append(toIndentedString(layersSize)).append("\n");
    sb.append("    images: ").append(toIndentedString(images)).append("\n");
    sb.append("    containers: ").append(toIndentedString(containers)).append("\n");
    sb.append("    volumes: ").append(toIndentedString(volumes)).append("\n");
    sb.append("    buildCache: ").append(toIndentedString(buildCache)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

