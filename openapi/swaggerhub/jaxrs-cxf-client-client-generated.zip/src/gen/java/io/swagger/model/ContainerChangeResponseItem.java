package io.swagger.model;

import io.swagger.annotations.ApiModel;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * change item in response to ContainerChanges operation
 **/
@ApiModel(description="change item in response to ContainerChanges operation")
public class ContainerChangeResponseItem  {
  
  @ApiModelProperty(required = true, value = "Path to file that has changed")
 /**
   * Path to file that has changed  
  **/
  private String path = null;

  @ApiModelProperty(required = true, value = "Kind of change")
 /**
   * Kind of change  
  **/
  private Integer kind = null;
 /**
   * Path to file that has changed
   * @return path
  **/
  @JsonProperty("Path")
  public String getPath() {
    return path;
  }

  public void setPath(String path) {
    this.path = path;
  }

  public ContainerChangeResponseItem path(String path) {
    this.path = path;
    return this;
  }

 /**
   * Kind of change
   * @return kind
  **/
  @JsonProperty("Kind")
  public Integer getKind() {
    return kind;
  }

  public void setKind(Integer kind) {
    this.kind = kind;
  }

  public ContainerChangeResponseItem kind(Integer kind) {
    this.kind = kind;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ContainerChangeResponseItem {\n");
    
    sb.append("    path: ").append(toIndentedString(path)).append("\n");
    sb.append("    kind: ").append(toIndentedString(kind)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

