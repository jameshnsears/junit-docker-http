package io.swagger.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class SystemEventsResponseActor  {
  
  @ApiModelProperty(value = "The ID of the object emitting the event")
 /**
   * The ID of the object emitting the event  
  **/
  private String ID = null;

  @ApiModelProperty(value = "Various key/value attributes of the object, depending on its type")
 /**
   * Various key/value attributes of the object, depending on its type  
  **/
  private Map<String, String> attributes = null;
 /**
   * The ID of the object emitting the event
   * @return ID
  **/
  @JsonProperty("ID")
  public String getID() {
    return ID;
  }

  public void setID(String ID) {
    this.ID = ID;
  }

  public SystemEventsResponseActor ID(String ID) {
    this.ID = ID;
    return this;
  }

 /**
   * Various key/value attributes of the object, depending on its type
   * @return attributes
  **/
  @JsonProperty("Attributes")
  public Map<String, String> getAttributes() {
    return attributes;
  }

  public void setAttributes(Map<String, String> attributes) {
    this.attributes = attributes;
  }

  public SystemEventsResponseActor attributes(Map<String, String> attributes) {
    this.attributes = attributes;
    return this;
  }

  public SystemEventsResponseActor putAttributesItem(String key, String attributesItem) {
    this.attributes.put(key, attributesItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SystemEventsResponseActor {\n");
    
    sb.append("    ID: ").append(toIndentedString(ID)).append("\n");
    sb.append("    attributes: ").append(toIndentedString(attributes)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

