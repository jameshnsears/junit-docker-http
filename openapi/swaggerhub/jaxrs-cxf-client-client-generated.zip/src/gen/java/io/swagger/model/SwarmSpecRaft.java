package io.swagger.model;

import io.swagger.annotations.ApiModel;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * Raft configuration.
 **/
@ApiModel(description="Raft configuration.")
public class SwarmSpecRaft  {
  
  @ApiModelProperty(example = "10000", value = "The number of log entries between snapshots.")
 /**
   * The number of log entries between snapshots.  
  **/
  private Integer snapshotInterval = null;

  @ApiModelProperty(value = "The number of snapshots to keep beyond the current snapshot.")
 /**
   * The number of snapshots to keep beyond the current snapshot.  
  **/
  private Integer keepOldSnapshots = null;

  @ApiModelProperty(example = "500", value = "The number of log entries to keep around to sync up slow followers after a snapshot is created.")
 /**
   * The number of log entries to keep around to sync up slow followers after a snapshot is created.  
  **/
  private Integer logEntriesForSlowFollowers = null;

  @ApiModelProperty(example = "3", value = "The number of ticks that a follower will wait for a message from the leader before becoming a candidate and starting an election. `ElectionTick` must be greater than `HeartbeatTick`.  A tick currently defaults to one second, so these translate directly to seconds currently, but this is NOT guaranteed. ")
 /**
   * The number of ticks that a follower will wait for a message from the leader before becoming a candidate and starting an election. `ElectionTick` must be greater than `HeartbeatTick`.  A tick currently defaults to one second, so these translate directly to seconds currently, but this is NOT guaranteed.   
  **/
  private Integer electionTick = null;

  @ApiModelProperty(example = "1", value = "The number of ticks between heartbeats. Every HeartbeatTick ticks, the leader will send a heartbeat to the followers.  A tick currently defaults to one second, so these translate directly to seconds currently, but this is NOT guaranteed. ")
 /**
   * The number of ticks between heartbeats. Every HeartbeatTick ticks, the leader will send a heartbeat to the followers.  A tick currently defaults to one second, so these translate directly to seconds currently, but this is NOT guaranteed.   
  **/
  private Integer heartbeatTick = null;
 /**
   * The number of log entries between snapshots.
   * @return snapshotInterval
  **/
  @JsonProperty("SnapshotInterval")
  public Integer getSnapshotInterval() {
    return snapshotInterval;
  }

  public void setSnapshotInterval(Integer snapshotInterval) {
    this.snapshotInterval = snapshotInterval;
  }

  public SwarmSpecRaft snapshotInterval(Integer snapshotInterval) {
    this.snapshotInterval = snapshotInterval;
    return this;
  }

 /**
   * The number of snapshots to keep beyond the current snapshot.
   * @return keepOldSnapshots
  **/
  @JsonProperty("KeepOldSnapshots")
  public Integer getKeepOldSnapshots() {
    return keepOldSnapshots;
  }

  public void setKeepOldSnapshots(Integer keepOldSnapshots) {
    this.keepOldSnapshots = keepOldSnapshots;
  }

  public SwarmSpecRaft keepOldSnapshots(Integer keepOldSnapshots) {
    this.keepOldSnapshots = keepOldSnapshots;
    return this;
  }

 /**
   * The number of log entries to keep around to sync up slow followers after a snapshot is created.
   * @return logEntriesForSlowFollowers
  **/
  @JsonProperty("LogEntriesForSlowFollowers")
  public Integer getLogEntriesForSlowFollowers() {
    return logEntriesForSlowFollowers;
  }

  public void setLogEntriesForSlowFollowers(Integer logEntriesForSlowFollowers) {
    this.logEntriesForSlowFollowers = logEntriesForSlowFollowers;
  }

  public SwarmSpecRaft logEntriesForSlowFollowers(Integer logEntriesForSlowFollowers) {
    this.logEntriesForSlowFollowers = logEntriesForSlowFollowers;
    return this;
  }

 /**
   * The number of ticks that a follower will wait for a message from the leader before becoming a candidate and starting an election. &#x60;ElectionTick&#x60; must be greater than &#x60;HeartbeatTick&#x60;.  A tick currently defaults to one second, so these translate directly to seconds currently, but this is NOT guaranteed. 
   * @return electionTick
  **/
  @JsonProperty("ElectionTick")
  public Integer getElectionTick() {
    return electionTick;
  }

  public void setElectionTick(Integer electionTick) {
    this.electionTick = electionTick;
  }

  public SwarmSpecRaft electionTick(Integer electionTick) {
    this.electionTick = electionTick;
    return this;
  }

 /**
   * The number of ticks between heartbeats. Every HeartbeatTick ticks, the leader will send a heartbeat to the followers.  A tick currently defaults to one second, so these translate directly to seconds currently, but this is NOT guaranteed. 
   * @return heartbeatTick
  **/
  @JsonProperty("HeartbeatTick")
  public Integer getHeartbeatTick() {
    return heartbeatTick;
  }

  public void setHeartbeatTick(Integer heartbeatTick) {
    this.heartbeatTick = heartbeatTick;
  }

  public SwarmSpecRaft heartbeatTick(Integer heartbeatTick) {
    this.heartbeatTick = heartbeatTick;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SwarmSpecRaft {\n");
    
    sb.append("    snapshotInterval: ").append(toIndentedString(snapshotInterval)).append("\n");
    sb.append("    keepOldSnapshots: ").append(toIndentedString(keepOldSnapshots)).append("\n");
    sb.append("    logEntriesForSlowFollowers: ").append(toIndentedString(logEntriesForSlowFollowers)).append("\n");
    sb.append("    electionTick: ").append(toIndentedString(electionTick)).append("\n");
    sb.append("    heartbeatTick: ").append(toIndentedString(heartbeatTick)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

