package io.swagger.model;

import io.swagger.annotations.ApiModel;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * The logging configuration for this container
 **/
@ApiModel(description="The logging configuration for this container")
public class HostConfigLogConfig  {
  

@XmlType(name="TypeEnum")
@XmlEnum(String.class)
public enum TypeEnum {

@XmlEnumValue("json-file") JSON_FILE(String.valueOf("json-file")), @XmlEnumValue("syslog") SYSLOG(String.valueOf("syslog")), @XmlEnumValue("journald") JOURNALD(String.valueOf("journald")), @XmlEnumValue("gelf") GELF(String.valueOf("gelf")), @XmlEnumValue("fluentd") FLUENTD(String.valueOf("fluentd")), @XmlEnumValue("awslogs") AWSLOGS(String.valueOf("awslogs")), @XmlEnumValue("splunk") SPLUNK(String.valueOf("splunk")), @XmlEnumValue("etwlogs") ETWLOGS(String.valueOf("etwlogs")), @XmlEnumValue("none") NONE(String.valueOf("none"));


    private String value;

    TypeEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static TypeEnum fromValue(String v) {
        for (TypeEnum b : TypeEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(value = "")
  private TypeEnum type = null;

  @ApiModelProperty(value = "")
  private Map<String, String> config = null;
 /**
   * Get type
   * @return type
  **/
  @JsonProperty("Type")
  public String getType() {
    if (type == null) {
      return null;
    }
    return type.value();
  }

  public void setType(TypeEnum type) {
    this.type = type;
  }

  public HostConfigLogConfig type(TypeEnum type) {
    this.type = type;
    return this;
  }

 /**
   * Get config
   * @return config
  **/
  @JsonProperty("Config")
  public Map<String, String> getConfig() {
    return config;
  }

  public void setConfig(Map<String, String> config) {
    this.config = config;
  }

  public HostConfigLogConfig config(Map<String, String> config) {
    this.config = config;
    return this;
  }

  public HostConfigLogConfig putConfigItem(String key, String configItem) {
    this.config.put(key, configItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class HostConfigLogConfig {\n");
    
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    config: ").append(toIndentedString(config)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

