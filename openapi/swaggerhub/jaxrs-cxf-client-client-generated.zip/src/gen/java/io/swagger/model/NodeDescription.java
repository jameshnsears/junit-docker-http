package io.swagger.model;

import io.swagger.annotations.ApiModel;
import io.swagger.model.EngineDescription;
import io.swagger.model.Platform;
import io.swagger.model.ResourceObject;
import io.swagger.model.TLSInfo;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * NodeDescription encapsulates the properties of the Node as reported by the agent. 
 **/
@ApiModel(description="NodeDescription encapsulates the properties of the Node as reported by the agent. ")
public class NodeDescription  {
  
  @ApiModelProperty(example = "bf3067039e47", value = "")
  private String hostname = null;

  @ApiModelProperty(value = "")
  private Platform platform = null;

  @ApiModelProperty(value = "")
  private ResourceObject resources = null;

  @ApiModelProperty(value = "")
  private EngineDescription engine = null;

  @ApiModelProperty(value = "")
  private TLSInfo tlSInfo = null;
 /**
   * Get hostname
   * @return hostname
  **/
  @JsonProperty("Hostname")
  public String getHostname() {
    return hostname;
  }

  public void setHostname(String hostname) {
    this.hostname = hostname;
  }

  public NodeDescription hostname(String hostname) {
    this.hostname = hostname;
    return this;
  }

 /**
   * Get platform
   * @return platform
  **/
  @JsonProperty("Platform")
  public Platform getPlatform() {
    return platform;
  }

  public void setPlatform(Platform platform) {
    this.platform = platform;
  }

  public NodeDescription platform(Platform platform) {
    this.platform = platform;
    return this;
  }

 /**
   * Get resources
   * @return resources
  **/
  @JsonProperty("Resources")
  public ResourceObject getResources() {
    return resources;
  }

  public void setResources(ResourceObject resources) {
    this.resources = resources;
  }

  public NodeDescription resources(ResourceObject resources) {
    this.resources = resources;
    return this;
  }

 /**
   * Get engine
   * @return engine
  **/
  @JsonProperty("Engine")
  public EngineDescription getEngine() {
    return engine;
  }

  public void setEngine(EngineDescription engine) {
    this.engine = engine;
  }

  public NodeDescription engine(EngineDescription engine) {
    this.engine = engine;
    return this;
  }

 /**
   * Get tlSInfo
   * @return tlSInfo
  **/
  @JsonProperty("TLSInfo")
  public TLSInfo getTlSInfo() {
    return tlSInfo;
  }

  public void setTlSInfo(TLSInfo tlSInfo) {
    this.tlSInfo = tlSInfo;
  }

  public NodeDescription tlSInfo(TLSInfo tlSInfo) {
    this.tlSInfo = tlSInfo;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class NodeDescription {\n");
    
    sb.append("    hostname: ").append(toIndentedString(hostname)).append("\n");
    sb.append("    platform: ").append(toIndentedString(platform)).append("\n");
    sb.append("    resources: ").append(toIndentedString(resources)).append("\n");
    sb.append("    engine: ").append(toIndentedString(engine)).append("\n");
    sb.append("    tlSInfo: ").append(toIndentedString(tlSInfo)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

