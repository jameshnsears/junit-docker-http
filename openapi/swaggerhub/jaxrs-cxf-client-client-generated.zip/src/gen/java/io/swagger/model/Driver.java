package io.swagger.model;

import io.swagger.annotations.ApiModel;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * Driver represents a driver (network, logging, secrets).
 **/
@ApiModel(description="Driver represents a driver (network, logging, secrets).")
public class Driver  {
  
  @ApiModelProperty(example = "some-driver", required = true, value = "Name of the driver.")
 /**
   * Name of the driver.  
  **/
  private String name = null;

  @ApiModelProperty(example = "{\"OptionA\":\"value for driver-specific option A\",\"OptionB\":\"value for driver-specific option B\"}", value = "Key/value map of driver-specific options.")
 /**
   * Key/value map of driver-specific options.  
  **/
  private Map<String, String> options = null;
 /**
   * Name of the driver.
   * @return name
  **/
  @JsonProperty("Name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Driver name(String name) {
    this.name = name;
    return this;
  }

 /**
   * Key/value map of driver-specific options.
   * @return options
  **/
  @JsonProperty("Options")
  public Map<String, String> getOptions() {
    return options;
  }

  public void setOptions(Map<String, String> options) {
    this.options = options;
  }

  public Driver options(Map<String, String> options) {
    this.options = options;
    return this;
  }

  public Driver putOptionsItem(String key, String optionsItem) {
    this.options.put(key, optionsItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Driver {\n");
    
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    options: ").append(toIndentedString(options)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

