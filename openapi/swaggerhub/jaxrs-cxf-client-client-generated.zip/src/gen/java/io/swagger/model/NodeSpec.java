package io.swagger.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class NodeSpec  {
  
  @ApiModelProperty(example = "my-node", value = "Name for the node.")
 /**
   * Name for the node.  
  **/
  private String name = null;

  @ApiModelProperty(value = "User-defined key/value metadata.")
 /**
   * User-defined key/value metadata.  
  **/
  private Map<String, String> labels = null;


@XmlType(name="RoleEnum")
@XmlEnum(String.class)
public enum RoleEnum {

@XmlEnumValue("worker") WORKER(String.valueOf("worker")), @XmlEnumValue("manager") MANAGER(String.valueOf("manager"));


    private String value;

    RoleEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static RoleEnum fromValue(String v) {
        for (RoleEnum b : RoleEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "manager", value = "Role of the node.")
 /**
   * Role of the node.  
  **/
  private RoleEnum role = null;


@XmlType(name="AvailabilityEnum")
@XmlEnum(String.class)
public enum AvailabilityEnum {

@XmlEnumValue("active") ACTIVE(String.valueOf("active")), @XmlEnumValue("pause") PAUSE(String.valueOf("pause")), @XmlEnumValue("drain") DRAIN(String.valueOf("drain"));


    private String value;

    AvailabilityEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static AvailabilityEnum fromValue(String v) {
        for (AvailabilityEnum b : AvailabilityEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "active", value = "Availability of the node.")
 /**
   * Availability of the node.  
  **/
  private AvailabilityEnum availability = null;
 /**
   * Name for the node.
   * @return name
  **/
  @JsonProperty("Name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public NodeSpec name(String name) {
    this.name = name;
    return this;
  }

 /**
   * User-defined key/value metadata.
   * @return labels
  **/
  @JsonProperty("Labels")
  public Map<String, String> getLabels() {
    return labels;
  }

  public void setLabels(Map<String, String> labels) {
    this.labels = labels;
  }

  public NodeSpec labels(Map<String, String> labels) {
    this.labels = labels;
    return this;
  }

  public NodeSpec putLabelsItem(String key, String labelsItem) {
    this.labels.put(key, labelsItem);
    return this;
  }

 /**
   * Role of the node.
   * @return role
  **/
  @JsonProperty("Role")
  public String getRole() {
    if (role == null) {
      return null;
    }
    return role.value();
  }

  public void setRole(RoleEnum role) {
    this.role = role;
  }

  public NodeSpec role(RoleEnum role) {
    this.role = role;
    return this;
  }

 /**
   * Availability of the node.
   * @return availability
  **/
  @JsonProperty("Availability")
  public String getAvailability() {
    if (availability == null) {
      return null;
    }
    return availability.value();
  }

  public void setAvailability(AvailabilityEnum availability) {
    this.availability = availability;
  }

  public NodeSpec availability(AvailabilityEnum availability) {
    this.availability = availability;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class NodeSpec {\n");
    
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    labels: ").append(toIndentedString(labels)).append("\n");
    sb.append("    role: ").append(toIndentedString(role)).append("\n");
    sb.append("    availability: ").append(toIndentedString(availability)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

