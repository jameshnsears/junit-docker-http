package io.swagger.model;

import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ExecConfig  {
  
  @ApiModelProperty(value = "Attach to `stdin` of the exec command.")
 /**
   * Attach to `stdin` of the exec command.  
  **/
  private Boolean attachStdin = null;

  @ApiModelProperty(value = "Attach to `stdout` of the exec command.")
 /**
   * Attach to `stdout` of the exec command.  
  **/
  private Boolean attachStdout = null;

  @ApiModelProperty(value = "Attach to `stderr` of the exec command.")
 /**
   * Attach to `stderr` of the exec command.  
  **/
  private Boolean attachStderr = null;

  @ApiModelProperty(value = "Override the key sequence for detaching a container. Format is a single character `[a-Z]` or `ctrl-<value>` where `<value>` is one of: `a-z`, `@`, `^`, `[`, `,` or `_`.")
 /**
   * Override the key sequence for detaching a container. Format is a single character `[a-Z]` or `ctrl-<value>` where `<value>` is one of: `a-z`, `@`, `^`, `[`, `,` or `_`.  
  **/
  private String detachKeys = null;

  @ApiModelProperty(value = "Allocate a pseudo-TTY.")
 /**
   * Allocate a pseudo-TTY.  
  **/
  private Boolean tty = null;

  @ApiModelProperty(value = "A list of environment variables in the form `[\"VAR=value\", ...]`.")
 /**
   * A list of environment variables in the form `[\"VAR=value\", ...]`.  
  **/
  private List<String> env = null;

  @ApiModelProperty(value = "Command to run, as a string or array of strings.")
 /**
   * Command to run, as a string or array of strings.  
  **/
  private List<String> cmd = null;

  @ApiModelProperty(value = "Runs the exec process with extended privileges.")
 /**
   * Runs the exec process with extended privileges.  
  **/
  private Boolean privileged = false;

  @ApiModelProperty(value = "The user, and optionally, group to run the exec process inside the container. Format is one of: `user`, `user:group`, `uid`, or `uid:gid`.")
 /**
   * The user, and optionally, group to run the exec process inside the container. Format is one of: `user`, `user:group`, `uid`, or `uid:gid`.  
  **/
  private String user = null;

  @ApiModelProperty(value = "The working directory for the exec process inside the container.")
 /**
   * The working directory for the exec process inside the container.  
  **/
  private String workingDir = null;
 /**
   * Attach to &#x60;stdin&#x60; of the exec command.
   * @return attachStdin
  **/
  @JsonProperty("AttachStdin")
  public Boolean isAttachStdin() {
    return attachStdin;
  }

  public void setAttachStdin(Boolean attachStdin) {
    this.attachStdin = attachStdin;
  }

  public ExecConfig attachStdin(Boolean attachStdin) {
    this.attachStdin = attachStdin;
    return this;
  }

 /**
   * Attach to &#x60;stdout&#x60; of the exec command.
   * @return attachStdout
  **/
  @JsonProperty("AttachStdout")
  public Boolean isAttachStdout() {
    return attachStdout;
  }

  public void setAttachStdout(Boolean attachStdout) {
    this.attachStdout = attachStdout;
  }

  public ExecConfig attachStdout(Boolean attachStdout) {
    this.attachStdout = attachStdout;
    return this;
  }

 /**
   * Attach to &#x60;stderr&#x60; of the exec command.
   * @return attachStderr
  **/
  @JsonProperty("AttachStderr")
  public Boolean isAttachStderr() {
    return attachStderr;
  }

  public void setAttachStderr(Boolean attachStderr) {
    this.attachStderr = attachStderr;
  }

  public ExecConfig attachStderr(Boolean attachStderr) {
    this.attachStderr = attachStderr;
    return this;
  }

 /**
   * Override the key sequence for detaching a container. Format is a single character &#x60;[a-Z]&#x60; or &#x60;ctrl-&lt;value&gt;&#x60; where &#x60;&lt;value&gt;&#x60; is one of: &#x60;a-z&#x60;, &#x60;@&#x60;, &#x60;^&#x60;, &#x60;[&#x60;, &#x60;,&#x60; or &#x60;_&#x60;.
   * @return detachKeys
  **/
  @JsonProperty("DetachKeys")
  public String getDetachKeys() {
    return detachKeys;
  }

  public void setDetachKeys(String detachKeys) {
    this.detachKeys = detachKeys;
  }

  public ExecConfig detachKeys(String detachKeys) {
    this.detachKeys = detachKeys;
    return this;
  }

 /**
   * Allocate a pseudo-TTY.
   * @return tty
  **/
  @JsonProperty("Tty")
  public Boolean isTty() {
    return tty;
  }

  public void setTty(Boolean tty) {
    this.tty = tty;
  }

  public ExecConfig tty(Boolean tty) {
    this.tty = tty;
    return this;
  }

 /**
   * A list of environment variables in the form &#x60;[\&quot;VAR&#x3D;value\&quot;, ...]&#x60;.
   * @return env
  **/
  @JsonProperty("Env")
  public List<String> getEnv() {
    return env;
  }

  public void setEnv(List<String> env) {
    this.env = env;
  }

  public ExecConfig env(List<String> env) {
    this.env = env;
    return this;
  }

  public ExecConfig addEnvItem(String envItem) {
    this.env.add(envItem);
    return this;
  }

 /**
   * Command to run, as a string or array of strings.
   * @return cmd
  **/
  @JsonProperty("Cmd")
  public List<String> getCmd() {
    return cmd;
  }

  public void setCmd(List<String> cmd) {
    this.cmd = cmd;
  }

  public ExecConfig cmd(List<String> cmd) {
    this.cmd = cmd;
    return this;
  }

  public ExecConfig addCmdItem(String cmdItem) {
    this.cmd.add(cmdItem);
    return this;
  }

 /**
   * Runs the exec process with extended privileges.
   * @return privileged
  **/
  @JsonProperty("Privileged")
  public Boolean isPrivileged() {
    return privileged;
  }

  public void setPrivileged(Boolean privileged) {
    this.privileged = privileged;
  }

  public ExecConfig privileged(Boolean privileged) {
    this.privileged = privileged;
    return this;
  }

 /**
   * The user, and optionally, group to run the exec process inside the container. Format is one of: &#x60;user&#x60;, &#x60;user:group&#x60;, &#x60;uid&#x60;, or &#x60;uid:gid&#x60;.
   * @return user
  **/
  @JsonProperty("User")
  public String getUser() {
    return user;
  }

  public void setUser(String user) {
    this.user = user;
  }

  public ExecConfig user(String user) {
    this.user = user;
    return this;
  }

 /**
   * The working directory for the exec process inside the container.
   * @return workingDir
  **/
  @JsonProperty("WorkingDir")
  public String getWorkingDir() {
    return workingDir;
  }

  public void setWorkingDir(String workingDir) {
    this.workingDir = workingDir;
  }

  public ExecConfig workingDir(String workingDir) {
    this.workingDir = workingDir;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ExecConfig {\n");
    
    sb.append("    attachStdin: ").append(toIndentedString(attachStdin)).append("\n");
    sb.append("    attachStdout: ").append(toIndentedString(attachStdout)).append("\n");
    sb.append("    attachStderr: ").append(toIndentedString(attachStderr)).append("\n");
    sb.append("    detachKeys: ").append(toIndentedString(detachKeys)).append("\n");
    sb.append("    tty: ").append(toIndentedString(tty)).append("\n");
    sb.append("    env: ").append(toIndentedString(env)).append("\n");
    sb.append("    cmd: ").append(toIndentedString(cmd)).append("\n");
    sb.append("    privileged: ").append(toIndentedString(privileged)).append("\n");
    sb.append("    user: ").append(toIndentedString(user)).append("\n");
    sb.append("    workingDir: ").append(toIndentedString(workingDir)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

