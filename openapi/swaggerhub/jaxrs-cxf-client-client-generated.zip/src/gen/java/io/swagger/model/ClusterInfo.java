package io.swagger.model;

import io.swagger.annotations.ApiModel;
import io.swagger.model.ObjectVersion;
import io.swagger.model.SwarmSpec;
import io.swagger.model.TLSInfo;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * ClusterInfo represents information about the swarm as is returned by the \"/info\" endpoint. Join-tokens are not included. 
 **/
@ApiModel(description="ClusterInfo represents information about the swarm as is returned by the \"/info\" endpoint. Join-tokens are not included. ")
public class ClusterInfo  {
  
  @ApiModelProperty(example = "abajmipo7b4xz5ip2nrla6b11", value = "The ID of the swarm.")
 /**
   * The ID of the swarm.  
  **/
  private String ID = null;

  @ApiModelProperty(value = "")
  private ObjectVersion version = null;

  @ApiModelProperty(example = "2016-08-18T10:44:24.496525531Z", value = "Date and time at which the swarm was initialised in [RFC 3339](https://www.ietf.org/rfc/rfc3339.txt) format with nano-seconds. ")
 /**
   * Date and time at which the swarm was initialised in [RFC 3339](https://www.ietf.org/rfc/rfc3339.txt) format with nano-seconds.   
  **/
  private String createdAt = null;

  @ApiModelProperty(example = "2017-08-09T07:09:37.632105588Z", value = "Date and time at which the swarm was last updated in [RFC 3339](https://www.ietf.org/rfc/rfc3339.txt) format with nano-seconds. ")
 /**
   * Date and time at which the swarm was last updated in [RFC 3339](https://www.ietf.org/rfc/rfc3339.txt) format with nano-seconds.   
  **/
  private String updatedAt = null;

  @ApiModelProperty(value = "")
  private SwarmSpec spec = null;

  @ApiModelProperty(value = "")
  private TLSInfo tlSInfo = null;

  @ApiModelProperty(example = "false", value = "Whether there is currently a root CA rotation in progress for the swarm")
 /**
   * Whether there is currently a root CA rotation in progress for the swarm  
  **/
  private Boolean rootRotationInProgress = null;
 /**
   * The ID of the swarm.
   * @return ID
  **/
  @JsonProperty("ID")
  public String getID() {
    return ID;
  }

  public void setID(String ID) {
    this.ID = ID;
  }

  public ClusterInfo ID(String ID) {
    this.ID = ID;
    return this;
  }

 /**
   * Get version
   * @return version
  **/
  @JsonProperty("Version")
  public ObjectVersion getVersion() {
    return version;
  }

  public void setVersion(ObjectVersion version) {
    this.version = version;
  }

  public ClusterInfo version(ObjectVersion version) {
    this.version = version;
    return this;
  }

 /**
   * Date and time at which the swarm was initialised in [RFC 3339](https://www.ietf.org/rfc/rfc3339.txt) format with nano-seconds. 
   * @return createdAt
  **/
  @JsonProperty("CreatedAt")
  public String getCreatedAt() {
    return createdAt;
  }

  public void setCreatedAt(String createdAt) {
    this.createdAt = createdAt;
  }

  public ClusterInfo createdAt(String createdAt) {
    this.createdAt = createdAt;
    return this;
  }

 /**
   * Date and time at which the swarm was last updated in [RFC 3339](https://www.ietf.org/rfc/rfc3339.txt) format with nano-seconds. 
   * @return updatedAt
  **/
  @JsonProperty("UpdatedAt")
  public String getUpdatedAt() {
    return updatedAt;
  }

  public void setUpdatedAt(String updatedAt) {
    this.updatedAt = updatedAt;
  }

  public ClusterInfo updatedAt(String updatedAt) {
    this.updatedAt = updatedAt;
    return this;
  }

 /**
   * Get spec
   * @return spec
  **/
  @JsonProperty("Spec")
  public SwarmSpec getSpec() {
    return spec;
  }

  public void setSpec(SwarmSpec spec) {
    this.spec = spec;
  }

  public ClusterInfo spec(SwarmSpec spec) {
    this.spec = spec;
    return this;
  }

 /**
   * Get tlSInfo
   * @return tlSInfo
  **/
  @JsonProperty("TLSInfo")
  public TLSInfo getTlSInfo() {
    return tlSInfo;
  }

  public void setTlSInfo(TLSInfo tlSInfo) {
    this.tlSInfo = tlSInfo;
  }

  public ClusterInfo tlSInfo(TLSInfo tlSInfo) {
    this.tlSInfo = tlSInfo;
    return this;
  }

 /**
   * Whether there is currently a root CA rotation in progress for the swarm
   * @return rootRotationInProgress
  **/
  @JsonProperty("RootRotationInProgress")
  public Boolean isRootRotationInProgress() {
    return rootRotationInProgress;
  }

  public void setRootRotationInProgress(Boolean rootRotationInProgress) {
    this.rootRotationInProgress = rootRotationInProgress;
  }

  public ClusterInfo rootRotationInProgress(Boolean rootRotationInProgress) {
    this.rootRotationInProgress = rootRotationInProgress;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ClusterInfo {\n");
    
    sb.append("    ID: ").append(toIndentedString(ID)).append("\n");
    sb.append("    version: ").append(toIndentedString(version)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("    spec: ").append(toIndentedString(spec)).append("\n");
    sb.append("    tlSInfo: ").append(toIndentedString(tlSInfo)).append("\n");
    sb.append("    rootRotationInProgress: ").append(toIndentedString(rootRotationInProgress)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

