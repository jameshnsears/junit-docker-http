package io.swagger.model;

import io.swagger.model.ProcessConfig;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ExecInspectResponse  {
  
  @ApiModelProperty(value = "")
  private Boolean canRemove = null;

  @ApiModelProperty(value = "")
  private String detachKeys = null;

  @ApiModelProperty(value = "")
  private String ID = null;

  @ApiModelProperty(value = "")
  private Boolean running = null;

  @ApiModelProperty(value = "")
  private Integer exitCode = null;

  @ApiModelProperty(value = "")
  private ProcessConfig processConfig = null;

  @ApiModelProperty(value = "")
  private Boolean openStdin = null;

  @ApiModelProperty(value = "")
  private Boolean openStderr = null;

  @ApiModelProperty(value = "")
  private Boolean openStdout = null;

  @ApiModelProperty(value = "")
  private String containerID = null;

  @ApiModelProperty(value = "The system process ID for the exec process.")
 /**
   * The system process ID for the exec process.  
  **/
  private Integer pid = null;
 /**
   * Get canRemove
   * @return canRemove
  **/
  @JsonProperty("CanRemove")
  public Boolean isCanRemove() {
    return canRemove;
  }

  public void setCanRemove(Boolean canRemove) {
    this.canRemove = canRemove;
  }

  public ExecInspectResponse canRemove(Boolean canRemove) {
    this.canRemove = canRemove;
    return this;
  }

 /**
   * Get detachKeys
   * @return detachKeys
  **/
  @JsonProperty("DetachKeys")
  public String getDetachKeys() {
    return detachKeys;
  }

  public void setDetachKeys(String detachKeys) {
    this.detachKeys = detachKeys;
  }

  public ExecInspectResponse detachKeys(String detachKeys) {
    this.detachKeys = detachKeys;
    return this;
  }

 /**
   * Get ID
   * @return ID
  **/
  @JsonProperty("ID")
  public String getID() {
    return ID;
  }

  public void setID(String ID) {
    this.ID = ID;
  }

  public ExecInspectResponse ID(String ID) {
    this.ID = ID;
    return this;
  }

 /**
   * Get running
   * @return running
  **/
  @JsonProperty("Running")
  public Boolean isRunning() {
    return running;
  }

  public void setRunning(Boolean running) {
    this.running = running;
  }

  public ExecInspectResponse running(Boolean running) {
    this.running = running;
    return this;
  }

 /**
   * Get exitCode
   * @return exitCode
  **/
  @JsonProperty("ExitCode")
  public Integer getExitCode() {
    return exitCode;
  }

  public void setExitCode(Integer exitCode) {
    this.exitCode = exitCode;
  }

  public ExecInspectResponse exitCode(Integer exitCode) {
    this.exitCode = exitCode;
    return this;
  }

 /**
   * Get processConfig
   * @return processConfig
  **/
  @JsonProperty("ProcessConfig")
  public ProcessConfig getProcessConfig() {
    return processConfig;
  }

  public void setProcessConfig(ProcessConfig processConfig) {
    this.processConfig = processConfig;
  }

  public ExecInspectResponse processConfig(ProcessConfig processConfig) {
    this.processConfig = processConfig;
    return this;
  }

 /**
   * Get openStdin
   * @return openStdin
  **/
  @JsonProperty("OpenStdin")
  public Boolean isOpenStdin() {
    return openStdin;
  }

  public void setOpenStdin(Boolean openStdin) {
    this.openStdin = openStdin;
  }

  public ExecInspectResponse openStdin(Boolean openStdin) {
    this.openStdin = openStdin;
    return this;
  }

 /**
   * Get openStderr
   * @return openStderr
  **/
  @JsonProperty("OpenStderr")
  public Boolean isOpenStderr() {
    return openStderr;
  }

  public void setOpenStderr(Boolean openStderr) {
    this.openStderr = openStderr;
  }

  public ExecInspectResponse openStderr(Boolean openStderr) {
    this.openStderr = openStderr;
    return this;
  }

 /**
   * Get openStdout
   * @return openStdout
  **/
  @JsonProperty("OpenStdout")
  public Boolean isOpenStdout() {
    return openStdout;
  }

  public void setOpenStdout(Boolean openStdout) {
    this.openStdout = openStdout;
  }

  public ExecInspectResponse openStdout(Boolean openStdout) {
    this.openStdout = openStdout;
    return this;
  }

 /**
   * Get containerID
   * @return containerID
  **/
  @JsonProperty("ContainerID")
  public String getContainerID() {
    return containerID;
  }

  public void setContainerID(String containerID) {
    this.containerID = containerID;
  }

  public ExecInspectResponse containerID(String containerID) {
    this.containerID = containerID;
    return this;
  }

 /**
   * The system process ID for the exec process.
   * @return pid
  **/
  @JsonProperty("Pid")
  public Integer getPid() {
    return pid;
  }

  public void setPid(Integer pid) {
    this.pid = pid;
  }

  public ExecInspectResponse pid(Integer pid) {
    this.pid = pid;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ExecInspectResponse {\n");
    
    sb.append("    canRemove: ").append(toIndentedString(canRemove)).append("\n");
    sb.append("    detachKeys: ").append(toIndentedString(detachKeys)).append("\n");
    sb.append("    ID: ").append(toIndentedString(ID)).append("\n");
    sb.append("    running: ").append(toIndentedString(running)).append("\n");
    sb.append("    exitCode: ").append(toIndentedString(exitCode)).append("\n");
    sb.append("    processConfig: ").append(toIndentedString(processConfig)).append("\n");
    sb.append("    openStdin: ").append(toIndentedString(openStdin)).append("\n");
    sb.append("    openStderr: ").append(toIndentedString(openStderr)).append("\n");
    sb.append("    openStdout: ").append(toIndentedString(openStdout)).append("\n");
    sb.append("    containerID: ").append(toIndentedString(containerID)).append("\n");
    sb.append("    pid: ").append(toIndentedString(pid)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

