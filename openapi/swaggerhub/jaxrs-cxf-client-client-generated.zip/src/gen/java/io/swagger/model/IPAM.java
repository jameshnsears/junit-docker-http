package io.swagger.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class IPAM  {
  
  @ApiModelProperty(value = "Name of the IPAM driver to use.")
 /**
   * Name of the IPAM driver to use.  
  **/
  private String driver = "default";

  @ApiModelProperty(value = "List of IPAM configuration options, specified as a map: `{\"Subnet\": <CIDR>, \"IPRange\": <CIDR>, \"Gateway\": <IP address>, \"AuxAddress\": <device_name:IP address>}`")
 /**
   * List of IPAM configuration options, specified as a map: `{\"Subnet\": <CIDR>, \"IPRange\": <CIDR>, \"Gateway\": <IP address>, \"AuxAddress\": <device_name:IP address>}`  
  **/
  private List<Map<String, String>> config = null;

  @ApiModelProperty(value = "Driver-specific options, specified as a map.")
 /**
   * Driver-specific options, specified as a map.  
  **/
  private List<Map<String, String>> options = null;
 /**
   * Name of the IPAM driver to use.
   * @return driver
  **/
  @JsonProperty("Driver")
  public String getDriver() {
    return driver;
  }

  public void setDriver(String driver) {
    this.driver = driver;
  }

  public IPAM driver(String driver) {
    this.driver = driver;
    return this;
  }

 /**
   * List of IPAM configuration options, specified as a map: &#x60;{\&quot;Subnet\&quot;: &lt;CIDR&gt;, \&quot;IPRange\&quot;: &lt;CIDR&gt;, \&quot;Gateway\&quot;: &lt;IP address&gt;, \&quot;AuxAddress\&quot;: &lt;device_name:IP address&gt;}&#x60;
   * @return config
  **/
  @JsonProperty("Config")
  public List<Map<String, String>> getConfig() {
    return config;
  }

  public void setConfig(List<Map<String, String>> config) {
    this.config = config;
  }

  public IPAM config(List<Map<String, String>> config) {
    this.config = config;
    return this;
  }

  public IPAM addConfigItem(Map<String, String> configItem) {
    this.config.add(configItem);
    return this;
  }

 /**
   * Driver-specific options, specified as a map.
   * @return options
  **/
  @JsonProperty("Options")
  public List<Map<String, String>> getOptions() {
    return options;
  }

  public void setOptions(List<Map<String, String>> options) {
    this.options = options;
  }

  public IPAM options(List<Map<String, String>> options) {
    this.options = options;
    return this;
  }

  public IPAM addOptionsItem(Map<String, String> optionsItem) {
    this.options.add(optionsItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class IPAM {\n");
    
    sb.append("    driver: ").append(toIndentedString(driver)).append("\n");
    sb.append("    config: ").append(toIndentedString(config)).append("\n");
    sb.append("    options: ").append(toIndentedString(options)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

