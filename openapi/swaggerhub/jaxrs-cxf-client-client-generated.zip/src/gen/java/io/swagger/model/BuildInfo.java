package io.swagger.model;

import io.swagger.model.ErrorDetail;
import io.swagger.model.ImageID;
import io.swagger.model.ProgressDetail;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class BuildInfo  {
  
  @ApiModelProperty(value = "")
  private String id = null;

  @ApiModelProperty(value = "")
  private String stream = null;

  @ApiModelProperty(value = "")
  private String error = null;

  @ApiModelProperty(value = "")
  private ErrorDetail errorDetail = null;

  @ApiModelProperty(value = "")
  private String status = null;

  @ApiModelProperty(value = "")
  private String progress = null;

  @ApiModelProperty(value = "")
  private ProgressDetail progressDetail = null;

  @ApiModelProperty(value = "")
  private ImageID aux = null;
 /**
   * Get id
   * @return id
  **/
  @JsonProperty("id")
  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public BuildInfo id(String id) {
    this.id = id;
    return this;
  }

 /**
   * Get stream
   * @return stream
  **/
  @JsonProperty("stream")
  public String getStream() {
    return stream;
  }

  public void setStream(String stream) {
    this.stream = stream;
  }

  public BuildInfo stream(String stream) {
    this.stream = stream;
    return this;
  }

 /**
   * Get error
   * @return error
  **/
  @JsonProperty("error")
  public String getError() {
    return error;
  }

  public void setError(String error) {
    this.error = error;
  }

  public BuildInfo error(String error) {
    this.error = error;
    return this;
  }

 /**
   * Get errorDetail
   * @return errorDetail
  **/
  @JsonProperty("errorDetail")
  public ErrorDetail getErrorDetail() {
    return errorDetail;
  }

  public void setErrorDetail(ErrorDetail errorDetail) {
    this.errorDetail = errorDetail;
  }

  public BuildInfo errorDetail(ErrorDetail errorDetail) {
    this.errorDetail = errorDetail;
    return this;
  }

 /**
   * Get status
   * @return status
  **/
  @JsonProperty("status")
  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public BuildInfo status(String status) {
    this.status = status;
    return this;
  }

 /**
   * Get progress
   * @return progress
  **/
  @JsonProperty("progress")
  public String getProgress() {
    return progress;
  }

  public void setProgress(String progress) {
    this.progress = progress;
  }

  public BuildInfo progress(String progress) {
    this.progress = progress;
    return this;
  }

 /**
   * Get progressDetail
   * @return progressDetail
  **/
  @JsonProperty("progressDetail")
  public ProgressDetail getProgressDetail() {
    return progressDetail;
  }

  public void setProgressDetail(ProgressDetail progressDetail) {
    this.progressDetail = progressDetail;
  }

  public BuildInfo progressDetail(ProgressDetail progressDetail) {
    this.progressDetail = progressDetail;
    return this;
  }

 /**
   * Get aux
   * @return aux
  **/
  @JsonProperty("aux")
  public ImageID getAux() {
    return aux;
  }

  public void setAux(ImageID aux) {
    this.aux = aux;
  }

  public BuildInfo aux(ImageID aux) {
    this.aux = aux;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BuildInfo {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    stream: ").append(toIndentedString(stream)).append("\n");
    sb.append("    error: ").append(toIndentedString(error)).append("\n");
    sb.append("    errorDetail: ").append(toIndentedString(errorDetail)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    progress: ").append(toIndentedString(progress)).append("\n");
    sb.append("    progressDetail: ").append(toIndentedString(progressDetail)).append("\n");
    sb.append("    aux: ").append(toIndentedString(aux)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

