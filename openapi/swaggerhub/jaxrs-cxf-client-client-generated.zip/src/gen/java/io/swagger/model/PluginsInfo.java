package io.swagger.model;

import io.swagger.annotations.ApiModel;
import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * Available plugins per type.  <p><br /></p>  > **Note**: Only unmanaged (V1) plugins are included in this list. > V1 plugins are \"lazily\" loaded, and are not returned in this list > if there is no resource using the plugin. 
 **/
@ApiModel(description="Available plugins per type.  <p><br /></p>  > **Note**: Only unmanaged (V1) plugins are included in this list. > V1 plugins are \"lazily\" loaded, and are not returned in this list > if there is no resource using the plugin. ")
public class PluginsInfo  {
  
  @ApiModelProperty(example = "[\"local\"]", value = "Names of available volume-drivers, and network-driver plugins.")
 /**
   * Names of available volume-drivers, and network-driver plugins.  
  **/
  private List<String> volume = null;

  @ApiModelProperty(example = "[\"bridge\",\"host\",\"ipvlan\",\"macvlan\",\"null\",\"overlay\"]", value = "Names of available network-drivers, and network-driver plugins.")
 /**
   * Names of available network-drivers, and network-driver plugins.  
  **/
  private List<String> network = null;

  @ApiModelProperty(example = "[\"img-authz-plugin\",\"hbm\"]", value = "Names of available authorization plugins.")
 /**
   * Names of available authorization plugins.  
  **/
  private List<String> authorization = null;

  @ApiModelProperty(example = "[\"awslogs\",\"fluentd\",\"gcplogs\",\"gelf\",\"journald\",\"json-file\",\"logentries\",\"splunk\",\"syslog\"]", value = "Names of available logging-drivers, and logging-driver plugins.")
 /**
   * Names of available logging-drivers, and logging-driver plugins.  
  **/
  private List<String> log = null;
 /**
   * Names of available volume-drivers, and network-driver plugins.
   * @return volume
  **/
  @JsonProperty("Volume")
  public List<String> getVolume() {
    return volume;
  }

  public void setVolume(List<String> volume) {
    this.volume = volume;
  }

  public PluginsInfo volume(List<String> volume) {
    this.volume = volume;
    return this;
  }

  public PluginsInfo addVolumeItem(String volumeItem) {
    this.volume.add(volumeItem);
    return this;
  }

 /**
   * Names of available network-drivers, and network-driver plugins.
   * @return network
  **/
  @JsonProperty("Network")
  public List<String> getNetwork() {
    return network;
  }

  public void setNetwork(List<String> network) {
    this.network = network;
  }

  public PluginsInfo network(List<String> network) {
    this.network = network;
    return this;
  }

  public PluginsInfo addNetworkItem(String networkItem) {
    this.network.add(networkItem);
    return this;
  }

 /**
   * Names of available authorization plugins.
   * @return authorization
  **/
  @JsonProperty("Authorization")
  public List<String> getAuthorization() {
    return authorization;
  }

  public void setAuthorization(List<String> authorization) {
    this.authorization = authorization;
  }

  public PluginsInfo authorization(List<String> authorization) {
    this.authorization = authorization;
    return this;
  }

  public PluginsInfo addAuthorizationItem(String authorizationItem) {
    this.authorization.add(authorizationItem);
    return this;
  }

 /**
   * Names of available logging-drivers, and logging-driver plugins.
   * @return log
  **/
  @JsonProperty("Log")
  public List<String> getLog() {
    return log;
  }

  public void setLog(List<String> log) {
    this.log = log;
  }

  public PluginsInfo log(List<String> log) {
    this.log = log;
    return this;
  }

  public PluginsInfo addLogItem(String logItem) {
    this.log.add(logItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PluginsInfo {\n");
    
    sb.append("    volume: ").append(toIndentedString(volume)).append("\n");
    sb.append("    network: ").append(toIndentedString(network)).append("\n");
    sb.append("    authorization: ").append(toIndentedString(authorization)).append("\n");
    sb.append("    log: ").append(toIndentedString(log)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

