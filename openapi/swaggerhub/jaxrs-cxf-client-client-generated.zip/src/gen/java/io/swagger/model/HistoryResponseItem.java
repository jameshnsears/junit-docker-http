package io.swagger.model;

import io.swagger.annotations.ApiModel;
import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * individual image layer information in response to ImageHistory operation
 **/
@ApiModel(description="individual image layer information in response to ImageHistory operation")
public class HistoryResponseItem  {
  
  @ApiModelProperty(required = true, value = "")
  private String id = null;

  @ApiModelProperty(required = true, value = "")
  private Long created = null;

  @ApiModelProperty(required = true, value = "")
  private String createdBy = null;

  @ApiModelProperty(required = true, value = "")
  private List<String> tags = new ArrayList<String>();

  @ApiModelProperty(required = true, value = "")
  private Long size = null;

  @ApiModelProperty(required = true, value = "")
  private String comment = null;
 /**
   * Get id
   * @return id
  **/
  @JsonProperty("Id")
  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public HistoryResponseItem id(String id) {
    this.id = id;
    return this;
  }

 /**
   * Get created
   * @return created
  **/
  @JsonProperty("Created")
  public Long getCreated() {
    return created;
  }

  public void setCreated(Long created) {
    this.created = created;
  }

  public HistoryResponseItem created(Long created) {
    this.created = created;
    return this;
  }

 /**
   * Get createdBy
   * @return createdBy
  **/
  @JsonProperty("CreatedBy")
  public String getCreatedBy() {
    return createdBy;
  }

  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  public HistoryResponseItem createdBy(String createdBy) {
    this.createdBy = createdBy;
    return this;
  }

 /**
   * Get tags
   * @return tags
  **/
  @JsonProperty("Tags")
  public List<String> getTags() {
    return tags;
  }

  public void setTags(List<String> tags) {
    this.tags = tags;
  }

  public HistoryResponseItem tags(List<String> tags) {
    this.tags = tags;
    return this;
  }

  public HistoryResponseItem addTagsItem(String tagsItem) {
    this.tags.add(tagsItem);
    return this;
  }

 /**
   * Get size
   * @return size
  **/
  @JsonProperty("Size")
  public Long getSize() {
    return size;
  }

  public void setSize(Long size) {
    this.size = size;
  }

  public HistoryResponseItem size(Long size) {
    this.size = size;
    return this;
  }

 /**
   * Get comment
   * @return comment
  **/
  @JsonProperty("Comment")
  public String getComment() {
    return comment;
  }

  public void setComment(String comment) {
    this.comment = comment;
  }

  public HistoryResponseItem comment(String comment) {
    this.comment = comment;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class HistoryResponseItem {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    created: ").append(toIndentedString(created)).append("\n");
    sb.append("    createdBy: ").append(toIndentedString(createdBy)).append("\n");
    sb.append("    tags: ").append(toIndentedString(tags)).append("\n");
    sb.append("    size: ").append(toIndentedString(size)).append("\n");
    sb.append("    comment: ").append(toIndentedString(comment)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

