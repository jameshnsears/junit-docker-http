package io.swagger.model;

import io.swagger.annotations.ApiModel;
import java.math.BigDecimal;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * Specification for the rollback strategy of the service.
 **/
@ApiModel(description="Specification for the rollback strategy of the service.")
public class ServiceSpecRollbackConfig  {
  
  @ApiModelProperty(value = "Maximum number of tasks to be rolled back in one iteration (0 means unlimited parallelism).")
 /**
   * Maximum number of tasks to be rolled back in one iteration (0 means unlimited parallelism).  
  **/
  private Long parallelism = null;

  @ApiModelProperty(value = "Amount of time between rollback iterations, in nanoseconds.")
 /**
   * Amount of time between rollback iterations, in nanoseconds.  
  **/
  private Long delay = null;


@XmlType(name="FailureActionEnum")
@XmlEnum(String.class)
public enum FailureActionEnum {

@XmlEnumValue("continue") CONTINUE(String.valueOf("continue")), @XmlEnumValue("pause") PAUSE(String.valueOf("pause"));


    private String value;

    FailureActionEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static FailureActionEnum fromValue(String v) {
        for (FailureActionEnum b : FailureActionEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(value = "Action to take if an rolled back task fails to run, or stops running during the rollback.")
 /**
   * Action to take if an rolled back task fails to run, or stops running during the rollback.  
  **/
  private FailureActionEnum failureAction = null;

  @ApiModelProperty(value = "Amount of time to monitor each rolled back task for failures, in nanoseconds.")
 /**
   * Amount of time to monitor each rolled back task for failures, in nanoseconds.  
  **/
  private Long monitor = null;

  @ApiModelProperty(value = "The fraction of tasks that may fail during a rollback before the failure action is invoked, specified as a floating point number between 0 and 1.")
 /**
   * The fraction of tasks that may fail during a rollback before the failure action is invoked, specified as a floating point number between 0 and 1.  
  **/
  private BigDecimal maxFailureRatio = null;


@XmlType(name="OrderEnum")
@XmlEnum(String.class)
public enum OrderEnum {

@XmlEnumValue("stop-first") STOP_FIRST(String.valueOf("stop-first")), @XmlEnumValue("start-first") START_FIRST(String.valueOf("start-first"));


    private String value;

    OrderEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static OrderEnum fromValue(String v) {
        for (OrderEnum b : OrderEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(value = "The order of operations when rolling back a task. Either the old task is shut down before the new task is started, or the new task is started before the old task is shut down.")
 /**
   * The order of operations when rolling back a task. Either the old task is shut down before the new task is started, or the new task is started before the old task is shut down.  
  **/
  private OrderEnum order = null;
 /**
   * Maximum number of tasks to be rolled back in one iteration (0 means unlimited parallelism).
   * @return parallelism
  **/
  @JsonProperty("Parallelism")
  public Long getParallelism() {
    return parallelism;
  }

  public void setParallelism(Long parallelism) {
    this.parallelism = parallelism;
  }

  public ServiceSpecRollbackConfig parallelism(Long parallelism) {
    this.parallelism = parallelism;
    return this;
  }

 /**
   * Amount of time between rollback iterations, in nanoseconds.
   * @return delay
  **/
  @JsonProperty("Delay")
  public Long getDelay() {
    return delay;
  }

  public void setDelay(Long delay) {
    this.delay = delay;
  }

  public ServiceSpecRollbackConfig delay(Long delay) {
    this.delay = delay;
    return this;
  }

 /**
   * Action to take if an rolled back task fails to run, or stops running during the rollback.
   * @return failureAction
  **/
  @JsonProperty("FailureAction")
  public String getFailureAction() {
    if (failureAction == null) {
      return null;
    }
    return failureAction.value();
  }

  public void setFailureAction(FailureActionEnum failureAction) {
    this.failureAction = failureAction;
  }

  public ServiceSpecRollbackConfig failureAction(FailureActionEnum failureAction) {
    this.failureAction = failureAction;
    return this;
  }

 /**
   * Amount of time to monitor each rolled back task for failures, in nanoseconds.
   * @return monitor
  **/
  @JsonProperty("Monitor")
  public Long getMonitor() {
    return monitor;
  }

  public void setMonitor(Long monitor) {
    this.monitor = monitor;
  }

  public ServiceSpecRollbackConfig monitor(Long monitor) {
    this.monitor = monitor;
    return this;
  }

 /**
   * The fraction of tasks that may fail during a rollback before the failure action is invoked, specified as a floating point number between 0 and 1.
   * @return maxFailureRatio
  **/
  @JsonProperty("MaxFailureRatio")
  public BigDecimal getMaxFailureRatio() {
    return maxFailureRatio;
  }

  public void setMaxFailureRatio(BigDecimal maxFailureRatio) {
    this.maxFailureRatio = maxFailureRatio;
  }

  public ServiceSpecRollbackConfig maxFailureRatio(BigDecimal maxFailureRatio) {
    this.maxFailureRatio = maxFailureRatio;
    return this;
  }

 /**
   * The order of operations when rolling back a task. Either the old task is shut down before the new task is started, or the new task is started before the old task is shut down.
   * @return order
  **/
  @JsonProperty("Order")
  public String getOrder() {
    if (order == null) {
      return null;
    }
    return order.value();
  }

  public void setOrder(OrderEnum order) {
    this.order = order;
  }

  public ServiceSpecRollbackConfig order(OrderEnum order) {
    this.order = order;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ServiceSpecRollbackConfig {\n");
    
    sb.append("    parallelism: ").append(toIndentedString(parallelism)).append("\n");
    sb.append("    delay: ").append(toIndentedString(delay)).append("\n");
    sb.append("    failureAction: ").append(toIndentedString(failureAction)).append("\n");
    sb.append("    monitor: ").append(toIndentedString(monitor)).append("\n");
    sb.append("    maxFailureRatio: ").append(toIndentedString(maxFailureRatio)).append("\n");
    sb.append("    order: ").append(toIndentedString(order)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

