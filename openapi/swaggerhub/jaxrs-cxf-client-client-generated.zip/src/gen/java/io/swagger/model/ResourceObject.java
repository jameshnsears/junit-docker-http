package io.swagger.model;

import io.swagger.annotations.ApiModel;
import io.swagger.model.GenericResources;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * An object describing the resources which can be advertised by a node and requested by a task
 **/
@ApiModel(description="An object describing the resources which can be advertised by a node and requested by a task")
public class ResourceObject  {
  
  @ApiModelProperty(example = "4000000000", value = "")
  private Long nanoCPUs = null;

  @ApiModelProperty(example = "8272408576", value = "")
  private Long memoryBytes = null;

  @ApiModelProperty(value = "")
  private GenericResources genericResources = null;
 /**
   * Get nanoCPUs
   * @return nanoCPUs
  **/
  @JsonProperty("NanoCPUs")
  public Long getNanoCPUs() {
    return nanoCPUs;
  }

  public void setNanoCPUs(Long nanoCPUs) {
    this.nanoCPUs = nanoCPUs;
  }

  public ResourceObject nanoCPUs(Long nanoCPUs) {
    this.nanoCPUs = nanoCPUs;
    return this;
  }

 /**
   * Get memoryBytes
   * @return memoryBytes
  **/
  @JsonProperty("MemoryBytes")
  public Long getMemoryBytes() {
    return memoryBytes;
  }

  public void setMemoryBytes(Long memoryBytes) {
    this.memoryBytes = memoryBytes;
  }

  public ResourceObject memoryBytes(Long memoryBytes) {
    this.memoryBytes = memoryBytes;
    return this;
  }

 /**
   * Get genericResources
   * @return genericResources
  **/
  @JsonProperty("GenericResources")
  public GenericResources getGenericResources() {
    return genericResources;
  }

  public void setGenericResources(GenericResources genericResources) {
    this.genericResources = genericResources;
  }

  public ResourceObject genericResources(GenericResources genericResources) {
    this.genericResources = genericResources;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ResourceObject {\n");
    
    sb.append("    nanoCPUs: ").append(toIndentedString(nanoCPUs)).append("\n");
    sb.append("    memoryBytes: ").append(toIndentedString(memoryBytes)).append("\n");
    sb.append("    genericResources: ").append(toIndentedString(genericResources)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

