package io.swagger.model;

import io.swagger.annotations.ApiModel;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * A mount point inside a container
 **/
@ApiModel(description="A mount point inside a container")
public class MountPoint  {
  
  @ApiModelProperty(value = "")
  private String type = null;

  @ApiModelProperty(value = "")
  private String name = null;

  @ApiModelProperty(value = "")
  private String source = null;

  @ApiModelProperty(value = "")
  private String destination = null;

  @ApiModelProperty(value = "")
  private String driver = null;

  @ApiModelProperty(value = "")
  private String mode = null;

  @ApiModelProperty(value = "")
  private Boolean RW = null;

  @ApiModelProperty(value = "")
  private String propagation = null;
 /**
   * Get type
   * @return type
  **/
  @JsonProperty("Type")
  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public MountPoint type(String type) {
    this.type = type;
    return this;
  }

 /**
   * Get name
   * @return name
  **/
  @JsonProperty("Name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public MountPoint name(String name) {
    this.name = name;
    return this;
  }

 /**
   * Get source
   * @return source
  **/
  @JsonProperty("Source")
  public String getSource() {
    return source;
  }

  public void setSource(String source) {
    this.source = source;
  }

  public MountPoint source(String source) {
    this.source = source;
    return this;
  }

 /**
   * Get destination
   * @return destination
  **/
  @JsonProperty("Destination")
  public String getDestination() {
    return destination;
  }

  public void setDestination(String destination) {
    this.destination = destination;
  }

  public MountPoint destination(String destination) {
    this.destination = destination;
    return this;
  }

 /**
   * Get driver
   * @return driver
  **/
  @JsonProperty("Driver")
  public String getDriver() {
    return driver;
  }

  public void setDriver(String driver) {
    this.driver = driver;
  }

  public MountPoint driver(String driver) {
    this.driver = driver;
    return this;
  }

 /**
   * Get mode
   * @return mode
  **/
  @JsonProperty("Mode")
  public String getMode() {
    return mode;
  }

  public void setMode(String mode) {
    this.mode = mode;
  }

  public MountPoint mode(String mode) {
    this.mode = mode;
    return this;
  }

 /**
   * Get RW
   * @return RW
  **/
  @JsonProperty("RW")
  public Boolean isRW() {
    return RW;
  }

  public void setRW(Boolean RW) {
    this.RW = RW;
  }

  public MountPoint RW(Boolean RW) {
    this.RW = RW;
    return this;
  }

 /**
   * Get propagation
   * @return propagation
  **/
  @JsonProperty("Propagation")
  public String getPropagation() {
    return propagation;
  }

  public void setPropagation(String propagation) {
    this.propagation = propagation;
  }

  public MountPoint propagation(String propagation) {
    this.propagation = propagation;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class MountPoint {\n");
    
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    source: ").append(toIndentedString(source)).append("\n");
    sb.append("    destination: ").append(toIndentedString(destination)).append("\n");
    sb.append("    driver: ").append(toIndentedString(driver)).append("\n");
    sb.append("    mode: ").append(toIndentedString(mode)).append("\n");
    sb.append("    RW: ").append(toIndentedString(RW)).append("\n");
    sb.append("    propagation: ").append(toIndentedString(propagation)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

