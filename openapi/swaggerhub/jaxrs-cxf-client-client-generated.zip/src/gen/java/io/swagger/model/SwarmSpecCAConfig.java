package io.swagger.model;

import io.swagger.annotations.ApiModel;
import io.swagger.model.SwarmSpecCAConfigExternalCAs;
import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * CA configuration.
 **/
@ApiModel(description="CA configuration.")
public class SwarmSpecCAConfig  {
  
  @ApiModelProperty(example = "7776000000000000", value = "The duration node certificates are issued for.")
 /**
   * The duration node certificates are issued for.  
  **/
  private Long nodeCertExpiry = null;

  @ApiModelProperty(value = "Configuration for forwarding signing requests to an external certificate authority.")
 /**
   * Configuration for forwarding signing requests to an external certificate authority.  
  **/
  private List<SwarmSpecCAConfigExternalCAs> externalCAs = null;

  @ApiModelProperty(value = "The desired signing CA certificate for all swarm node TLS leaf certificates, in PEM format.")
 /**
   * The desired signing CA certificate for all swarm node TLS leaf certificates, in PEM format.  
  **/
  private String signingCACert = null;

  @ApiModelProperty(value = "The desired signing CA key for all swarm node TLS leaf certificates, in PEM format.")
 /**
   * The desired signing CA key for all swarm node TLS leaf certificates, in PEM format.  
  **/
  private String signingCAKey = null;

  @ApiModelProperty(value = "An integer whose purpose is to force swarm to generate a new signing CA certificate and key, if none have been specified in `SigningCACert` and `SigningCAKey`")
 /**
   * An integer whose purpose is to force swarm to generate a new signing CA certificate and key, if none have been specified in `SigningCACert` and `SigningCAKey`  
  **/
  private Integer forceRotate = null;
 /**
   * The duration node certificates are issued for.
   * @return nodeCertExpiry
  **/
  @JsonProperty("NodeCertExpiry")
  public Long getNodeCertExpiry() {
    return nodeCertExpiry;
  }

  public void setNodeCertExpiry(Long nodeCertExpiry) {
    this.nodeCertExpiry = nodeCertExpiry;
  }

  public SwarmSpecCAConfig nodeCertExpiry(Long nodeCertExpiry) {
    this.nodeCertExpiry = nodeCertExpiry;
    return this;
  }

 /**
   * Configuration for forwarding signing requests to an external certificate authority.
   * @return externalCAs
  **/
  @JsonProperty("ExternalCAs")
  public List<SwarmSpecCAConfigExternalCAs> getExternalCAs() {
    return externalCAs;
  }

  public void setExternalCAs(List<SwarmSpecCAConfigExternalCAs> externalCAs) {
    this.externalCAs = externalCAs;
  }

  public SwarmSpecCAConfig externalCAs(List<SwarmSpecCAConfigExternalCAs> externalCAs) {
    this.externalCAs = externalCAs;
    return this;
  }

  public SwarmSpecCAConfig addExternalCAsItem(SwarmSpecCAConfigExternalCAs externalCAsItem) {
    this.externalCAs.add(externalCAsItem);
    return this;
  }

 /**
   * The desired signing CA certificate for all swarm node TLS leaf certificates, in PEM format.
   * @return signingCACert
  **/
  @JsonProperty("SigningCACert")
  public String getSigningCACert() {
    return signingCACert;
  }

  public void setSigningCACert(String signingCACert) {
    this.signingCACert = signingCACert;
  }

  public SwarmSpecCAConfig signingCACert(String signingCACert) {
    this.signingCACert = signingCACert;
    return this;
  }

 /**
   * The desired signing CA key for all swarm node TLS leaf certificates, in PEM format.
   * @return signingCAKey
  **/
  @JsonProperty("SigningCAKey")
  public String getSigningCAKey() {
    return signingCAKey;
  }

  public void setSigningCAKey(String signingCAKey) {
    this.signingCAKey = signingCAKey;
  }

  public SwarmSpecCAConfig signingCAKey(String signingCAKey) {
    this.signingCAKey = signingCAKey;
    return this;
  }

 /**
   * An integer whose purpose is to force swarm to generate a new signing CA certificate and key, if none have been specified in &#x60;SigningCACert&#x60; and &#x60;SigningCAKey&#x60;
   * @return forceRotate
  **/
  @JsonProperty("ForceRotate")
  public Integer getForceRotate() {
    return forceRotate;
  }

  public void setForceRotate(Integer forceRotate) {
    this.forceRotate = forceRotate;
  }

  public SwarmSpecCAConfig forceRotate(Integer forceRotate) {
    this.forceRotate = forceRotate;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SwarmSpecCAConfig {\n");
    
    sb.append("    nodeCertExpiry: ").append(toIndentedString(nodeCertExpiry)).append("\n");
    sb.append("    externalCAs: ").append(toIndentedString(externalCAs)).append("\n");
    sb.append("    signingCACert: ").append(toIndentedString(signingCACert)).append("\n");
    sb.append("    signingCAKey: ").append(toIndentedString(signingCAKey)).append("\n");
    sb.append("    forceRotate: ").append(toIndentedString(forceRotate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

