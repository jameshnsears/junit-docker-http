package io.swagger.model;

import io.swagger.annotations.ApiModel;
import io.swagger.model.Reachability;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * ManagerStatus represents the status of a manager.  It provides the current status of a node's manager component, if the node is a manager. 
 **/
@ApiModel(description="ManagerStatus represents the status of a manager.  It provides the current status of a node's manager component, if the node is a manager. ")
public class ManagerStatus  {
  
  @ApiModelProperty(example = "true", value = "")
  private Boolean leader = false;

  @ApiModelProperty(value = "")
  private Reachability reachability = null;

  @ApiModelProperty(example = "10.0.0.46:2377", value = "The IP address and port at which the manager is reachable. ")
 /**
   * The IP address and port at which the manager is reachable.   
  **/
  private String addr = null;
 /**
   * Get leader
   * @return leader
  **/
  @JsonProperty("Leader")
  public Boolean isLeader() {
    return leader;
  }

  public void setLeader(Boolean leader) {
    this.leader = leader;
  }

  public ManagerStatus leader(Boolean leader) {
    this.leader = leader;
    return this;
  }

 /**
   * Get reachability
   * @return reachability
  **/
  @JsonProperty("Reachability")
  public Reachability getReachability() {
    return reachability;
  }

  public void setReachability(Reachability reachability) {
    this.reachability = reachability;
  }

  public ManagerStatus reachability(Reachability reachability) {
    this.reachability = reachability;
    return this;
  }

 /**
   * The IP address and port at which the manager is reachable. 
   * @return addr
  **/
  @JsonProperty("Addr")
  public String getAddr() {
    return addr;
  }

  public void setAddr(String addr) {
    this.addr = addr;
  }

  public ManagerStatus addr(String addr) {
    this.addr = addr;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ManagerStatus {\n");
    
    sb.append("    leader: ").append(toIndentedString(leader)).append("\n");
    sb.append("    reachability: ").append(toIndentedString(reachability)).append("\n");
    sb.append("    addr: ").append(toIndentedString(addr)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

