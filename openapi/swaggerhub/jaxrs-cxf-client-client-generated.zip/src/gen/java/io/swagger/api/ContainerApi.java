package io.swagger.api;

import io.swagger.model.ContainerCreateResponse;
import io.swagger.model.ContainerInspectResponse;
import io.swagger.model.ContainerPruneResponse;
import io.swagger.model.ContainerSummary;
import io.swagger.model.ContainerTopResponse;
import io.swagger.model.ContainerUpdateResponse;
import io.swagger.model.ContainerWaitResponse;
import io.swagger.model.ErrorResponse;
import io.swagger.model.InlineResponse400;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import org.apache.cxf.jaxrs.ext.multipart.*;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.ApiResponse;
import io.swagger.jaxrs.PATCH;

/**
 * Docker Engine API
 *
 * <p>The Engine API is an HTTP API served by Docker Engine. It is the API the Docker client uses to communicate with the Engine, so everything the Docker client can do can be done with the API.  Most of the client's commands map directly to API endpoints (e.g. `docker ps` is `GET /containers/json`). The notable exception is running containers, which consists of several API calls.  # Errors  The API uses standard HTTP status codes to indicate the success or failure of the API call. The body of the response will be JSON in the following format:  ``` {   \"message\": \"page not found\" } ```  # Versioning  The API is usually changed in each release, so API calls are versioned to ensure that clients don't break. To lock to a specific version of the API, you prefix the URL with its version, for example, call `/v1.30/info` to use the v1.30 version of the `/info` endpoint. If the API version specified in the URL is not supported by the daemon, a HTTP `400 Bad Request` error message is returned.  If you omit the version-prefix, the current version of the API (v1.39) is used. For example, calling `/info` is the same as calling `/v1.39/info`. Using the API without a version-prefix is deprecated and will be removed in a future release.  Engine releases in the near future should support this version of the API, so your client will continue to work even if it is talking to a newer Engine.  The API uses an open schema model, which means server may add extra properties to responses. Likewise, the server will ignore any extra query parameters and request body properties. When you write clients, you need to ignore additional properties in responses to ensure they do not break when talking to newer daemons.   # Authentication  Authentication for registries is handled client side. The client has to send authentication details to various endpoints that need to communicate with registries, such as `POST /images/(name)/push`. These are sent as `X-Registry-Auth` header as a Base64 encoded (JSON) string with the following structure:  ``` {   \"username\": \"string\",   \"password\": \"string\",   \"email\": \"string\",   \"serveraddress\": \"string\" } ```  The `serveraddress` is a domain/IP without a protocol. Throughout this structure, double quotes are required.  If you have already got an identity token from the [`/auth` endpoint](#operation/SystemAuth), you can just pass this instead of credentials:  ``` {   \"identitytoken\": \"9cbaf023786cd7...\" } ``` 
 *
 */
@Path("/")
@Api(value = "/", description = "")
public interface ContainerApi  {

    /**
     * Get an archive of a filesystem resource in a container
     *
     * Get a tar archive of a resource in the filesystem of container id.
     *
     */
    @GET
    @Path("/containers/{id}/archive")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/x-tar" })
    @ApiOperation(value = "Get an archive of a filesystem resource in a container", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "no error", response = .class),
        @ApiResponse(code = 400, message = "Bad parameter", response = InlineResponse400.class),
        @ApiResponse(code = 404, message = "Container or path does not exist", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public void containerArchive(@PathParam("id") String id, @QueryParam("path")String path);

    /**
     * Get information about files in a container
     *
     * A response header &#x60;X-Docker-Container-Path-Stat&#x60; is return containing a base64 - encoded JSON object with some filesystem header information about the path.
     *
     */
    @HEAD
    @Path("/containers/{id}/archive")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json", "text/plain" })
    @ApiOperation(value = "Get information about files in a container", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "no error", response = .class),
        @ApiResponse(code = 400, message = "Bad parameter", response = InlineResponse400.class),
        @ApiResponse(code = 404, message = "Container or path does not exist", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "Server error", response = ErrorResponse.class) })
    public void containerArchiveInfo(@PathParam("id") String id, @QueryParam("path")String path);

    /**
     * Attach to a container
     *
     * Attach to a container to read its output or send it input. You can attach to the same container multiple times and you can reattach to containers that have been detached.  Either the &#x60;stream&#x60; or &#x60;logs&#x60; parameter must be &#x60;true&#x60; for this endpoint to do anything.  See [the documentation for the &#x60;docker attach&#x60; command](https://docs.docker.com/engine/reference/commandline/attach/) for more details.  ### Hijacking  This endpoint hijacks the HTTP connection to transport &#x60;stdin&#x60;, &#x60;stdout&#x60;, and &#x60;stderr&#x60; on the same socket.  This is the response from the daemon for an attach request:  &#x60;&#x60;&#x60; HTTP/1.1 200 OK Content-Type: application/vnd.docker.raw-stream  [STREAM] &#x60;&#x60;&#x60;  After the headers and two new lines, the TCP connection can now be used for raw, bidirectional communication between the client and server.  To hint potential proxies about connection hijacking, the Docker client can also optionally send connection upgrade headers.  For example, the client sends this request to upgrade the connection:  &#x60;&#x60;&#x60; POST /containers/16253994b7c4/attach?stream&#x3D;1&amp;stdout&#x3D;1 HTTP/1.1 Upgrade: tcp Connection: Upgrade &#x60;&#x60;&#x60;  The Docker daemon will respond with a &#x60;101 UPGRADED&#x60; response, and will similarly follow with the raw stream:  &#x60;&#x60;&#x60; HTTP/1.1 101 UPGRADED Content-Type: application/vnd.docker.raw-stream Connection: Upgrade Upgrade: tcp  [STREAM] &#x60;&#x60;&#x60;  ### Stream format  When the TTY setting is disabled in [&#x60;POST /containers/create&#x60;](#operation/ContainerCreate), the stream over the hijacked connected is multiplexed to separate out &#x60;stdout&#x60; and &#x60;stderr&#x60;. The stream consists of a series of frames, each containing a header and a payload.  The header contains the information which the stream writes (&#x60;stdout&#x60; or &#x60;stderr&#x60;). It also contains the size of the associated frame encoded in the last four bytes (&#x60;uint32&#x60;).  It is encoded on the first eight bytes like this:  &#x60;&#x60;&#x60;go header :&#x3D; [8]byte{STREAM_TYPE, 0, 0, 0, SIZE1, SIZE2, SIZE3, SIZE4} &#x60;&#x60;&#x60;  &#x60;STREAM_TYPE&#x60; can be:  - 0: &#x60;stdin&#x60; (is written on &#x60;stdout&#x60;) - 1: &#x60;stdout&#x60; - 2: &#x60;stderr&#x60;  &#x60;SIZE1, SIZE2, SIZE3, SIZE4&#x60; are the four bytes of the &#x60;uint32&#x60; size encoded as big endian.  Following the header is the payload, which is the specified number of bytes of &#x60;STREAM_TYPE&#x60;.  The simplest way to implement this protocol is the following:  1. Read 8 bytes. 2. Choose &#x60;stdout&#x60; or &#x60;stderr&#x60; depending on the first byte. 3. Extract the frame size from the last four bytes. 4. Read the extracted size and output it on the correct output. 5. Goto 1.  ### Stream format when using a TTY  When the TTY setting is enabled in [&#x60;POST /containers/create&#x60;](#operation/ContainerCreate), the stream is not multiplexed. The data exchanged over the hijacked connection is simply the raw data from the process PTY and client&#39;s &#x60;stdin&#x60;. 
     *
     */
    @POST
    @Path("/containers/{id}/attach")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/vnd.docker.raw-stream" })
    @ApiOperation(value = "Attach to a container", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 101, message = "no error, hints proxy about hijacking", response = .class),
        @ApiResponse(code = 200, message = "no error, no upgrade header found", response = .class),
        @ApiResponse(code = 400, message = "bad parameter", response = ErrorResponse.class),
        @ApiResponse(code = 404, message = "no such container", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public void containerAttach(@PathParam("id") String id, @QueryParam("detachKeys")String detachKeys, @QueryParam("logs")@DefaultValue("false") Boolean logs, @QueryParam("stream")@DefaultValue("false") Boolean stream, @QueryParam("stdin")@DefaultValue("false") Boolean stdin, @QueryParam("stdout")@DefaultValue("false") Boolean stdout, @QueryParam("stderr")@DefaultValue("false") Boolean stderr);

    /**
     * Attach to a container via a websocket
     *
     */
    @GET
    @Path("/containers/{id}/attach/ws")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json", "text/plain" })
    @ApiOperation(value = "Attach to a container via a websocket", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 101, message = "no error, hints proxy about hijacking", response = .class),
        @ApiResponse(code = 200, message = "no error, no upgrade header found", response = .class),
        @ApiResponse(code = 400, message = "bad parameter", response = ErrorResponse.class),
        @ApiResponse(code = 404, message = "no such container", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public void containerAttachWebsocket(@PathParam("id") String id, @QueryParam("detachKeys")String detachKeys, @QueryParam("logs")@DefaultValue("false") Boolean logs, @QueryParam("stream")@DefaultValue("false") Boolean stream, @QueryParam("stdin")@DefaultValue("false") Boolean stdin, @QueryParam("stdout")@DefaultValue("false") Boolean stdout, @QueryParam("stderr")@DefaultValue("false") Boolean stderr);

    /**
     * Get changes on a container’s filesystem
     *
     * Returns which files in a container&#39;s filesystem have been added, deleted, or modified. The &#x60;Kind&#x60; of modification can be one of:  - &#x60;0&#x60;: Modified - &#x60;1&#x60;: Added - &#x60;2&#x60;: Deleted 
     *
     */
    @GET
    @Path("/containers/{id}/changes")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Get changes on a container’s filesystem", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "The list of changes", response = Object.class, responseContainer = "array"),
        @ApiResponse(code = 404, message = "no such container", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public List<Object> containerChanges(@PathParam("id") String id);

    /**
     * Create a container
     *
     */
    @POST
    @Path("/containers/create")
    @Consumes({ "application/json", "application/octet-stream" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Create a container", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 201, message = "Container created successfully", response = ContainerCreateResponse.class),
        @ApiResponse(code = 400, message = "bad parameter", response = ErrorResponse.class),
        @ApiResponse(code = 404, message = "no such container", response = ErrorResponse.class),
        @ApiResponse(code = 409, message = "conflict", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public ContainerCreateResponse containerCreate( body, @QueryParam("name")String name);

    /**
     * Remove a container
     *
     */
    @DELETE
    @Path("/containers/{id}")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json", "text/plain" })
    @ApiOperation(value = "Remove a container", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 204, message = "no error", response = .class),
        @ApiResponse(code = 400, message = "bad parameter", response = ErrorResponse.class),
        @ApiResponse(code = 404, message = "no such container", response = ErrorResponse.class),
        @ApiResponse(code = 409, message = "conflict", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public void containerDelete(@PathParam("id") String id, @QueryParam("v")@DefaultValue("false") Boolean v, @QueryParam("force")@DefaultValue("false") Boolean force, @QueryParam("link")@DefaultValue("false") Boolean link);

    /**
     * Export a container
     *
     * Export the contents of a container as a tarball.
     *
     */
    @GET
    @Path("/containers/{id}/export")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/octet-stream" })
    @ApiOperation(value = "Export a container", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "no error", response = .class),
        @ApiResponse(code = 404, message = "no such container", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public void containerExport(@PathParam("id") String id);

    /**
     * Inspect a container
     *
     * Return low-level information about a container.
     *
     */
    @GET
    @Path("/containers/{id}/json")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Inspect a container", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "no error", response = ContainerInspectResponse.class),
        @ApiResponse(code = 404, message = "no such container", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public ContainerInspectResponse containerInspect(@PathParam("id") String id, @QueryParam("size")@DefaultValue("false") Boolean size);

    /**
     * Kill a container
     *
     * Send a POSIX signal to a container, defaulting to killing to the container.
     *
     */
    @POST
    @Path("/containers/{id}/kill")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json", "text/plain" })
    @ApiOperation(value = "Kill a container", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 204, message = "no error", response = .class),
        @ApiResponse(code = 404, message = "no such container", response = ErrorResponse.class),
        @ApiResponse(code = 409, message = "container is not running", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public void containerKill(@PathParam("id") String id, @QueryParam("signal")@DefaultValue("SIGKILL") String signal);

    /**
     * List containers
     *
     * Returns a list of containers. For details on the format, see [the inspect endpoint](#operation/ContainerInspect).  Note that it uses a different, smaller representation of a container than inspecting a single container. For example, the list of linked containers is not propagated . 
     *
     */
    @GET
    @Path("/containers/json")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json" })
    @ApiOperation(value = "List containers", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "no error", response = ContainerSummary.class),
        @ApiResponse(code = 400, message = "bad parameter", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public ContainerSummary containerList(@QueryParam("all")@DefaultValue("false") Boolean all, @QueryParam("limit")Integer limit, @QueryParam("size")@DefaultValue("false") Boolean size, @QueryParam("filters")String filters);

    /**
     * Get container logs
     *
     * Get &#x60;stdout&#x60; and &#x60;stderr&#x60; logs from a container.  Note: This endpoint works only for containers with the &#x60;json-file&#x60; or &#x60;journald&#x60; logging driver. 
     *
     */
    @GET
    @Path("/containers/{id}/logs")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json", "text/plain" })
    @ApiOperation(value = "Get container logs", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 101, message = "logs returned as a stream", response = byte[].class),
        @ApiResponse(code = 200, message = "logs returned as a string in response body", response = String.class),
        @ApiResponse(code = 404, message = "no such container", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public String containerLogs(@PathParam("id") String id, @QueryParam("follow")@DefaultValue("false") Boolean follow, @QueryParam("stdout")@DefaultValue("false") Boolean stdout, @QueryParam("stderr")@DefaultValue("false") Boolean stderr, @QueryParam("since")@DefaultValue("0") Integer since, @QueryParam("until")@DefaultValue("0") Integer until, @QueryParam("timestamps")@DefaultValue("false") Boolean timestamps, @QueryParam("tail")@DefaultValue("all") String tail);

    /**
     * Pause a container
     *
     * Use the cgroups freezer to suspend all processes in a container.  Traditionally, when suspending a process the &#x60;SIGSTOP&#x60; signal is used, which is observable by the process being suspended. With the cgroups freezer the process is unaware, and unable to capture, that it is being suspended, and subsequently resumed. 
     *
     */
    @POST
    @Path("/containers/{id}/pause")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json", "text/plain" })
    @ApiOperation(value = "Pause a container", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 204, message = "no error", response = .class),
        @ApiResponse(code = 404, message = "no such container", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public void containerPause(@PathParam("id") String id);

    /**
     * Delete stopped containers
     *
     */
    @POST
    @Path("/containers/prune")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Delete stopped containers", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "No error", response = ContainerPruneResponse.class),
        @ApiResponse(code = 500, message = "Server error", response = ErrorResponse.class) })
    public ContainerPruneResponse containerPrune(@QueryParam("filters")String filters);

    /**
     * Rename a container
     *
     */
    @POST
    @Path("/containers/{id}/rename")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json", "text/plain" })
    @ApiOperation(value = "Rename a container", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 204, message = "no error", response = .class),
        @ApiResponse(code = 404, message = "no such container", response = ErrorResponse.class),
        @ApiResponse(code = 409, message = "name already in use", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public void containerRename(@PathParam("id") String id, @QueryParam("name")String name);

    /**
     * Resize a container TTY
     *
     * Resize the TTY for a container. You must restart the container for the resize to take effect.
     *
     */
    @POST
    @Path("/containers/{id}/resize")
    @Consumes({ "application/octet-stream" })
    @Produces({ "text/plain" })
    @ApiOperation(value = "Resize a container TTY", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "no error", response = .class),
        @ApiResponse(code = 404, message = "no such container", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "cannot resize container", response = ErrorResponse.class) })
    public void containerResize(@PathParam("id") String id, @QueryParam("h")Integer h, @QueryParam("w")Integer w);

    /**
     * Restart a container
     *
     */
    @POST
    @Path("/containers/{id}/restart")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json", "text/plain" })
    @ApiOperation(value = "Restart a container", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 204, message = "no error", response = .class),
        @ApiResponse(code = 404, message = "no such container", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public void containerRestart(@PathParam("id") String id, @QueryParam("t")Integer t);

    /**
     * Start a container
     *
     */
    @POST
    @Path("/containers/{id}/start")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json", "text/plain" })
    @ApiOperation(value = "Start a container", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 204, message = "no error", response = .class),
        @ApiResponse(code = 304, message = "container already started", response = ErrorResponse.class),
        @ApiResponse(code = 404, message = "no such container", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public void containerStart(@PathParam("id") String id, @QueryParam("detachKeys")String detachKeys);

    /**
     * Get container stats based on resource usage
     *
     * This endpoint returns a live stream of a container’s resource usage statistics.  The &#x60;precpu_stats&#x60; is the CPU statistic of the *previous* read, and is used to calculate the CPU usage percentage. It is not an exact copy of the &#x60;cpu_stats&#x60; field.  If either &#x60;precpu_stats.online_cpus&#x60; or &#x60;cpu_stats.online_cpus&#x60; is nil then for compatibility with older daemons the length of the corresponding &#x60;cpu_usage.percpu_usage&#x60; array should be used. 
     *
     */
    @GET
    @Path("/containers/{id}/stats")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Get container stats based on resource usage", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "no error", response = Object.class),
        @ApiResponse(code = 404, message = "no such container", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public Object containerStats(@PathParam("id") String id, @QueryParam("stream")@DefaultValue("true") Boolean stream);

    /**
     * Stop a container
     *
     */
    @POST
    @Path("/containers/{id}/stop")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json", "text/plain" })
    @ApiOperation(value = "Stop a container", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 204, message = "no error", response = .class),
        @ApiResponse(code = 304, message = "container already stopped", response = ErrorResponse.class),
        @ApiResponse(code = 404, message = "no such container", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public void containerStop(@PathParam("id") String id, @QueryParam("t")Integer t);

    /**
     * List processes running inside a container
     *
     * On Unix systems, this is done by running the &#x60;ps&#x60; command. This endpoint is not supported on Windows.
     *
     */
    @GET
    @Path("/containers/{id}/top")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json", "text/plain" })
    @ApiOperation(value = "List processes running inside a container", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "no error", response = ContainerTopResponse.class),
        @ApiResponse(code = 404, message = "no such container", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public ContainerTopResponse containerTop(@PathParam("id") String id, @QueryParam("ps_args")@DefaultValue("-ef") String psArgs);

    /**
     * Unpause a container
     *
     * Resume a container which has been paused.
     *
     */
    @POST
    @Path("/containers/{id}/unpause")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json", "text/plain" })
    @ApiOperation(value = "Unpause a container", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 204, message = "no error", response = .class),
        @ApiResponse(code = 404, message = "no such container", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public void containerUnpause(@PathParam("id") String id);

    /**
     * Update a container
     *
     * Change various configuration options of a container without having to recreate it.
     *
     */
    @POST
    @Path("/containers/{id}/update")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Update a container", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "The container has been updated.", response = ContainerUpdateResponse.class),
        @ApiResponse(code = 404, message = "no such container", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public ContainerUpdateResponse containerUpdate(@PathParam("id") String id,  update);

    /**
     * Wait for a container
     *
     * Block until a container stops, then returns the exit code.
     *
     */
    @POST
    @Path("/containers/{id}/wait")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Wait for a container", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "The container has exit.", response = ContainerWaitResponse.class),
        @ApiResponse(code = 404, message = "no such container", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public ContainerWaitResponse containerWait(@PathParam("id") String id, @QueryParam("condition")@DefaultValue("not-running") String condition);

    /**
     * Extract an archive of files or folders to a directory in a container
     *
     * Upload a tar archive to be extracted to a path in the filesystem of container id.
     *
     */
    @PUT
    @Path("/containers/{id}/archive")
    @Consumes({ "application/x-tar", "application/octet-stream" })
    @Produces({ "application/json", "text/plain" })
    @ApiOperation(value = "Extract an archive of files or folders to a directory in a container", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "The content was extracted successfully", response = .class),
        @ApiResponse(code = 400, message = "Bad parameter", response = ErrorResponse.class),
        @ApiResponse(code = 403, message = "Permission denied, the volume or container rootfs is marked as read-only.", response = ErrorResponse.class),
        @ApiResponse(code = 404, message = "No such container or path does not exist inside the container", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "Server error", response = ErrorResponse.class) })
    public void putContainerArchive(@PathParam("id") String id, @QueryParam("path")String path, String inputStream, @QueryParam("noOverwriteDirNonDir")String noOverwriteDirNonDir);
}

