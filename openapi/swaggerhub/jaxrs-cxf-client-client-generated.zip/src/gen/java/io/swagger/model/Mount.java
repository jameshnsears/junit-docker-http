package io.swagger.model;

import io.swagger.model.MountBindOptions;
import io.swagger.model.MountTmpfsOptions;
import io.swagger.model.MountVolumeOptions;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Mount  {
  
  @ApiModelProperty(value = "Container path.")
 /**
   * Container path.  
  **/
  private String target = null;

  @ApiModelProperty(value = "Mount source (e.g. a volume name, a host path).")
 /**
   * Mount source (e.g. a volume name, a host path).  
  **/
  private String source = null;


@XmlType(name="TypeEnum")
@XmlEnum(String.class)
public enum TypeEnum {

@XmlEnumValue("bind") BIND(String.valueOf("bind")), @XmlEnumValue("volume") VOLUME(String.valueOf("volume")), @XmlEnumValue("tmpfs") TMPFS(String.valueOf("tmpfs"));


    private String value;

    TypeEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static TypeEnum fromValue(String v) {
        for (TypeEnum b : TypeEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(value = "The mount type. Available types:  - `bind` Mounts a file or directory from the host into the container. Must exist prior to creating the container. - `volume` Creates a volume with the given name and options (or uses a pre-existing volume with the same name and options). These are **not** removed when the container is removed. - `tmpfs` Create a tmpfs with the given options. The mount source cannot be specified for tmpfs. ")
 /**
   * The mount type. Available types:  - `bind` Mounts a file or directory from the host into the container. Must exist prior to creating the container. - `volume` Creates a volume with the given name and options (or uses a pre-existing volume with the same name and options). These are **not** removed when the container is removed. - `tmpfs` Create a tmpfs with the given options. The mount source cannot be specified for tmpfs.   
  **/
  private TypeEnum type = null;

  @ApiModelProperty(value = "Whether the mount should be read-only.")
 /**
   * Whether the mount should be read-only.  
  **/
  private Boolean readOnly = null;

  @ApiModelProperty(value = "The consistency requirement for the mount: `default`, `consistent`, `cached`, or `delegated`.")
 /**
   * The consistency requirement for the mount: `default`, `consistent`, `cached`, or `delegated`.  
  **/
  private String consistency = null;

  @ApiModelProperty(value = "")
  private MountBindOptions bindOptions = null;

  @ApiModelProperty(value = "")
  private MountVolumeOptions volumeOptions = null;

  @ApiModelProperty(value = "")
  private MountTmpfsOptions tmpfsOptions = null;
 /**
   * Container path.
   * @return target
  **/
  @JsonProperty("Target")
  public String getTarget() {
    return target;
  }

  public void setTarget(String target) {
    this.target = target;
  }

  public Mount target(String target) {
    this.target = target;
    return this;
  }

 /**
   * Mount source (e.g. a volume name, a host path).
   * @return source
  **/
  @JsonProperty("Source")
  public String getSource() {
    return source;
  }

  public void setSource(String source) {
    this.source = source;
  }

  public Mount source(String source) {
    this.source = source;
    return this;
  }

 /**
   * The mount type. Available types:  - &#x60;bind&#x60; Mounts a file or directory from the host into the container. Must exist prior to creating the container. - &#x60;volume&#x60; Creates a volume with the given name and options (or uses a pre-existing volume with the same name and options). These are **not** removed when the container is removed. - &#x60;tmpfs&#x60; Create a tmpfs with the given options. The mount source cannot be specified for tmpfs. 
   * @return type
  **/
  @JsonProperty("Type")
  public String getType() {
    if (type == null) {
      return null;
    }
    return type.value();
  }

  public void setType(TypeEnum type) {
    this.type = type;
  }

  public Mount type(TypeEnum type) {
    this.type = type;
    return this;
  }

 /**
   * Whether the mount should be read-only.
   * @return readOnly
  **/
  @JsonProperty("ReadOnly")
  public Boolean isReadOnly() {
    return readOnly;
  }

  public void setReadOnly(Boolean readOnly) {
    this.readOnly = readOnly;
  }

  public Mount readOnly(Boolean readOnly) {
    this.readOnly = readOnly;
    return this;
  }

 /**
   * The consistency requirement for the mount: &#x60;default&#x60;, &#x60;consistent&#x60;, &#x60;cached&#x60;, or &#x60;delegated&#x60;.
   * @return consistency
  **/
  @JsonProperty("Consistency")
  public String getConsistency() {
    return consistency;
  }

  public void setConsistency(String consistency) {
    this.consistency = consistency;
  }

  public Mount consistency(String consistency) {
    this.consistency = consistency;
    return this;
  }

 /**
   * Get bindOptions
   * @return bindOptions
  **/
  @JsonProperty("BindOptions")
  public MountBindOptions getBindOptions() {
    return bindOptions;
  }

  public void setBindOptions(MountBindOptions bindOptions) {
    this.bindOptions = bindOptions;
  }

  public Mount bindOptions(MountBindOptions bindOptions) {
    this.bindOptions = bindOptions;
    return this;
  }

 /**
   * Get volumeOptions
   * @return volumeOptions
  **/
  @JsonProperty("VolumeOptions")
  public MountVolumeOptions getVolumeOptions() {
    return volumeOptions;
  }

  public void setVolumeOptions(MountVolumeOptions volumeOptions) {
    this.volumeOptions = volumeOptions;
  }

  public Mount volumeOptions(MountVolumeOptions volumeOptions) {
    this.volumeOptions = volumeOptions;
    return this;
  }

 /**
   * Get tmpfsOptions
   * @return tmpfsOptions
  **/
  @JsonProperty("TmpfsOptions")
  public MountTmpfsOptions getTmpfsOptions() {
    return tmpfsOptions;
  }

  public void setTmpfsOptions(MountTmpfsOptions tmpfsOptions) {
    this.tmpfsOptions = tmpfsOptions;
  }

  public Mount tmpfsOptions(MountTmpfsOptions tmpfsOptions) {
    this.tmpfsOptions = tmpfsOptions;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Mount {\n");
    
    sb.append("    target: ").append(toIndentedString(target)).append("\n");
    sb.append("    source: ").append(toIndentedString(source)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    readOnly: ").append(toIndentedString(readOnly)).append("\n");
    sb.append("    consistency: ").append(toIndentedString(consistency)).append("\n");
    sb.append("    bindOptions: ").append(toIndentedString(bindOptions)).append("\n");
    sb.append("    volumeOptions: ").append(toIndentedString(volumeOptions)).append("\n");
    sb.append("    tmpfsOptions: ").append(toIndentedString(tmpfsOptions)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

