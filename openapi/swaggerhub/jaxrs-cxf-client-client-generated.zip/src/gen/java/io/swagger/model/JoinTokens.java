package io.swagger.model;

import io.swagger.annotations.ApiModel;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * JoinTokens contains the tokens workers and managers need to join the swarm. 
 **/
@ApiModel(description="JoinTokens contains the tokens workers and managers need to join the swarm. ")
public class JoinTokens  {
  
  @ApiModelProperty(example = "SWMTKN-1-3pu6hszjas19xyp7ghgosyx9k8atbfcr8p2is99znpy26u2lkl-1awxwuwd3z9j1z3puu7rcgdbx", value = "The token workers can use to join the swarm. ")
 /**
   * The token workers can use to join the swarm.   
  **/
  private String worker = null;

  @ApiModelProperty(example = "SWMTKN-1-3pu6hszjas19xyp7ghgosyx9k8atbfcr8p2is99znpy26u2lkl-7p73s1dx5in4tatdymyhg9hu2", value = "The token managers can use to join the swarm. ")
 /**
   * The token managers can use to join the swarm.   
  **/
  private String manager = null;
 /**
   * The token workers can use to join the swarm. 
   * @return worker
  **/
  @JsonProperty("Worker")
  public String getWorker() {
    return worker;
  }

  public void setWorker(String worker) {
    this.worker = worker;
  }

  public JoinTokens worker(String worker) {
    this.worker = worker;
    return this;
  }

 /**
   * The token managers can use to join the swarm. 
   * @return manager
  **/
  @JsonProperty("Manager")
  public String getManager() {
    return manager;
  }

  public void setManager(String manager) {
    this.manager = manager;
  }

  public JoinTokens manager(String manager) {
    this.manager = manager;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class JoinTokens {\n");
    
    sb.append("    worker: ").append(toIndentedString(worker)).append("\n");
    sb.append("    manager: ").append(toIndentedString(manager)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

