package io.swagger.model;

import io.swagger.annotations.ApiModel;


/**
 * Reachability represents the reachability of a node.
 */
public enum Reachability {
  
  UNKNOWN("unknown"),
  
  UNREACHABLE("unreachable"),
  
  REACHABLE("reachable");

  private String value;

  Reachability(String value) {
    this.value = value;
  }

  @Override
  public String toString() {
    return String.valueOf(value);
  }

  public static Reachability fromValue(String text) {
    for (Reachability b : Reachability.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
  
}

