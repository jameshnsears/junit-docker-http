package io.swagger.model;

import io.swagger.model.IPAM;
import io.swagger.model.NetworkContainer;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Network  {
  
  @ApiModelProperty(value = "")
  private String name = null;

  @ApiModelProperty(value = "")
  private String id = null;

  @ApiModelProperty(value = "")
  private String created = null;

  @ApiModelProperty(value = "")
  private String scope = null;

  @ApiModelProperty(value = "")
  private String driver = null;

  @ApiModelProperty(value = "")
  private Boolean enableIPv6 = null;

  @ApiModelProperty(value = "")
  private IPAM IPAM = null;

  @ApiModelProperty(value = "")
  private Boolean internal = null;

  @ApiModelProperty(value = "")
  private Boolean attachable = null;

  @ApiModelProperty(value = "")
  private Boolean ingress = null;

  @ApiModelProperty(value = "")
  private Map<String, NetworkContainer> containers = null;

  @ApiModelProperty(value = "")
  private Map<String, String> options = null;

  @ApiModelProperty(value = "")
  private Map<String, String> labels = null;
 /**
   * Get name
   * @return name
  **/
  @JsonProperty("Name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Network name(String name) {
    this.name = name;
    return this;
  }

 /**
   * Get id
   * @return id
  **/
  @JsonProperty("Id")
  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public Network id(String id) {
    this.id = id;
    return this;
  }

 /**
   * Get created
   * @return created
  **/
  @JsonProperty("Created")
  public String getCreated() {
    return created;
  }

  public void setCreated(String created) {
    this.created = created;
  }

  public Network created(String created) {
    this.created = created;
    return this;
  }

 /**
   * Get scope
   * @return scope
  **/
  @JsonProperty("Scope")
  public String getScope() {
    return scope;
  }

  public void setScope(String scope) {
    this.scope = scope;
  }

  public Network scope(String scope) {
    this.scope = scope;
    return this;
  }

 /**
   * Get driver
   * @return driver
  **/
  @JsonProperty("Driver")
  public String getDriver() {
    return driver;
  }

  public void setDriver(String driver) {
    this.driver = driver;
  }

  public Network driver(String driver) {
    this.driver = driver;
    return this;
  }

 /**
   * Get enableIPv6
   * @return enableIPv6
  **/
  @JsonProperty("EnableIPv6")
  public Boolean isEnableIPv6() {
    return enableIPv6;
  }

  public void setEnableIPv6(Boolean enableIPv6) {
    this.enableIPv6 = enableIPv6;
  }

  public Network enableIPv6(Boolean enableIPv6) {
    this.enableIPv6 = enableIPv6;
    return this;
  }

 /**
   * Get IPAM
   * @return IPAM
  **/
  @JsonProperty("IPAM")
  public IPAM getIPAM() {
    return IPAM;
  }

  public void setIPAM(IPAM IPAM) {
    this.IPAM = IPAM;
  }

  public Network IPAM(IPAM IPAM) {
    this.IPAM = IPAM;
    return this;
  }

 /**
   * Get internal
   * @return internal
  **/
  @JsonProperty("Internal")
  public Boolean isInternal() {
    return internal;
  }

  public void setInternal(Boolean internal) {
    this.internal = internal;
  }

  public Network internal(Boolean internal) {
    this.internal = internal;
    return this;
  }

 /**
   * Get attachable
   * @return attachable
  **/
  @JsonProperty("Attachable")
  public Boolean isAttachable() {
    return attachable;
  }

  public void setAttachable(Boolean attachable) {
    this.attachable = attachable;
  }

  public Network attachable(Boolean attachable) {
    this.attachable = attachable;
    return this;
  }

 /**
   * Get ingress
   * @return ingress
  **/
  @JsonProperty("Ingress")
  public Boolean isIngress() {
    return ingress;
  }

  public void setIngress(Boolean ingress) {
    this.ingress = ingress;
  }

  public Network ingress(Boolean ingress) {
    this.ingress = ingress;
    return this;
  }

 /**
   * Get containers
   * @return containers
  **/
  @JsonProperty("Containers")
  public Map<String, NetworkContainer> getContainers() {
    return containers;
  }

  public void setContainers(Map<String, NetworkContainer> containers) {
    this.containers = containers;
  }

  public Network containers(Map<String, NetworkContainer> containers) {
    this.containers = containers;
    return this;
  }

  public Network putContainersItem(String key, NetworkContainer containersItem) {
    this.containers.put(key, containersItem);
    return this;
  }

 /**
   * Get options
   * @return options
  **/
  @JsonProperty("Options")
  public Map<String, String> getOptions() {
    return options;
  }

  public void setOptions(Map<String, String> options) {
    this.options = options;
  }

  public Network options(Map<String, String> options) {
    this.options = options;
    return this;
  }

  public Network putOptionsItem(String key, String optionsItem) {
    this.options.put(key, optionsItem);
    return this;
  }

 /**
   * Get labels
   * @return labels
  **/
  @JsonProperty("Labels")
  public Map<String, String> getLabels() {
    return labels;
  }

  public void setLabels(Map<String, String> labels) {
    this.labels = labels;
  }

  public Network labels(Map<String, String> labels) {
    this.labels = labels;
    return this;
  }

  public Network putLabelsItem(String key, String labelsItem) {
    this.labels.put(key, labelsItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Network {\n");
    
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    created: ").append(toIndentedString(created)).append("\n");
    sb.append("    scope: ").append(toIndentedString(scope)).append("\n");
    sb.append("    driver: ").append(toIndentedString(driver)).append("\n");
    sb.append("    enableIPv6: ").append(toIndentedString(enableIPv6)).append("\n");
    sb.append("    IPAM: ").append(toIndentedString(IPAM)).append("\n");
    sb.append("    internal: ").append(toIndentedString(internal)).append("\n");
    sb.append("    attachable: ").append(toIndentedString(attachable)).append("\n");
    sb.append("    ingress: ").append(toIndentedString(ingress)).append("\n");
    sb.append("    containers: ").append(toIndentedString(containers)).append("\n");
    sb.append("    options: ").append(toIndentedString(options)).append("\n");
    sb.append("    labels: ").append(toIndentedString(labels)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

