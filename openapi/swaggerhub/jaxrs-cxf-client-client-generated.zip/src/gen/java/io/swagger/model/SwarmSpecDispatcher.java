package io.swagger.model;

import io.swagger.annotations.ApiModel;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * Dispatcher configuration.
 **/
@ApiModel(description="Dispatcher configuration.")
public class SwarmSpecDispatcher  {
  
  @ApiModelProperty(example = "5000000000", value = "The delay for an agent to send a heartbeat to the dispatcher.")
 /**
   * The delay for an agent to send a heartbeat to the dispatcher.  
  **/
  private Long heartbeatPeriod = null;
 /**
   * The delay for an agent to send a heartbeat to the dispatcher.
   * @return heartbeatPeriod
  **/
  @JsonProperty("HeartbeatPeriod")
  public Long getHeartbeatPeriod() {
    return heartbeatPeriod;
  }

  public void setHeartbeatPeriod(Long heartbeatPeriod) {
    this.heartbeatPeriod = heartbeatPeriod;
  }

  public SwarmSpecDispatcher heartbeatPeriod(Long heartbeatPeriod) {
    this.heartbeatPeriod = heartbeatPeriod;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SwarmSpecDispatcher {\n");
    
    sb.append("    heartbeatPeriod: ").append(toIndentedString(heartbeatPeriod)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

