package io.swagger.model;

import io.swagger.annotations.ApiModel;


/**
 * Current local status of this node.
 */
public enum LocalNodeState {
  
  EMPTY(""),
  
  INACTIVE("inactive"),
  
  PENDING("pending"),
  
  ACTIVE("active"),
  
  ERROR("error"),
  
  LOCKED("locked");

  private String value;

  LocalNodeState(String value) {
    this.value = value;
  }

  @Override
  public String toString() {
    return String.valueOf(value);
  }

  public static LocalNodeState fromValue(String text) {
    for (LocalNodeState b : LocalNodeState.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
  
}

