package io.swagger.api;

import io.swagger.model.Body;
import io.swagger.model.ErrorResponse;
import io.swagger.model.Plugin;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import org.apache.cxf.jaxrs.ext.multipart.*;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.ApiResponse;
import io.swagger.jaxrs.PATCH;

/**
 * Docker Engine API
 *
 * <p>The Engine API is an HTTP API served by Docker Engine. It is the API the Docker client uses to communicate with the Engine, so everything the Docker client can do can be done with the API.  Most of the client's commands map directly to API endpoints (e.g. `docker ps` is `GET /containers/json`). The notable exception is running containers, which consists of several API calls.  # Errors  The API uses standard HTTP status codes to indicate the success or failure of the API call. The body of the response will be JSON in the following format:  ``` {   \"message\": \"page not found\" } ```  # Versioning  The API is usually changed in each release, so API calls are versioned to ensure that clients don't break. To lock to a specific version of the API, you prefix the URL with its version, for example, call `/v1.30/info` to use the v1.30 version of the `/info` endpoint. If the API version specified in the URL is not supported by the daemon, a HTTP `400 Bad Request` error message is returned.  If you omit the version-prefix, the current version of the API (v1.39) is used. For example, calling `/info` is the same as calling `/v1.39/info`. Using the API without a version-prefix is deprecated and will be removed in a future release.  Engine releases in the near future should support this version of the API, so your client will continue to work even if it is talking to a newer Engine.  The API uses an open schema model, which means server may add extra properties to responses. Likewise, the server will ignore any extra query parameters and request body properties. When you write clients, you need to ignore additional properties in responses to ensure they do not break when talking to newer daemons.   # Authentication  Authentication for registries is handled client side. The client has to send authentication details to various endpoints that need to communicate with registries, such as `POST /images/(name)/push`. These are sent as `X-Registry-Auth` header as a Base64 encoded (JSON) string with the following structure:  ``` {   \"username\": \"string\",   \"password\": \"string\",   \"email\": \"string\",   \"serveraddress\": \"string\" } ```  The `serveraddress` is a domain/IP without a protocol. Throughout this structure, double quotes are required.  If you have already got an identity token from the [`/auth` endpoint](#operation/SystemAuth), you can just pass this instead of credentials:  ``` {   \"identitytoken\": \"9cbaf023786cd7...\" } ``` 
 *
 */
@Path("/")
@Api(value = "/", description = "")
public interface PluginApi  {

    /**
     * Get plugin privileges
     *
     */
    @GET
    @Path("/plugins/privileges")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json", "text/plain" })
    @ApiOperation(value = "Get plugin privileges", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "no error", response = Object.class, responseContainer = "array"),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public List<Object> getPluginPrivileges(@QueryParam("remote")String remote);

    /**
     * Create a plugin
     *
     */
    @POST
    @Path("/plugins/create")
    @Consumes({ "application/x-tar" })
    @Produces({ "application/json", "text/plain" })
    @ApiOperation(value = "Create a plugin", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 204, message = "no error", response = .class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public void pluginCreate(@QueryParam("name")String name, byte[] tarContext);

    /**
     * Remove a plugin
     *
     */
    @DELETE
    @Path("/plugins/{name}")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json", "text/plain" })
    @ApiOperation(value = "Remove a plugin", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "no error", response = Plugin.class),
        @ApiResponse(code = 404, message = "plugin is not installed", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public Plugin pluginDelete(@PathParam("name") String name, @QueryParam("force")@DefaultValue("false") Boolean force);

    /**
     * Disable a plugin
     *
     */
    @POST
    @Path("/plugins/{name}/disable")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json", "text/plain" })
    @ApiOperation(value = "Disable a plugin", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "no error", response = .class),
        @ApiResponse(code = 404, message = "plugin is not installed", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public void pluginDisable(@PathParam("name") String name);

    /**
     * Enable a plugin
     *
     */
    @POST
    @Path("/plugins/{name}/enable")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json", "text/plain" })
    @ApiOperation(value = "Enable a plugin", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "no error", response = .class),
        @ApiResponse(code = 404, message = "plugin is not installed", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public void pluginEnable(@PathParam("name") String name, @QueryParam("timeout")@DefaultValue("0") Integer timeout);

    /**
     * Inspect a plugin
     *
     */
    @GET
    @Path("/plugins/{name}/json")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json", "text/plain" })
    @ApiOperation(value = "Inspect a plugin", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "no error", response = Plugin.class),
        @ApiResponse(code = 404, message = "plugin is not installed", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public Plugin pluginInspect(@PathParam("name") String name);

    /**
     * List plugins
     *
     * Returns information about installed plugins.
     *
     */
    @GET
    @Path("/plugins")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json" })
    @ApiOperation(value = "List plugins", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "No error", response = Plugin.class, responseContainer = "array"),
        @ApiResponse(code = 500, message = "Server error", response = ErrorResponse.class) })
    public List<Plugin> pluginList(@QueryParam("filters")String filters);

    /**
     * Install a plugin
     *
     * Pulls and installs a plugin. After the plugin is installed, it can be enabled using the [&#x60;POST /plugins/{name}/enable&#x60; endpoint](#operation/PostPluginsEnable). 
     *
     */
    @POST
    @Path("/plugins/pull")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Install a plugin", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 204, message = "no error", response = .class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public void pluginPull(@QueryParam("remote")String remote, @QueryParam("name")String name, @HeaderParam("X-Registry-Auth") String xRegistryAuth, List<Body> body);

    /**
     * Push a plugin
     *
     * Push a plugin to the registry. 
     *
     */
    @POST
    @Path("/plugins/{name}/push")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json", "text/plain" })
    @ApiOperation(value = "Push a plugin", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "no error", response = .class),
        @ApiResponse(code = 404, message = "plugin not installed", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public void pluginPush(@PathParam("name") String name);

    /**
     * Configure a plugin
     *
     */
    @POST
    @Path("/plugins/{name}/set")
    @Consumes({ "application/json" })
    @Produces({ "application/json", "text/plain" })
    @ApiOperation(value = "Configure a plugin", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 204, message = "No error", response = .class),
        @ApiResponse(code = 404, message = "Plugin not installed", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "Server error", response = ErrorResponse.class) })
    public void pluginSet(@PathParam("name") String name, List<String> body);

    /**
     * Upgrade a plugin
     *
     */
    @POST
    @Path("/plugins/{name}/upgrade")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json", "text/plain" })
    @ApiOperation(value = "Upgrade a plugin", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 204, message = "no error", response = .class),
        @ApiResponse(code = 404, message = "plugin not installed", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public void pluginUpgrade(@PathParam("name") String name, @QueryParam("remote")String remote, @HeaderParam("X-Registry-Auth") String xRegistryAuth, List<Body> body);
}

