package io.swagger.model;

import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ContainerPruneResponse  {
  
  @ApiModelProperty(value = "Container IDs that were deleted")
 /**
   * Container IDs that were deleted  
  **/
  private List<String> containersDeleted = null;

  @ApiModelProperty(value = "Disk space reclaimed in bytes")
 /**
   * Disk space reclaimed in bytes  
  **/
  private Long spaceReclaimed = null;
 /**
   * Container IDs that were deleted
   * @return containersDeleted
  **/
  @JsonProperty("ContainersDeleted")
  public List<String> getContainersDeleted() {
    return containersDeleted;
  }

  public void setContainersDeleted(List<String> containersDeleted) {
    this.containersDeleted = containersDeleted;
  }

  public ContainerPruneResponse containersDeleted(List<String> containersDeleted) {
    this.containersDeleted = containersDeleted;
    return this;
  }

  public ContainerPruneResponse addContainersDeletedItem(String containersDeletedItem) {
    this.containersDeleted.add(containersDeletedItem);
    return this;
  }

 /**
   * Disk space reclaimed in bytes
   * @return spaceReclaimed
  **/
  @JsonProperty("SpaceReclaimed")
  public Long getSpaceReclaimed() {
    return spaceReclaimed;
  }

  public void setSpaceReclaimed(Long spaceReclaimed) {
    this.spaceReclaimed = spaceReclaimed;
  }

  public ContainerPruneResponse spaceReclaimed(Long spaceReclaimed) {
    this.spaceReclaimed = spaceReclaimed;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ContainerPruneResponse {\n");
    
    sb.append("    containersDeleted: ").append(toIndentedString(containersDeleted)).append("\n");
    sb.append("    spaceReclaimed: ").append(toIndentedString(spaceReclaimed)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

