package io.swagger.api;

import io.swagger.model.BuildPruneResponse;
import io.swagger.model.ContainerConfig;
import io.swagger.model.ErrorResponse;
import io.swagger.model.IdResponse;
import io.swagger.model.Image;
import io.swagger.model.ImageDeleteResponseItem;
import io.swagger.model.ImagePruneResponse;
import io.swagger.model.ImageSummary;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import org.apache.cxf.jaxrs.ext.multipart.*;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.ApiResponse;
import io.swagger.jaxrs.PATCH;

/**
 * Docker Engine API
 *
 * <p>The Engine API is an HTTP API served by Docker Engine. It is the API the Docker client uses to communicate with the Engine, so everything the Docker client can do can be done with the API.  Most of the client's commands map directly to API endpoints (e.g. `docker ps` is `GET /containers/json`). The notable exception is running containers, which consists of several API calls.  # Errors  The API uses standard HTTP status codes to indicate the success or failure of the API call. The body of the response will be JSON in the following format:  ``` {   \"message\": \"page not found\" } ```  # Versioning  The API is usually changed in each release, so API calls are versioned to ensure that clients don't break. To lock to a specific version of the API, you prefix the URL with its version, for example, call `/v1.30/info` to use the v1.30 version of the `/info` endpoint. If the API version specified in the URL is not supported by the daemon, a HTTP `400 Bad Request` error message is returned.  If you omit the version-prefix, the current version of the API (v1.39) is used. For example, calling `/info` is the same as calling `/v1.39/info`. Using the API without a version-prefix is deprecated and will be removed in a future release.  Engine releases in the near future should support this version of the API, so your client will continue to work even if it is talking to a newer Engine.  The API uses an open schema model, which means server may add extra properties to responses. Likewise, the server will ignore any extra query parameters and request body properties. When you write clients, you need to ignore additional properties in responses to ensure they do not break when talking to newer daemons.   # Authentication  Authentication for registries is handled client side. The client has to send authentication details to various endpoints that need to communicate with registries, such as `POST /images/(name)/push`. These are sent as `X-Registry-Auth` header as a Base64 encoded (JSON) string with the following structure:  ``` {   \"username\": \"string\",   \"password\": \"string\",   \"email\": \"string\",   \"serveraddress\": \"string\" } ```  The `serveraddress` is a domain/IP without a protocol. Throughout this structure, double quotes are required.  If you have already got an identity token from the [`/auth` endpoint](#operation/SystemAuth), you can just pass this instead of credentials:  ``` {   \"identitytoken\": \"9cbaf023786cd7...\" } ``` 
 *
 */
@Path("/")
@Api(value = "/", description = "")
public interface ImageApi  {

    /**
     * Delete builder cache
     *
     */
    @POST
    @Path("/build/prune")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Delete builder cache", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "No error", response = BuildPruneResponse.class),
        @ApiResponse(code = 500, message = "Server error", response = ErrorResponse.class) })
    public BuildPruneResponse buildPrune(@QueryParam("keep-storage")Long keepStorage, @QueryParam("all")Boolean all, @QueryParam("filters")String filters);

    /**
     * Build an image
     *
     * Build an image from a tar archive with a &#x60;Dockerfile&#x60; in it.  The &#x60;Dockerfile&#x60; specifies how the image is built from the tar archive. It is typically in the archive&#39;s root, but can be at a different path or have a different name by specifying the &#x60;dockerfile&#x60; parameter. [See the &#x60;Dockerfile&#x60; reference for more information](https://docs.docker.com/engine/reference/builder/).  The Docker daemon performs a preliminary validation of the &#x60;Dockerfile&#x60; before starting the build, and returns an error if the syntax is incorrect. After that, each instruction is run one-by-one until the ID of the new image is output.  The build is canceled if the client drops the connection by quitting or being killed. 
     *
     */
    @POST
    @Path("/build")
    @Consumes({ "application/octet-stream" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Build an image", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "no error", response = .class),
        @ApiResponse(code = 400, message = "Bad parameter", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public void imageBuild(byte[] inputStream, @QueryParam("dockerfile")@DefaultValue("Dockerfile") String dockerfile, @QueryParam("t")String t, @QueryParam("extrahosts")String extrahosts, @QueryParam("remote")String remote, @QueryParam("q")@DefaultValue("false") Boolean q, @QueryParam("nocache")@DefaultValue("false") Boolean nocache, @QueryParam("cachefrom")String cachefrom, @QueryParam("pull")String pull, @QueryParam("rm")@DefaultValue("true") Boolean rm, @QueryParam("forcerm")@DefaultValue("false") Boolean forcerm, @QueryParam("memory")Integer memory, @QueryParam("memswap")Integer memswap, @QueryParam("cpushares")Integer cpushares, @QueryParam("cpusetcpus")String cpusetcpus, @QueryParam("cpuperiod")Integer cpuperiod, @QueryParam("cpuquota")Integer cpuquota, @QueryParam("buildargs")String buildargs, @QueryParam("shmsize")Integer shmsize, @QueryParam("squash")Boolean squash, @QueryParam("labels")String labels, @QueryParam("networkmode")String networkmode, @HeaderParam("Content-type") String contentType, @HeaderParam("X-Registry-Config") String xRegistryConfig, @QueryParam("platform")@DefaultValue("") String platform, @QueryParam("target")@DefaultValue("") String target);

    /**
     * Create a new image from a container
     *
     */
    @POST
    @Path("/commit")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Create a new image from a container", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 201, message = "no error", response = IdResponse.class),
        @ApiResponse(code = 404, message = "no such container", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public IdResponse imageCommit(ContainerConfig containerConfig, @QueryParam("container")String container, @QueryParam("repo")String repo, @QueryParam("tag")String tag, @QueryParam("comment")String comment, @QueryParam("author")String author, @QueryParam("pause")@DefaultValue("true") Boolean pause, @QueryParam("changes")String changes);

    /**
     * Create an image
     *
     * Create an image by either pulling it from a registry or importing it.
     *
     */
    @POST
    @Path("/images/create")
    @Consumes({ "text/plain", "application/octet-stream" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Create an image", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "no error", response = .class),
        @ApiResponse(code = 404, message = "repository does not exist or no read access", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public void imageCreate(@QueryParam("fromImage")String fromImage, @QueryParam("fromSrc")String fromSrc, @QueryParam("repo")String repo, @QueryParam("tag")String tag, String inputImage, @HeaderParam("X-Registry-Auth") String xRegistryAuth, @QueryParam("platform")@DefaultValue("") String platform);

    /**
     * Remove an image
     *
     * Remove an image, along with any untagged parent images that were referenced by that image.  Images can&#39;t be removed if they have descendant images, are being used by a running container or are being used by a build. 
     *
     */
    @DELETE
    @Path("/images/{name}")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Remove an image", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "The image was deleted successfully", response = ImageDeleteResponseItem.class, responseContainer = "array"),
        @ApiResponse(code = 404, message = "No such image", response = ErrorResponse.class),
        @ApiResponse(code = 409, message = "Conflict", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "Server error", response = ErrorResponse.class) })
    public List<ImageDeleteResponseItem> imageDelete(@PathParam("name") String name, @QueryParam("force")@DefaultValue("false") Boolean force, @QueryParam("noprune")@DefaultValue("false") Boolean noprune);

    /**
     * Export an image
     *
     * Get a tarball containing all images and metadata for a repository.  If &#x60;name&#x60; is a specific name and tag (e.g. &#x60;ubuntu:latest&#x60;), then only that image (and its parents) are returned. If &#x60;name&#x60; is an image ID, similarly only that image (and its parents) are returned, but with the exclusion of the &#x60;repositories&#x60; file in the tarball, as there were no image names referenced.  ### Image tarball format  An image tarball contains one directory per image layer (named using its long ID), each containing these files:  - &#x60;VERSION&#x60;: currently &#x60;1.0&#x60; - the file format version - &#x60;json&#x60;: detailed layer information, similar to &#x60;docker inspect layer_id&#x60; - &#x60;layer.tar&#x60;: A tarfile containing the filesystem changes in this layer  The &#x60;layer.tar&#x60; file contains &#x60;aufs&#x60; style &#x60;.wh..wh.aufs&#x60; files and directories for storing attribute changes and deletions.  If the tarball defines a repository, the tarball should also include a &#x60;repositories&#x60; file at the root that contains a list of repository and tag names mapped to layer IDs.  &#x60;&#x60;&#x60;json {   \&quot;hello-world\&quot;: {     \&quot;latest\&quot;: \&quot;565a9d68a73f6706862bfe8409a7f659776d4d60a8d096eb4a3cbce6999cc2a1\&quot;   } } &#x60;&#x60;&#x60; 
     *
     */
    @GET
    @Path("/images/{name}/get")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/x-tar" })
    @ApiOperation(value = "Export an image", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "no error", response = byte[].class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public byte[] imageGet(@PathParam("name") String name);

    /**
     * Export several images
     *
     * Get a tarball containing all images and metadata for several image repositories.  For each value of the &#x60;names&#x60; parameter: if it is a specific name and tag (e.g. &#x60;ubuntu:latest&#x60;), then only that image (and its parents) are returned; if it is an image ID, similarly only that image (and its parents) are returned and there would be no names referenced in the &#39;repositories&#39; file for this image ID.  For details on the format, see [the export image endpoint](#operation/ImageGet). 
     *
     */
    @GET
    @Path("/images/get")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/x-tar" })
    @ApiOperation(value = "Export several images", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "no error", response = byte[].class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public byte[] imageGetAll(@QueryParam("names")List<String> names);

    /**
     * Get the history of an image
     *
     * Return parent layers of an image.
     *
     */
    @GET
    @Path("/images/{name}/history")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Get the history of an image", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "List of image layers", response = Object.class, responseContainer = "array"),
        @ApiResponse(code = 404, message = "No such image", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "Server error", response = ErrorResponse.class) })
    public List<Object> imageHistory(@PathParam("name") String name);

    /**
     * Inspect an image
     *
     * Return low-level information about an image.
     *
     */
    @GET
    @Path("/images/{name}/json")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Inspect an image", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "No error", response = Image.class),
        @ApiResponse(code = 404, message = "No such image", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "Server error", response = ErrorResponse.class) })
    public Image imageInspect(@PathParam("name") String name);

    /**
     * List Images
     *
     * Returns a list of images on the server. Note that it uses a different, smaller representation of an image than inspecting a single image.
     *
     */
    @GET
    @Path("/images/json")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json" })
    @ApiOperation(value = "List Images", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "Summary image data for the images matching the query", response = ImageSummary.class, responseContainer = "array"),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public List<ImageSummary> imageList(@QueryParam("all")@DefaultValue("false") Boolean all, @QueryParam("filters")String filters, @QueryParam("digests")@DefaultValue("false") Boolean digests);

    /**
     * Import images
     *
     * Load a set of images and tags into a repository.  For details on the format, see [the export image endpoint](#operation/ImageGet). 
     *
     */
    @POST
    @Path("/images/load")
    @Consumes({ "application/x-tar" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Import images", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "no error", response = .class),
        @ApiResponse(code = 500, message = "server error", response = ErrorResponse.class) })
    public void imageLoad(byte[] imagesTarball, @QueryParam("quiet")@DefaultValue("false") Boolean quiet);

    /**
     * Delete unused images
     *
     */
    @POST
    @Path("/images/prune")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Delete unused images", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "No error", response = ImagePruneResponse.class),
        @ApiResponse(code = 500, message = "Server error", response = ErrorResponse.class) })
    public ImagePruneResponse imagePrune(@QueryParam("filters")String filters);

    /**
     * Push an image
     *
     * Push an image to a registry.  If you wish to push an image on to a private registry, that image must already have a tag which references the registry. For example, &#x60;registry.example.com/myimage:latest&#x60;.  The push is cancelled if the HTTP connection is closed. 
     *
     */
    @POST
    @Path("/images/{name}/push")
    @Consumes({ "application/octet-stream" })
    @Produces({ "application/json", "text/plain" })
    @ApiOperation(value = "Push an image", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "No error", response = .class),
        @ApiResponse(code = 404, message = "No such image", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "Server error", response = ErrorResponse.class) })
    public void imagePush(@PathParam("name") String name, @HeaderParam("X-Registry-Auth") String xRegistryAuth, @QueryParam("tag")String tag);

    /**
     * Search images
     *
     * Search for an image on Docker Hub.
     *
     */
    @GET
    @Path("/images/search")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json" })
    @ApiOperation(value = "Search images", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "No error", response = Object.class, responseContainer = "array"),
        @ApiResponse(code = 500, message = "Server error", response = ErrorResponse.class) })
    public List<Object> imageSearch(@QueryParam("term")String term, @QueryParam("limit")Integer limit, @QueryParam("filters")String filters);

    /**
     * Tag an image
     *
     * Tag an image so that it becomes part of a repository.
     *
     */
    @POST
    @Path("/images/{name}/tag")
    @Consumes({ "application/json", "text/plain" })
    @Produces({ "application/json", "text/plain" })
    @ApiOperation(value = "Tag an image", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 201, message = "No error", response = .class),
        @ApiResponse(code = 400, message = "Bad parameter", response = ErrorResponse.class),
        @ApiResponse(code = 404, message = "No such image", response = ErrorResponse.class),
        @ApiResponse(code = 409, message = "Conflict", response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "Server error", response = ErrorResponse.class) })
    public void imageTag(@PathParam("name") String name, @QueryParam("repo")String repo, @QueryParam("tag")String tag);
}

