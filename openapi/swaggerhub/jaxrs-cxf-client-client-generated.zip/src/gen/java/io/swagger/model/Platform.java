package io.swagger.model;

import io.swagger.annotations.ApiModel;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * Platform represents the platform (Arch/OS). 
 **/
@ApiModel(description="Platform represents the platform (Arch/OS). ")
public class Platform  {
  
  @ApiModelProperty(example = "x86_64", value = "Architecture represents the hardware architecture (for example, `x86_64`). ")
 /**
   * Architecture represents the hardware architecture (for example, `x86_64`).   
  **/
  private String architecture = null;

  @ApiModelProperty(example = "linux", value = "OS represents the Operating System (for example, `linux` or `windows`). ")
 /**
   * OS represents the Operating System (for example, `linux` or `windows`).   
  **/
  private String OS = null;
 /**
   * Architecture represents the hardware architecture (for example, &#x60;x86_64&#x60;). 
   * @return architecture
  **/
  @JsonProperty("Architecture")
  public String getArchitecture() {
    return architecture;
  }

  public void setArchitecture(String architecture) {
    this.architecture = architecture;
  }

  public Platform architecture(String architecture) {
    this.architecture = architecture;
    return this;
  }

 /**
   * OS represents the Operating System (for example, &#x60;linux&#x60; or &#x60;windows&#x60;). 
   * @return OS
  **/
  @JsonProperty("OS")
  public String getOS() {
    return OS;
  }

  public void setOS(String OS) {
    this.OS = OS;
  }

  public Platform OS(String OS) {
    this.OS = OS;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Platform {\n");
    
    sb.append("    architecture: ").append(toIndentedString(architecture)).append("\n");
    sb.append("    OS: ").append(toIndentedString(OS)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

