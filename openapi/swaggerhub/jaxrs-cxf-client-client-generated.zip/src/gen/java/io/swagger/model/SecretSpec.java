package io.swagger.model;

import io.swagger.model.Driver;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class SecretSpec  {
  
  @ApiModelProperty(value = "User-defined name of the secret.")
 /**
   * User-defined name of the secret.  
  **/
  private String name = null;

  @ApiModelProperty(example = "{\"com.example.some-label\":\"some-value\",\"com.example.some-other-label\":\"some-other-value\"}", value = "User-defined key/value metadata.")
 /**
   * User-defined key/value metadata.  
  **/
  private Map<String, String> labels = null;

  @ApiModelProperty(example = "", value = "Base64-url-safe-encoded ([RFC 4648](https://tools.ietf.org/html/rfc4648#section-3.2)) data to store as secret.  This field is only used to _create_ a secret, and is not returned by other endpoints. ")
 /**
   * Base64-url-safe-encoded ([RFC 4648](https://tools.ietf.org/html/rfc4648#section-3.2)) data to store as secret.  This field is only used to _create_ a secret, and is not returned by other endpoints.   
  **/
  private String data = null;

  @ApiModelProperty(value = "Name of the secrets driver used to fetch the secret's value from an external secret store")
 /**
   * Name of the secrets driver used to fetch the secret's value from an external secret store  
  **/
  private Driver driver = null;

  @ApiModelProperty(value = "Templating driver, if applicable  Templating controls whether and how to evaluate the config payload as a template. If no driver is set, no templating is used. ")
 /**
   * Templating driver, if applicable  Templating controls whether and how to evaluate the config payload as a template. If no driver is set, no templating is used.   
  **/
  private Driver templating = null;
 /**
   * User-defined name of the secret.
   * @return name
  **/
  @JsonProperty("Name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public SecretSpec name(String name) {
    this.name = name;
    return this;
  }

 /**
   * User-defined key/value metadata.
   * @return labels
  **/
  @JsonProperty("Labels")
  public Map<String, String> getLabels() {
    return labels;
  }

  public void setLabels(Map<String, String> labels) {
    this.labels = labels;
  }

  public SecretSpec labels(Map<String, String> labels) {
    this.labels = labels;
    return this;
  }

  public SecretSpec putLabelsItem(String key, String labelsItem) {
    this.labels.put(key, labelsItem);
    return this;
  }

 /**
   * Base64-url-safe-encoded ([RFC 4648](https://tools.ietf.org/html/rfc4648#section-3.2)) data to store as secret.  This field is only used to _create_ a secret, and is not returned by other endpoints. 
   * @return data
  **/
  @JsonProperty("Data")
  public String getData() {
    return data;
  }

  public void setData(String data) {
    this.data = data;
  }

  public SecretSpec data(String data) {
    this.data = data;
    return this;
  }

 /**
   * Name of the secrets driver used to fetch the secret&#39;s value from an external secret store
   * @return driver
  **/
  @JsonProperty("Driver")
  public Driver getDriver() {
    return driver;
  }

  public void setDriver(Driver driver) {
    this.driver = driver;
  }

  public SecretSpec driver(Driver driver) {
    this.driver = driver;
    return this;
  }

 /**
   * Templating driver, if applicable  Templating controls whether and how to evaluate the config payload as a template. If no driver is set, no templating is used. 
   * @return templating
  **/
  @JsonProperty("Templating")
  public Driver getTemplating() {
    return templating;
  }

  public void setTemplating(Driver templating) {
    this.templating = templating;
  }

  public SecretSpec templating(Driver templating) {
    this.templating = templating;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SecretSpec {\n");
    
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    labels: ").append(toIndentedString(labels)).append("\n");
    sb.append("    data: ").append(toIndentedString(data)).append("\n");
    sb.append("    driver: ").append(toIndentedString(driver)).append("\n");
    sb.append("    templating: ").append(toIndentedString(templating)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

