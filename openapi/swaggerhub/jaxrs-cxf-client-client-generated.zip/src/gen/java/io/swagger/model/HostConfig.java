package io.swagger.model;

import io.swagger.annotations.ApiModel;
import io.swagger.model.DeviceMapping;
import io.swagger.model.HostConfigLogConfig;
import io.swagger.model.Mount;
import io.swagger.model.PortMap;
import io.swagger.model.Resources;
import io.swagger.model.ResourcesBlkioWeightDevice;
import io.swagger.model.ResourcesUlimits;
import io.swagger.model.RestartPolicy;
import io.swagger.model.ThrottleDevice;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * Container configuration that depends on the host we are running on
 **/
@ApiModel(description="Container configuration that depends on the host we are running on")
public class HostConfig extends Resources {
  
  @ApiModelProperty(value = "A list of volume bindings for this container. Each volume binding is a string in one of these forms:  - `host-src:container-dest` to bind-mount a host path into the container. Both `host-src`, and `container-dest` must be an _absolute_ path. - `host-src:container-dest:ro` to make the bind mount read-only inside the container. Both `host-src`, and `container-dest` must be an _absolute_ path. - `volume-name:container-dest` to bind-mount a volume managed by a volume driver into the container. `container-dest` must be an _absolute_ path. - `volume-name:container-dest:ro` to mount the volume read-only inside the container.  `container-dest` must be an _absolute_ path. ")
 /**
   * A list of volume bindings for this container. Each volume binding is a string in one of these forms:  - `host-src:container-dest` to bind-mount a host path into the container. Both `host-src`, and `container-dest` must be an _absolute_ path. - `host-src:container-dest:ro` to make the bind mount read-only inside the container. Both `host-src`, and `container-dest` must be an _absolute_ path. - `volume-name:container-dest` to bind-mount a volume managed by a volume driver into the container. `container-dest` must be an _absolute_ path. - `volume-name:container-dest:ro` to mount the volume read-only inside the container.  `container-dest` must be an _absolute_ path.   
  **/
  private List<String> binds = null;

  @ApiModelProperty(value = "Path to a file where the container ID is written")
 /**
   * Path to a file where the container ID is written  
  **/
  private String containerIDFile = null;

  @ApiModelProperty(value = "")
  private HostConfigLogConfig logConfig = null;

  @ApiModelProperty(value = "Network mode to use for this container. Supported standard values are: `bridge`, `host`, `none`, and `container:<name|id>`. Any other value is taken as a custom network's name to which this container should connect to.")
 /**
   * Network mode to use for this container. Supported standard values are: `bridge`, `host`, `none`, and `container:<name|id>`. Any other value is taken as a custom network's name to which this container should connect to.  
  **/
  private String networkMode = null;

  @ApiModelProperty(value = "")
  private PortMap portBindings = null;

  @ApiModelProperty(value = "")
  private RestartPolicy restartPolicy = null;

  @ApiModelProperty(value = "Automatically remove the container when the container's process exits. This has no effect if `RestartPolicy` is set.")
 /**
   * Automatically remove the container when the container's process exits. This has no effect if `RestartPolicy` is set.  
  **/
  private Boolean autoRemove = null;

  @ApiModelProperty(value = "Driver that this container uses to mount volumes.")
 /**
   * Driver that this container uses to mount volumes.  
  **/
  private String volumeDriver = null;

  @ApiModelProperty(value = "A list of volumes to inherit from another container, specified in the form `<container name>[:<ro|rw>]`.")
 /**
   * A list of volumes to inherit from another container, specified in the form `<container name>[:<ro|rw>]`.  
  **/
  private List<String> volumesFrom = null;

  @ApiModelProperty(value = "Specification for mounts to be added to the container.")
 /**
   * Specification for mounts to be added to the container.  
  **/
  private List<Mount> mounts = null;

  @ApiModelProperty(value = "A list of kernel capabilities to add to the container.")
 /**
   * A list of kernel capabilities to add to the container.  
  **/
  private List<String> capAdd = null;

  @ApiModelProperty(value = "A list of kernel capabilities to drop from the container.")
 /**
   * A list of kernel capabilities to drop from the container.  
  **/
  private List<String> capDrop = null;

  @ApiModelProperty(value = "A list of DNS servers for the container to use.")
 /**
   * A list of DNS servers for the container to use.  
  **/
  private List<String> dns = null;

  @ApiModelProperty(value = "A list of DNS options.")
 /**
   * A list of DNS options.  
  **/
  private List<String> dnsOptions = null;

  @ApiModelProperty(value = "A list of DNS search domains.")
 /**
   * A list of DNS search domains.  
  **/
  private List<String> dnsSearch = null;

  @ApiModelProperty(value = "A list of hostnames/IP mappings to add to the container's `/etc/hosts` file. Specified in the form `[\"hostname:IP\"]`. ")
 /**
   * A list of hostnames/IP mappings to add to the container's `/etc/hosts` file. Specified in the form `[\"hostname:IP\"]`.   
  **/
  private List<String> extraHosts = null;

  @ApiModelProperty(value = "A list of additional groups that the container process will run as.")
 /**
   * A list of additional groups that the container process will run as.  
  **/
  private List<String> groupAdd = null;

  @ApiModelProperty(value = "IPC sharing mode for the container. Possible values are:  - `\"none\"`: own private IPC namespace, with /dev/shm not mounted - `\"private\"`: own private IPC namespace - `\"shareable\"`: own private IPC namespace, with a possibility to share it with other containers - `\"container:<name|id>\"`: join another (shareable) container's IPC namespace - `\"host\"`: use the host system's IPC namespace  If not specified, daemon default is used, which can either be `\"private\"` or `\"shareable\"`, depending on daemon version and configuration. ")
 /**
   * IPC sharing mode for the container. Possible values are:  - `\"none\"`: own private IPC namespace, with /dev/shm not mounted - `\"private\"`: own private IPC namespace - `\"shareable\"`: own private IPC namespace, with a possibility to share it with other containers - `\"container:<name|id>\"`: join another (shareable) container's IPC namespace - `\"host\"`: use the host system's IPC namespace  If not specified, daemon default is used, which can either be `\"private\"` or `\"shareable\"`, depending on daemon version and configuration.   
  **/
  private String ipcMode = null;

  @ApiModelProperty(value = "Cgroup to use for the container.")
 /**
   * Cgroup to use for the container.  
  **/
  private String cgroup = null;

  @ApiModelProperty(value = "A list of links for the container in the form `container_name:alias`.")
 /**
   * A list of links for the container in the form `container_name:alias`.  
  **/
  private List<String> links = null;

  @ApiModelProperty(example = "500", value = "An integer value containing the score given to the container in order to tune OOM killer preferences.")
 /**
   * An integer value containing the score given to the container in order to tune OOM killer preferences.  
  **/
  private Integer oomScoreAdj = null;

  @ApiModelProperty(value = "Set the PID (Process) Namespace mode for the container. It can be either:  - `\"container:<name|id>\"`: joins another container's PID namespace - `\"host\"`: use the host's PID namespace inside the container ")
 /**
   * Set the PID (Process) Namespace mode for the container. It can be either:  - `\"container:<name|id>\"`: joins another container's PID namespace - `\"host\"`: use the host's PID namespace inside the container   
  **/
  private String pidMode = null;

  @ApiModelProperty(value = "Gives the container full access to the host.")
 /**
   * Gives the container full access to the host.  
  **/
  private Boolean privileged = null;

  @ApiModelProperty(value = "Allocates an ephemeral host port for all of a container's exposed ports.  Ports are de-allocated when the container stops and allocated when the container starts. The allocated port might be changed when restarting the container.  The port is selected from the ephemeral port range that depends on the kernel. For example, on Linux the range is defined by `/proc/sys/net/ipv4/ip_local_port_range`. ")
 /**
   * Allocates an ephemeral host port for all of a container's exposed ports.  Ports are de-allocated when the container stops and allocated when the container starts. The allocated port might be changed when restarting the container.  The port is selected from the ephemeral port range that depends on the kernel. For example, on Linux the range is defined by `/proc/sys/net/ipv4/ip_local_port_range`.   
  **/
  private Boolean publishAllPorts = null;

  @ApiModelProperty(value = "Mount the container's root filesystem as read only.")
 /**
   * Mount the container's root filesystem as read only.  
  **/
  private Boolean readonlyRootfs = null;

  @ApiModelProperty(value = "A list of string values to customize labels for MLS systems, such as SELinux.")
 /**
   * A list of string values to customize labels for MLS systems, such as SELinux.  
  **/
  private List<String> securityOpt = null;

  @ApiModelProperty(value = "Storage driver options for this container, in the form `{\"size\": \"120G\"}`. ")
 /**
   * Storage driver options for this container, in the form `{\"size\": \"120G\"}`.   
  **/
  private Map<String, String> storageOpt = null;

  @ApiModelProperty(value = "A map of container directories which should be replaced by tmpfs mounts, and their corresponding mount options. For example: `{ \"/run\": \"rw,noexec,nosuid,size=65536k\" }`. ")
 /**
   * A map of container directories which should be replaced by tmpfs mounts, and their corresponding mount options. For example: `{ \"/run\": \"rw,noexec,nosuid,size=65536k\" }`.   
  **/
  private Map<String, String> tmpfs = null;

  @ApiModelProperty(value = "UTS namespace to use for the container.")
 /**
   * UTS namespace to use for the container.  
  **/
  private String utSMode = null;

  @ApiModelProperty(value = "Sets the usernamespace mode for the container when usernamespace remapping option is enabled.")
 /**
   * Sets the usernamespace mode for the container when usernamespace remapping option is enabled.  
  **/
  private String usernsMode = null;

  @ApiModelProperty(value = "Size of `/dev/shm` in bytes. If omitted, the system uses 64MB.")
 /**
   * Size of `/dev/shm` in bytes. If omitted, the system uses 64MB.  
  **/
  private Integer shmSize = null;

  @ApiModelProperty(value = "A list of kernel parameters (sysctls) to set in the container. For example: `{\"net.ipv4.ip_forward\": \"1\"}` ")
 /**
   * A list of kernel parameters (sysctls) to set in the container. For example: `{\"net.ipv4.ip_forward\": \"1\"}`   
  **/
  private Map<String, String> sysctls = null;

  @ApiModelProperty(value = "Runtime to use with this container.")
 /**
   * Runtime to use with this container.  
  **/
  private String runtime = null;

  @ApiModelProperty(value = "Initial console size, as an `[height, width]` array. (Windows only)")
 /**
   * Initial console size, as an `[height, width]` array. (Windows only)  
  **/
  private List<Integer> consoleSize = null;


@XmlType(name="IsolationEnum")
@XmlEnum(String.class)
public enum IsolationEnum {

@XmlEnumValue("default") DEFAULT(String.valueOf("default")), @XmlEnumValue("process") PROCESS(String.valueOf("process")), @XmlEnumValue("hyperv") HYPERV(String.valueOf("hyperv"));


    private String value;

    IsolationEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static IsolationEnum fromValue(String v) {
        for (IsolationEnum b : IsolationEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(value = "Isolation technology of the container. (Windows only)")
 /**
   * Isolation technology of the container. (Windows only)  
  **/
  private IsolationEnum isolation = null;

  @ApiModelProperty(value = "The list of paths to be masked inside the container (this overrides the default set of paths)")
 /**
   * The list of paths to be masked inside the container (this overrides the default set of paths)  
  **/
  private List<String> maskedPaths = null;

  @ApiModelProperty(value = "The list of paths to be set as read-only inside the container (this overrides the default set of paths)")
 /**
   * The list of paths to be set as read-only inside the container (this overrides the default set of paths)  
  **/
  private List<String> readonlyPaths = null;
 /**
   * A list of volume bindings for this container. Each volume binding is a string in one of these forms:  - &#x60;host-src:container-dest&#x60; to bind-mount a host path into the container. Both &#x60;host-src&#x60;, and &#x60;container-dest&#x60; must be an _absolute_ path. - &#x60;host-src:container-dest:ro&#x60; to make the bind mount read-only inside the container. Both &#x60;host-src&#x60;, and &#x60;container-dest&#x60; must be an _absolute_ path. - &#x60;volume-name:container-dest&#x60; to bind-mount a volume managed by a volume driver into the container. &#x60;container-dest&#x60; must be an _absolute_ path. - &#x60;volume-name:container-dest:ro&#x60; to mount the volume read-only inside the container.  &#x60;container-dest&#x60; must be an _absolute_ path. 
   * @return binds
  **/
  @JsonProperty("Binds")
  public List<String> getBinds() {
    return binds;
  }

  public void setBinds(List<String> binds) {
    this.binds = binds;
  }

  public HostConfig binds(List<String> binds) {
    this.binds = binds;
    return this;
  }

  public HostConfig addBindsItem(String bindsItem) {
    this.binds.add(bindsItem);
    return this;
  }

 /**
   * Path to a file where the container ID is written
   * @return containerIDFile
  **/
  @JsonProperty("ContainerIDFile")
  public String getContainerIDFile() {
    return containerIDFile;
  }

  public void setContainerIDFile(String containerIDFile) {
    this.containerIDFile = containerIDFile;
  }

  public HostConfig containerIDFile(String containerIDFile) {
    this.containerIDFile = containerIDFile;
    return this;
  }

 /**
   * Get logConfig
   * @return logConfig
  **/
  @JsonProperty("LogConfig")
  public HostConfigLogConfig getLogConfig() {
    return logConfig;
  }

  public void setLogConfig(HostConfigLogConfig logConfig) {
    this.logConfig = logConfig;
  }

  public HostConfig logConfig(HostConfigLogConfig logConfig) {
    this.logConfig = logConfig;
    return this;
  }

 /**
   * Network mode to use for this container. Supported standard values are: &#x60;bridge&#x60;, &#x60;host&#x60;, &#x60;none&#x60;, and &#x60;container:&lt;name|id&gt;&#x60;. Any other value is taken as a custom network&#39;s name to which this container should connect to.
   * @return networkMode
  **/
  @JsonProperty("NetworkMode")
  public String getNetworkMode() {
    return networkMode;
  }

  public void setNetworkMode(String networkMode) {
    this.networkMode = networkMode;
  }

  public HostConfig networkMode(String networkMode) {
    this.networkMode = networkMode;
    return this;
  }

 /**
   * Get portBindings
   * @return portBindings
  **/
  @JsonProperty("PortBindings")
  public PortMap getPortBindings() {
    return portBindings;
  }

  public void setPortBindings(PortMap portBindings) {
    this.portBindings = portBindings;
  }

  public HostConfig portBindings(PortMap portBindings) {
    this.portBindings = portBindings;
    return this;
  }

 /**
   * Get restartPolicy
   * @return restartPolicy
  **/
  @JsonProperty("RestartPolicy")
  public RestartPolicy getRestartPolicy() {
    return restartPolicy;
  }

  public void setRestartPolicy(RestartPolicy restartPolicy) {
    this.restartPolicy = restartPolicy;
  }

  public HostConfig restartPolicy(RestartPolicy restartPolicy) {
    this.restartPolicy = restartPolicy;
    return this;
  }

 /**
   * Automatically remove the container when the container&#39;s process exits. This has no effect if &#x60;RestartPolicy&#x60; is set.
   * @return autoRemove
  **/
  @JsonProperty("AutoRemove")
  public Boolean isAutoRemove() {
    return autoRemove;
  }

  public void setAutoRemove(Boolean autoRemove) {
    this.autoRemove = autoRemove;
  }

  public HostConfig autoRemove(Boolean autoRemove) {
    this.autoRemove = autoRemove;
    return this;
  }

 /**
   * Driver that this container uses to mount volumes.
   * @return volumeDriver
  **/
  @JsonProperty("VolumeDriver")
  public String getVolumeDriver() {
    return volumeDriver;
  }

  public void setVolumeDriver(String volumeDriver) {
    this.volumeDriver = volumeDriver;
  }

  public HostConfig volumeDriver(String volumeDriver) {
    this.volumeDriver = volumeDriver;
    return this;
  }

 /**
   * A list of volumes to inherit from another container, specified in the form &#x60;&lt;container name&gt;[:&lt;ro|rw&gt;]&#x60;.
   * @return volumesFrom
  **/
  @JsonProperty("VolumesFrom")
  public List<String> getVolumesFrom() {
    return volumesFrom;
  }

  public void setVolumesFrom(List<String> volumesFrom) {
    this.volumesFrom = volumesFrom;
  }

  public HostConfig volumesFrom(List<String> volumesFrom) {
    this.volumesFrom = volumesFrom;
    return this;
  }

  public HostConfig addVolumesFromItem(String volumesFromItem) {
    this.volumesFrom.add(volumesFromItem);
    return this;
  }

 /**
   * Specification for mounts to be added to the container.
   * @return mounts
  **/
  @JsonProperty("Mounts")
  public List<Mount> getMounts() {
    return mounts;
  }

  public void setMounts(List<Mount> mounts) {
    this.mounts = mounts;
  }

  public HostConfig mounts(List<Mount> mounts) {
    this.mounts = mounts;
    return this;
  }

  public HostConfig addMountsItem(Mount mountsItem) {
    this.mounts.add(mountsItem);
    return this;
  }

 /**
   * A list of kernel capabilities to add to the container.
   * @return capAdd
  **/
  @JsonProperty("CapAdd")
  public List<String> getCapAdd() {
    return capAdd;
  }

  public void setCapAdd(List<String> capAdd) {
    this.capAdd = capAdd;
  }

  public HostConfig capAdd(List<String> capAdd) {
    this.capAdd = capAdd;
    return this;
  }

  public HostConfig addCapAddItem(String capAddItem) {
    this.capAdd.add(capAddItem);
    return this;
  }

 /**
   * A list of kernel capabilities to drop from the container.
   * @return capDrop
  **/
  @JsonProperty("CapDrop")
  public List<String> getCapDrop() {
    return capDrop;
  }

  public void setCapDrop(List<String> capDrop) {
    this.capDrop = capDrop;
  }

  public HostConfig capDrop(List<String> capDrop) {
    this.capDrop = capDrop;
    return this;
  }

  public HostConfig addCapDropItem(String capDropItem) {
    this.capDrop.add(capDropItem);
    return this;
  }

 /**
   * A list of DNS servers for the container to use.
   * @return dns
  **/
  @JsonProperty("Dns")
  public List<String> getDns() {
    return dns;
  }

  public void setDns(List<String> dns) {
    this.dns = dns;
  }

  public HostConfig dns(List<String> dns) {
    this.dns = dns;
    return this;
  }

  public HostConfig addDnsItem(String dnsItem) {
    this.dns.add(dnsItem);
    return this;
  }

 /**
   * A list of DNS options.
   * @return dnsOptions
  **/
  @JsonProperty("DnsOptions")
  public List<String> getDnsOptions() {
    return dnsOptions;
  }

  public void setDnsOptions(List<String> dnsOptions) {
    this.dnsOptions = dnsOptions;
  }

  public HostConfig dnsOptions(List<String> dnsOptions) {
    this.dnsOptions = dnsOptions;
    return this;
  }

  public HostConfig addDnsOptionsItem(String dnsOptionsItem) {
    this.dnsOptions.add(dnsOptionsItem);
    return this;
  }

 /**
   * A list of DNS search domains.
   * @return dnsSearch
  **/
  @JsonProperty("DnsSearch")
  public List<String> getDnsSearch() {
    return dnsSearch;
  }

  public void setDnsSearch(List<String> dnsSearch) {
    this.dnsSearch = dnsSearch;
  }

  public HostConfig dnsSearch(List<String> dnsSearch) {
    this.dnsSearch = dnsSearch;
    return this;
  }

  public HostConfig addDnsSearchItem(String dnsSearchItem) {
    this.dnsSearch.add(dnsSearchItem);
    return this;
  }

 /**
   * A list of hostnames/IP mappings to add to the container&#39;s &#x60;/etc/hosts&#x60; file. Specified in the form &#x60;[\&quot;hostname:IP\&quot;]&#x60;. 
   * @return extraHosts
  **/
  @JsonProperty("ExtraHosts")
  public List<String> getExtraHosts() {
    return extraHosts;
  }

  public void setExtraHosts(List<String> extraHosts) {
    this.extraHosts = extraHosts;
  }

  public HostConfig extraHosts(List<String> extraHosts) {
    this.extraHosts = extraHosts;
    return this;
  }

  public HostConfig addExtraHostsItem(String extraHostsItem) {
    this.extraHosts.add(extraHostsItem);
    return this;
  }

 /**
   * A list of additional groups that the container process will run as.
   * @return groupAdd
  **/
  @JsonProperty("GroupAdd")
  public List<String> getGroupAdd() {
    return groupAdd;
  }

  public void setGroupAdd(List<String> groupAdd) {
    this.groupAdd = groupAdd;
  }

  public HostConfig groupAdd(List<String> groupAdd) {
    this.groupAdd = groupAdd;
    return this;
  }

  public HostConfig addGroupAddItem(String groupAddItem) {
    this.groupAdd.add(groupAddItem);
    return this;
  }

 /**
   * IPC sharing mode for the container. Possible values are:  - &#x60;\&quot;none\&quot;&#x60;: own private IPC namespace, with /dev/shm not mounted - &#x60;\&quot;private\&quot;&#x60;: own private IPC namespace - &#x60;\&quot;shareable\&quot;&#x60;: own private IPC namespace, with a possibility to share it with other containers - &#x60;\&quot;container:&lt;name|id&gt;\&quot;&#x60;: join another (shareable) container&#39;s IPC namespace - &#x60;\&quot;host\&quot;&#x60;: use the host system&#39;s IPC namespace  If not specified, daemon default is used, which can either be &#x60;\&quot;private\&quot;&#x60; or &#x60;\&quot;shareable\&quot;&#x60;, depending on daemon version and configuration. 
   * @return ipcMode
  **/
  @JsonProperty("IpcMode")
  public String getIpcMode() {
    return ipcMode;
  }

  public void setIpcMode(String ipcMode) {
    this.ipcMode = ipcMode;
  }

  public HostConfig ipcMode(String ipcMode) {
    this.ipcMode = ipcMode;
    return this;
  }

 /**
   * Cgroup to use for the container.
   * @return cgroup
  **/
  @JsonProperty("Cgroup")
  public String getCgroup() {
    return cgroup;
  }

  public void setCgroup(String cgroup) {
    this.cgroup = cgroup;
  }

  public HostConfig cgroup(String cgroup) {
    this.cgroup = cgroup;
    return this;
  }

 /**
   * A list of links for the container in the form &#x60;container_name:alias&#x60;.
   * @return links
  **/
  @JsonProperty("Links")
  public List<String> getLinks() {
    return links;
  }

  public void setLinks(List<String> links) {
    this.links = links;
  }

  public HostConfig links(List<String> links) {
    this.links = links;
    return this;
  }

  public HostConfig addLinksItem(String linksItem) {
    this.links.add(linksItem);
    return this;
  }

 /**
   * An integer value containing the score given to the container in order to tune OOM killer preferences.
   * @return oomScoreAdj
  **/
  @JsonProperty("OomScoreAdj")
  public Integer getOomScoreAdj() {
    return oomScoreAdj;
  }

  public void setOomScoreAdj(Integer oomScoreAdj) {
    this.oomScoreAdj = oomScoreAdj;
  }

  public HostConfig oomScoreAdj(Integer oomScoreAdj) {
    this.oomScoreAdj = oomScoreAdj;
    return this;
  }

 /**
   * Set the PID (Process) Namespace mode for the container. It can be either:  - &#x60;\&quot;container:&lt;name|id&gt;\&quot;&#x60;: joins another container&#39;s PID namespace - &#x60;\&quot;host\&quot;&#x60;: use the host&#39;s PID namespace inside the container 
   * @return pidMode
  **/
  @JsonProperty("PidMode")
  public String getPidMode() {
    return pidMode;
  }

  public void setPidMode(String pidMode) {
    this.pidMode = pidMode;
  }

  public HostConfig pidMode(String pidMode) {
    this.pidMode = pidMode;
    return this;
  }

 /**
   * Gives the container full access to the host.
   * @return privileged
  **/
  @JsonProperty("Privileged")
  public Boolean isPrivileged() {
    return privileged;
  }

  public void setPrivileged(Boolean privileged) {
    this.privileged = privileged;
  }

  public HostConfig privileged(Boolean privileged) {
    this.privileged = privileged;
    return this;
  }

 /**
   * Allocates an ephemeral host port for all of a container&#39;s exposed ports.  Ports are de-allocated when the container stops and allocated when the container starts. The allocated port might be changed when restarting the container.  The port is selected from the ephemeral port range that depends on the kernel. For example, on Linux the range is defined by &#x60;/proc/sys/net/ipv4/ip_local_port_range&#x60;. 
   * @return publishAllPorts
  **/
  @JsonProperty("PublishAllPorts")
  public Boolean isPublishAllPorts() {
    return publishAllPorts;
  }

  public void setPublishAllPorts(Boolean publishAllPorts) {
    this.publishAllPorts = publishAllPorts;
  }

  public HostConfig publishAllPorts(Boolean publishAllPorts) {
    this.publishAllPorts = publishAllPorts;
    return this;
  }

 /**
   * Mount the container&#39;s root filesystem as read only.
   * @return readonlyRootfs
  **/
  @JsonProperty("ReadonlyRootfs")
  public Boolean isReadonlyRootfs() {
    return readonlyRootfs;
  }

  public void setReadonlyRootfs(Boolean readonlyRootfs) {
    this.readonlyRootfs = readonlyRootfs;
  }

  public HostConfig readonlyRootfs(Boolean readonlyRootfs) {
    this.readonlyRootfs = readonlyRootfs;
    return this;
  }

 /**
   * A list of string values to customize labels for MLS systems, such as SELinux.
   * @return securityOpt
  **/
  @JsonProperty("SecurityOpt")
  public List<String> getSecurityOpt() {
    return securityOpt;
  }

  public void setSecurityOpt(List<String> securityOpt) {
    this.securityOpt = securityOpt;
  }

  public HostConfig securityOpt(List<String> securityOpt) {
    this.securityOpt = securityOpt;
    return this;
  }

  public HostConfig addSecurityOptItem(String securityOptItem) {
    this.securityOpt.add(securityOptItem);
    return this;
  }

 /**
   * Storage driver options for this container, in the form &#x60;{\&quot;size\&quot;: \&quot;120G\&quot;}&#x60;. 
   * @return storageOpt
  **/
  @JsonProperty("StorageOpt")
  public Map<String, String> getStorageOpt() {
    return storageOpt;
  }

  public void setStorageOpt(Map<String, String> storageOpt) {
    this.storageOpt = storageOpt;
  }

  public HostConfig storageOpt(Map<String, String> storageOpt) {
    this.storageOpt = storageOpt;
    return this;
  }

  public HostConfig putStorageOptItem(String key, String storageOptItem) {
    this.storageOpt.put(key, storageOptItem);
    return this;
  }

 /**
   * A map of container directories which should be replaced by tmpfs mounts, and their corresponding mount options. For example: &#x60;{ \&quot;/run\&quot;: \&quot;rw,noexec,nosuid,size&#x3D;65536k\&quot; }&#x60;. 
   * @return tmpfs
  **/
  @JsonProperty("Tmpfs")
  public Map<String, String> getTmpfs() {
    return tmpfs;
  }

  public void setTmpfs(Map<String, String> tmpfs) {
    this.tmpfs = tmpfs;
  }

  public HostConfig tmpfs(Map<String, String> tmpfs) {
    this.tmpfs = tmpfs;
    return this;
  }

  public HostConfig putTmpfsItem(String key, String tmpfsItem) {
    this.tmpfs.put(key, tmpfsItem);
    return this;
  }

 /**
   * UTS namespace to use for the container.
   * @return utSMode
  **/
  @JsonProperty("UTSMode")
  public String getUtSMode() {
    return utSMode;
  }

  public void setUtSMode(String utSMode) {
    this.utSMode = utSMode;
  }

  public HostConfig utSMode(String utSMode) {
    this.utSMode = utSMode;
    return this;
  }

 /**
   * Sets the usernamespace mode for the container when usernamespace remapping option is enabled.
   * @return usernsMode
  **/
  @JsonProperty("UsernsMode")
  public String getUsernsMode() {
    return usernsMode;
  }

  public void setUsernsMode(String usernsMode) {
    this.usernsMode = usernsMode;
  }

  public HostConfig usernsMode(String usernsMode) {
    this.usernsMode = usernsMode;
    return this;
  }

 /**
   * Size of &#x60;/dev/shm&#x60; in bytes. If omitted, the system uses 64MB.
   * minimum: 0
   * @return shmSize
  **/
  @JsonProperty("ShmSize")
  public Integer getShmSize() {
    return shmSize;
  }

  public void setShmSize(Integer shmSize) {
    this.shmSize = shmSize;
  }

  public HostConfig shmSize(Integer shmSize) {
    this.shmSize = shmSize;
    return this;
  }

 /**
   * A list of kernel parameters (sysctls) to set in the container. For example: &#x60;{\&quot;net.ipv4.ip_forward\&quot;: \&quot;1\&quot;}&#x60; 
   * @return sysctls
  **/
  @JsonProperty("Sysctls")
  public Map<String, String> getSysctls() {
    return sysctls;
  }

  public void setSysctls(Map<String, String> sysctls) {
    this.sysctls = sysctls;
  }

  public HostConfig sysctls(Map<String, String> sysctls) {
    this.sysctls = sysctls;
    return this;
  }

  public HostConfig putSysctlsItem(String key, String sysctlsItem) {
    this.sysctls.put(key, sysctlsItem);
    return this;
  }

 /**
   * Runtime to use with this container.
   * @return runtime
  **/
  @JsonProperty("Runtime")
  public String getRuntime() {
    return runtime;
  }

  public void setRuntime(String runtime) {
    this.runtime = runtime;
  }

  public HostConfig runtime(String runtime) {
    this.runtime = runtime;
    return this;
  }

 /**
   * Initial console size, as an &#x60;[height, width]&#x60; array. (Windows only)
   * @return consoleSize
  **/
  @JsonProperty("ConsoleSize")
  public List<Integer> getConsoleSize() {
    return consoleSize;
  }

  public void setConsoleSize(List<Integer> consoleSize) {
    this.consoleSize = consoleSize;
  }

  public HostConfig consoleSize(List<Integer> consoleSize) {
    this.consoleSize = consoleSize;
    return this;
  }

  public HostConfig addConsoleSizeItem(Integer consoleSizeItem) {
    this.consoleSize.add(consoleSizeItem);
    return this;
  }

 /**
   * Isolation technology of the container. (Windows only)
   * @return isolation
  **/
  @JsonProperty("Isolation")
  public String getIsolation() {
    if (isolation == null) {
      return null;
    }
    return isolation.value();
  }

  public void setIsolation(IsolationEnum isolation) {
    this.isolation = isolation;
  }

  public HostConfig isolation(IsolationEnum isolation) {
    this.isolation = isolation;
    return this;
  }

 /**
   * The list of paths to be masked inside the container (this overrides the default set of paths)
   * @return maskedPaths
  **/
  @JsonProperty("MaskedPaths")
  public List<String> getMaskedPaths() {
    return maskedPaths;
  }

  public void setMaskedPaths(List<String> maskedPaths) {
    this.maskedPaths = maskedPaths;
  }

  public HostConfig maskedPaths(List<String> maskedPaths) {
    this.maskedPaths = maskedPaths;
    return this;
  }

  public HostConfig addMaskedPathsItem(String maskedPathsItem) {
    this.maskedPaths.add(maskedPathsItem);
    return this;
  }

 /**
   * The list of paths to be set as read-only inside the container (this overrides the default set of paths)
   * @return readonlyPaths
  **/
  @JsonProperty("ReadonlyPaths")
  public List<String> getReadonlyPaths() {
    return readonlyPaths;
  }

  public void setReadonlyPaths(List<String> readonlyPaths) {
    this.readonlyPaths = readonlyPaths;
  }

  public HostConfig readonlyPaths(List<String> readonlyPaths) {
    this.readonlyPaths = readonlyPaths;
    return this;
  }

  public HostConfig addReadonlyPathsItem(String readonlyPathsItem) {
    this.readonlyPaths.add(readonlyPathsItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class HostConfig {\n");
    sb.append("    ").append(toIndentedString(super.toString())).append("\n");
    sb.append("    binds: ").append(toIndentedString(binds)).append("\n");
    sb.append("    containerIDFile: ").append(toIndentedString(containerIDFile)).append("\n");
    sb.append("    logConfig: ").append(toIndentedString(logConfig)).append("\n");
    sb.append("    networkMode: ").append(toIndentedString(networkMode)).append("\n");
    sb.append("    portBindings: ").append(toIndentedString(portBindings)).append("\n");
    sb.append("    restartPolicy: ").append(toIndentedString(restartPolicy)).append("\n");
    sb.append("    autoRemove: ").append(toIndentedString(autoRemove)).append("\n");
    sb.append("    volumeDriver: ").append(toIndentedString(volumeDriver)).append("\n");
    sb.append("    volumesFrom: ").append(toIndentedString(volumesFrom)).append("\n");
    sb.append("    mounts: ").append(toIndentedString(mounts)).append("\n");
    sb.append("    capAdd: ").append(toIndentedString(capAdd)).append("\n");
    sb.append("    capDrop: ").append(toIndentedString(capDrop)).append("\n");
    sb.append("    dns: ").append(toIndentedString(dns)).append("\n");
    sb.append("    dnsOptions: ").append(toIndentedString(dnsOptions)).append("\n");
    sb.append("    dnsSearch: ").append(toIndentedString(dnsSearch)).append("\n");
    sb.append("    extraHosts: ").append(toIndentedString(extraHosts)).append("\n");
    sb.append("    groupAdd: ").append(toIndentedString(groupAdd)).append("\n");
    sb.append("    ipcMode: ").append(toIndentedString(ipcMode)).append("\n");
    sb.append("    cgroup: ").append(toIndentedString(cgroup)).append("\n");
    sb.append("    links: ").append(toIndentedString(links)).append("\n");
    sb.append("    oomScoreAdj: ").append(toIndentedString(oomScoreAdj)).append("\n");
    sb.append("    pidMode: ").append(toIndentedString(pidMode)).append("\n");
    sb.append("    privileged: ").append(toIndentedString(privileged)).append("\n");
    sb.append("    publishAllPorts: ").append(toIndentedString(publishAllPorts)).append("\n");
    sb.append("    readonlyRootfs: ").append(toIndentedString(readonlyRootfs)).append("\n");
    sb.append("    securityOpt: ").append(toIndentedString(securityOpt)).append("\n");
    sb.append("    storageOpt: ").append(toIndentedString(storageOpt)).append("\n");
    sb.append("    tmpfs: ").append(toIndentedString(tmpfs)).append("\n");
    sb.append("    utSMode: ").append(toIndentedString(utSMode)).append("\n");
    sb.append("    usernsMode: ").append(toIndentedString(usernsMode)).append("\n");
    sb.append("    shmSize: ").append(toIndentedString(shmSize)).append("\n");
    sb.append("    sysctls: ").append(toIndentedString(sysctls)).append("\n");
    sb.append("    runtime: ").append(toIndentedString(runtime)).append("\n");
    sb.append("    consoleSize: ").append(toIndentedString(consoleSize)).append("\n");
    sb.append("    isolation: ").append(toIndentedString(isolation)).append("\n");
    sb.append("    maskedPaths: ").append(toIndentedString(maskedPaths)).append("\n");
    sb.append("    readonlyPaths: ").append(toIndentedString(readonlyPaths)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

