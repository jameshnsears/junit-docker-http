package io.swagger.model;

import io.swagger.annotations.ApiModel;
import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * OK response to ContainerTop operation
 **/
@ApiModel(description="OK response to ContainerTop operation")
public class ContainerTopResponse  {
  
  @ApiModelProperty(value = "The ps column titles")
 /**
   * The ps column titles  
  **/
  private List<String> titles = null;

  @ApiModelProperty(value = "Each process running in the container, where each is process is an array of values corresponding to the titles")
 /**
   * Each process running in the container, where each is process is an array of values corresponding to the titles  
  **/
  private List<List<String>> processes = null;
 /**
   * The ps column titles
   * @return titles
  **/
  @JsonProperty("Titles")
  public List<String> getTitles() {
    return titles;
  }

  public void setTitles(List<String> titles) {
    this.titles = titles;
  }

  public ContainerTopResponse titles(List<String> titles) {
    this.titles = titles;
    return this;
  }

  public ContainerTopResponse addTitlesItem(String titlesItem) {
    this.titles.add(titlesItem);
    return this;
  }

 /**
   * Each process running in the container, where each is process is an array of values corresponding to the titles
   * @return processes
  **/
  @JsonProperty("Processes")
  public List<List<String>> getProcesses() {
    return processes;
  }

  public void setProcesses(List<List<String>> processes) {
    this.processes = processes;
  }

  public ContainerTopResponse processes(List<List<String>> processes) {
    this.processes = processes;
    return this;
  }

  public ContainerTopResponse addProcessesItem(List<String> processesItem) {
    this.processes.add(processesItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ContainerTopResponse {\n");
    
    sb.append("    titles: ").append(toIndentedString(titles)).append("\n");
    sb.append("    processes: ").append(toIndentedString(processes)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

