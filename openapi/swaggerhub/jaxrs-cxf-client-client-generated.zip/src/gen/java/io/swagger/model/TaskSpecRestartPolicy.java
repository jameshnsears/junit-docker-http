package io.swagger.model;

import io.swagger.annotations.ApiModel;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * Specification for the restart policy which applies to containers created as part of this service.
 **/
@ApiModel(description="Specification for the restart policy which applies to containers created as part of this service.")
public class TaskSpecRestartPolicy  {
  

@XmlType(name="ConditionEnum")
@XmlEnum(String.class)
public enum ConditionEnum {

@XmlEnumValue("none") NONE(String.valueOf("none")), @XmlEnumValue("on-failure") ON_FAILURE(String.valueOf("on-failure")), @XmlEnumValue("any") ANY(String.valueOf("any"));


    private String value;

    ConditionEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static ConditionEnum fromValue(String v) {
        for (ConditionEnum b : ConditionEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(value = "Condition for restart.")
 /**
   * Condition for restart.  
  **/
  private ConditionEnum condition = null;

  @ApiModelProperty(value = "Delay between restart attempts.")
 /**
   * Delay between restart attempts.  
  **/
  private Long delay = null;

  @ApiModelProperty(value = "Maximum attempts to restart a given container before giving up (default value is 0, which is ignored).")
 /**
   * Maximum attempts to restart a given container before giving up (default value is 0, which is ignored).  
  **/
  private Long maxAttempts = 0l;

  @ApiModelProperty(value = "Windows is the time window used to evaluate the restart policy (default value is 0, which is unbounded).")
 /**
   * Windows is the time window used to evaluate the restart policy (default value is 0, which is unbounded).  
  **/
  private Long window = 0l;
 /**
   * Condition for restart.
   * @return condition
  **/
  @JsonProperty("Condition")
  public String getCondition() {
    if (condition == null) {
      return null;
    }
    return condition.value();
  }

  public void setCondition(ConditionEnum condition) {
    this.condition = condition;
  }

  public TaskSpecRestartPolicy condition(ConditionEnum condition) {
    this.condition = condition;
    return this;
  }

 /**
   * Delay between restart attempts.
   * @return delay
  **/
  @JsonProperty("Delay")
  public Long getDelay() {
    return delay;
  }

  public void setDelay(Long delay) {
    this.delay = delay;
  }

  public TaskSpecRestartPolicy delay(Long delay) {
    this.delay = delay;
    return this;
  }

 /**
   * Maximum attempts to restart a given container before giving up (default value is 0, which is ignored).
   * @return maxAttempts
  **/
  @JsonProperty("MaxAttempts")
  public Long getMaxAttempts() {
    return maxAttempts;
  }

  public void setMaxAttempts(Long maxAttempts) {
    this.maxAttempts = maxAttempts;
  }

  public TaskSpecRestartPolicy maxAttempts(Long maxAttempts) {
    this.maxAttempts = maxAttempts;
    return this;
  }

 /**
   * Windows is the time window used to evaluate the restart policy (default value is 0, which is unbounded).
   * @return window
  **/
  @JsonProperty("Window")
  public Long getWindow() {
    return window;
  }

  public void setWindow(Long window) {
    this.window = window;
  }

  public TaskSpecRestartPolicy window(Long window) {
    this.window = window;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TaskSpecRestartPolicy {\n");
    
    sb.append("    condition: ").append(toIndentedString(condition)).append("\n");
    sb.append("    delay: ").append(toIndentedString(delay)).append("\n");
    sb.append("    maxAttempts: ").append(toIndentedString(maxAttempts)).append("\n");
    sb.append("    window: ").append(toIndentedString(window)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

