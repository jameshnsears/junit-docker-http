package io.swagger.model;

import io.swagger.model.Platform;
import io.swagger.model.TaskSpecPlacementPreferences;
import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class TaskSpecPlacement  {
  
  @ApiModelProperty(example = "[\"node.hostname!=node3.corp.example.com\",\"node.role!=manager\",\"node.labels.type==production\"]", value = "An array of constraints.")
 /**
   * An array of constraints.  
  **/
  private List<String> constraints = null;

  @ApiModelProperty(example = "[{\"Spread\":{\"SpreadDescriptor\":\"node.labels.datacenter\"}},{\"Spread\":{\"SpreadDescriptor\":\"node.labels.rack\"}}]", value = "Preferences provide a way to make the scheduler aware of factors such as topology. They are provided in order from highest to lowest precedence.")
 /**
   * Preferences provide a way to make the scheduler aware of factors such as topology. They are provided in order from highest to lowest precedence.  
  **/
  private List<TaskSpecPlacementPreferences> preferences = null;

  @ApiModelProperty(value = "Platforms stores all the platforms that the service's image can run on. This field is used in the platform filter for scheduling. If empty, then the platform filter is off, meaning there are no scheduling restrictions. ")
 /**
   * Platforms stores all the platforms that the service's image can run on. This field is used in the platform filter for scheduling. If empty, then the platform filter is off, meaning there are no scheduling restrictions.   
  **/
  private List<Platform> platforms = null;
 /**
   * An array of constraints.
   * @return constraints
  **/
  @JsonProperty("Constraints")
  public List<String> getConstraints() {
    return constraints;
  }

  public void setConstraints(List<String> constraints) {
    this.constraints = constraints;
  }

  public TaskSpecPlacement constraints(List<String> constraints) {
    this.constraints = constraints;
    return this;
  }

  public TaskSpecPlacement addConstraintsItem(String constraintsItem) {
    this.constraints.add(constraintsItem);
    return this;
  }

 /**
   * Preferences provide a way to make the scheduler aware of factors such as topology. They are provided in order from highest to lowest precedence.
   * @return preferences
  **/
  @JsonProperty("Preferences")
  public List<TaskSpecPlacementPreferences> getPreferences() {
    return preferences;
  }

  public void setPreferences(List<TaskSpecPlacementPreferences> preferences) {
    this.preferences = preferences;
  }

  public TaskSpecPlacement preferences(List<TaskSpecPlacementPreferences> preferences) {
    this.preferences = preferences;
    return this;
  }

  public TaskSpecPlacement addPreferencesItem(TaskSpecPlacementPreferences preferencesItem) {
    this.preferences.add(preferencesItem);
    return this;
  }

 /**
   * Platforms stores all the platforms that the service&#39;s image can run on. This field is used in the platform filter for scheduling. If empty, then the platform filter is off, meaning there are no scheduling restrictions. 
   * @return platforms
  **/
  @JsonProperty("Platforms")
  public List<Platform> getPlatforms() {
    return platforms;
  }

  public void setPlatforms(List<Platform> platforms) {
    this.platforms = platforms;
  }

  public TaskSpecPlacement platforms(List<Platform> platforms) {
    this.platforms = platforms;
    return this;
  }

  public TaskSpecPlacement addPlatformsItem(Platform platformsItem) {
    this.platforms.add(platformsItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TaskSpecPlacement {\n");
    
    sb.append("    constraints: ").append(toIndentedString(constraints)).append("\n");
    sb.append("    preferences: ").append(toIndentedString(preferences)).append("\n");
    sb.append("    platforms: ").append(toIndentedString(platforms)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

