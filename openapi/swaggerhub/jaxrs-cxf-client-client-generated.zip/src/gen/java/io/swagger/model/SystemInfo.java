package io.swagger.model;

import io.swagger.model.Commit;
import io.swagger.model.GenericResources;
import io.swagger.model.PluginsInfo;
import io.swagger.model.RegistryServiceConfig;
import io.swagger.model.Runtime;
import io.swagger.model.SwarmInfo;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class SystemInfo  {
  
  @ApiModelProperty(example = "7TRN:IPZB:QYBB:VPBQ:UMPP:KARE:6ZNR:XE6T:7EWV:PKF4:ZOJD:TPYS", value = "Unique identifier of the daemon.  <p><br /></p>  > **Note**: The format of the ID itself is not part of the API, and > should not be considered stable. ")
 /**
   * Unique identifier of the daemon.  <p><br /></p>  > **Note**: The format of the ID itself is not part of the API, and > should not be considered stable.   
  **/
  private String ID = null;

  @ApiModelProperty(example = "14", value = "Total number of containers on the host.")
 /**
   * Total number of containers on the host.  
  **/
  private Integer containers = null;

  @ApiModelProperty(example = "3", value = "Number of containers with status `\"running\"`. ")
 /**
   * Number of containers with status `\"running\"`.   
  **/
  private Integer containersRunning = null;

  @ApiModelProperty(example = "1", value = "Number of containers with status `\"paused\"`. ")
 /**
   * Number of containers with status `\"paused\"`.   
  **/
  private Integer containersPaused = null;

  @ApiModelProperty(example = "10", value = "Number of containers with status `\"stopped\"`. ")
 /**
   * Number of containers with status `\"stopped\"`.   
  **/
  private Integer containersStopped = null;

  @ApiModelProperty(example = "508", value = "Total number of images on the host.  Both _tagged_ and _untagged_ (dangling) images are counted. ")
 /**
   * Total number of images on the host.  Both _tagged_ and _untagged_ (dangling) images are counted.   
  **/
  private Integer images = null;

  @ApiModelProperty(example = "overlay2", value = "Name of the storage driver in use.")
 /**
   * Name of the storage driver in use.  
  **/
  private String driver = null;

  @ApiModelProperty(example = "[[\"Backing Filesystem\",\"extfs\"],[\"Supports d_type\",\"true\"],[\"Native Overlay Diff\",\"true\"]]", value = "Information specific to the storage driver, provided as \"label\" / \"value\" pairs.  This information is provided by the storage driver, and formatted in a way consistent with the output of `docker info` on the command line.  <p><br /></p>  > **Note**: The information returned in this field, including the > formatting of values and labels, should not be considered stable, > and may change without notice. ")
 /**
   * Information specific to the storage driver, provided as \"label\" / \"value\" pairs.  This information is provided by the storage driver, and formatted in a way consistent with the output of `docker info` on the command line.  <p><br /></p>  > **Note**: The information returned in this field, including the > formatting of values and labels, should not be considered stable, > and may change without notice.   
  **/
  private List<List<String>> driverStatus = null;

  @ApiModelProperty(example = "/var/lib/docker", value = "Root directory of persistent Docker state.  Defaults to `/var/lib/docker` on Linux, and `C:\\ProgramData\\docker` on Windows. ")
 /**
   * Root directory of persistent Docker state.  Defaults to `/var/lib/docker` on Linux, and `C:\\ProgramData\\docker` on Windows.   
  **/
  private String dockerRootDir = null;

  @ApiModelProperty(example = "[[\"Role\",\"primary\"],[\"State\",\"Healthy\"],[\"Strategy\",\"spread\"],[\"Filters\",\"health, port, containerslots, dependency, affinity, constraint, whitelist\"],[\"Nodes\",\"2\"],[\" swarm-agent-00\",\"192.168.99.102:2376\"],[\"  └ ID\",\"5CT6:FBGO:RVGO:CZL4:PB2K:WCYN:2JSV:KSHH:GGFW:QOPG:6J5Q:IOZ2|192.168.99.102:2376\"],[\"  └ Status\",\"Healthy\"],[\"  └ Containers\",\"1 (1 Running, 0 Paused, 0 Stopped)\"],[\"  └ Reserved CPUs\",\"0 / 1\"],[\"  └ Reserved Memory\",\"0 B / 1.021 GiB\"],[\"  └ Labels\",\"kernelversion=4.4.74-boot2docker, operatingsystem=Boot2Docker 17.06.0-ce (TCL 7.2); HEAD : 0672754 - Thu Jun 29 00:06:31 UTC 2017, ostype=linux, provider=virtualbox, storagedriver=aufs\"],[\"  └ UpdatedAt\",\"2017-08-09T10:03:46Z\"],[\"  └ ServerVersion\",\"17.06.0-ce\"],[\" swarm-manager\",\"192.168.99.101:2376\"],[\"  └ ID\",\"TAMD:7LL3:SEF7:LW2W:4Q2X:WVFH:RTXX:JSYS:XY2P:JEHL:ZMJK:JGIW|192.168.99.101:2376\"],[\"  └ Status\",\"Healthy\"],[\"  └ Containers\",\"2 (2 Running, 0 Paused, 0 Stopped)\"],[\"  └ Reserved CPUs\",\"0 / 1\"],[\"  └ Reserved Memory\",\"0 B / 1.021 GiB\"],[\"  └ Labels\",\"kernelversion=4.4.74-boot2docker, operatingsystem=Boot2Docker 17.06.0-ce (TCL 7.2); HEAD : 0672754 - Thu Jun 29 00:06:31 UTC 2017, ostype=linux, provider=virtualbox, storagedriver=aufs\"],[\"  └ UpdatedAt\",\"2017-08-09T10:04:11Z\"],[\"  └ ServerVersion\",\"17.06.0-ce\"]]", value = "Status information about this node (standalone Swarm API).  <p><br /></p>  > **Note**: The information returned in this field is only propagated > by the Swarm standalone API, and is empty (`null`) when using > built-in swarm mode. ")
 /**
   * Status information about this node (standalone Swarm API).  <p><br /></p>  > **Note**: The information returned in this field is only propagated > by the Swarm standalone API, and is empty (`null`) when using > built-in swarm mode.   
  **/
  private List<List<String>> systemStatus = null;

  @ApiModelProperty(value = "")
  private PluginsInfo plugins = null;

  @ApiModelProperty(example = "true", value = "Indicates if the host has memory limit support enabled.")
 /**
   * Indicates if the host has memory limit support enabled.  
  **/
  private Boolean memoryLimit = null;

  @ApiModelProperty(example = "true", value = "Indicates if the host has memory swap limit support enabled.")
 /**
   * Indicates if the host has memory swap limit support enabled.  
  **/
  private Boolean swapLimit = null;

  @ApiModelProperty(example = "true", value = "Indicates if the host has kernel memory limit support enabled.")
 /**
   * Indicates if the host has kernel memory limit support enabled.  
  **/
  private Boolean kernelMemory = null;

  @ApiModelProperty(example = "true", value = "Indicates if CPU CFS(Completely Fair Scheduler) period is supported by the host.")
 /**
   * Indicates if CPU CFS(Completely Fair Scheduler) period is supported by the host.  
  **/
  private Boolean cpuCfsPeriod = null;

  @ApiModelProperty(example = "true", value = "Indicates if CPU CFS(Completely Fair Scheduler) quota is supported by the host.")
 /**
   * Indicates if CPU CFS(Completely Fair Scheduler) quota is supported by the host.  
  **/
  private Boolean cpuCfsQuota = null;

  @ApiModelProperty(example = "true", value = "Indicates if CPU Shares limiting is supported by the host.")
 /**
   * Indicates if CPU Shares limiting is supported by the host.  
  **/
  private Boolean cpUShares = null;

  @ApiModelProperty(example = "true", value = "Indicates if CPUsets (cpuset.cpus, cpuset.mems) are supported by the host.  See [cpuset(7)](https://www.kernel.org/doc/Documentation/cgroup-v1/cpusets.txt) ")
 /**
   * Indicates if CPUsets (cpuset.cpus, cpuset.mems) are supported by the host.  See [cpuset(7)](https://www.kernel.org/doc/Documentation/cgroup-v1/cpusets.txt)   
  **/
  private Boolean cpUSet = null;

  @ApiModelProperty(value = "Indicates if OOM killer disable is supported on the host.")
 /**
   * Indicates if OOM killer disable is supported on the host.  
  **/
  private Boolean oomKillDisable = null;

  @ApiModelProperty(example = "true", value = "Indicates IPv4 forwarding is enabled.")
 /**
   * Indicates IPv4 forwarding is enabled.  
  **/
  private Boolean ipv4Forwarding = null;

  @ApiModelProperty(example = "true", value = "Indicates if `bridge-nf-call-iptables` is available on the host.")
 /**
   * Indicates if `bridge-nf-call-iptables` is available on the host.  
  **/
  private Boolean bridgeNfIptables = null;

  @ApiModelProperty(example = "true", value = "Indicates if `bridge-nf-call-ip6tables` is available on the host.")
 /**
   * Indicates if `bridge-nf-call-ip6tables` is available on the host.  
  **/
  private Boolean bridgeNfIp6tables = null;

  @ApiModelProperty(example = "true", value = "Indicates if the daemon is running in debug-mode / with debug-level logging enabled.")
 /**
   * Indicates if the daemon is running in debug-mode / with debug-level logging enabled.  
  **/
  private Boolean debug = null;

  @ApiModelProperty(example = "64", value = "The total number of file Descriptors in use by the daemon process.  This information is only returned if debug-mode is enabled. ")
 /**
   * The total number of file Descriptors in use by the daemon process.  This information is only returned if debug-mode is enabled.   
  **/
  private Integer nfd = null;

  @ApiModelProperty(example = "174", value = "The  number of goroutines that currently exist.  This information is only returned if debug-mode is enabled. ")
 /**
   * The  number of goroutines that currently exist.  This information is only returned if debug-mode is enabled.   
  **/
  private Integer ngoroutines = null;

  @ApiModelProperty(example = "2017-08-08T20:28:29.06202363Z", value = "Current system-time in [RFC 3339](https://www.ietf.org/rfc/rfc3339.txt) format with nano-seconds. ")
 /**
   * Current system-time in [RFC 3339](https://www.ietf.org/rfc/rfc3339.txt) format with nano-seconds.   
  **/
  private String systemTime = null;

  @ApiModelProperty(value = "The logging driver to use as a default for new containers. ")
 /**
   * The logging driver to use as a default for new containers.   
  **/
  private String loggingDriver = null;


@XmlType(name="CgroupDriverEnum")
@XmlEnum(String.class)
public enum CgroupDriverEnum {

@XmlEnumValue("cgroupfs") CGROUPFS(String.valueOf("cgroupfs")), @XmlEnumValue("systemd") SYSTEMD(String.valueOf("systemd"));


    private String value;

    CgroupDriverEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static CgroupDriverEnum fromValue(String v) {
        for (CgroupDriverEnum b : CgroupDriverEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(example = "cgroupfs", value = "The driver to use for managing cgroups. ")
 /**
   * The driver to use for managing cgroups.   
  **/
  private CgroupDriverEnum cgroupDriver = CgroupDriverEnum.CGROUPFS;

  @ApiModelProperty(example = "30", value = "Number of event listeners subscribed.")
 /**
   * Number of event listeners subscribed.  
  **/
  private Integer neventsListener = null;

  @ApiModelProperty(example = "4.9.38-moby", value = "Kernel version of the host.  On Linux, this information obtained from `uname`. On Windows this information is queried from the <kbd>HKEY_LOCAL_MACHINE\\\\SOFTWARE\\\\Microsoft\\\\Windows NT\\\\CurrentVersion\\\\</kbd> registry value, for example _\"10.0 14393 (14393.1198.amd64fre.rs1_release_sec.170427-1353)\"_. ")
 /**
   * Kernel version of the host.  On Linux, this information obtained from `uname`. On Windows this information is queried from the <kbd>HKEY_LOCAL_MACHINE\\\\SOFTWARE\\\\Microsoft\\\\Windows NT\\\\CurrentVersion\\\\</kbd> registry value, for example _\"10.0 14393 (14393.1198.amd64fre.rs1_release_sec.170427-1353)\"_.   
  **/
  private String kernelVersion = null;

  @ApiModelProperty(example = "Alpine Linux v3.5", value = "Name of the host's operating system, for example: \"Ubuntu 16.04.2 LTS\" or \"Windows Server 2016 Datacenter\" ")
 /**
   * Name of the host's operating system, for example: \"Ubuntu 16.04.2 LTS\" or \"Windows Server 2016 Datacenter\"   
  **/
  private String operatingSystem = null;

  @ApiModelProperty(example = "linux", value = "Generic type of the operating system of the host, as returned by the Go runtime (`GOOS`).  Currently returned values are \"linux\" and \"windows\". A full list of possible values can be found in the [Go documentation](https://golang.org/doc/install/source#environment). ")
 /**
   * Generic type of the operating system of the host, as returned by the Go runtime (`GOOS`).  Currently returned values are \"linux\" and \"windows\". A full list of possible values can be found in the [Go documentation](https://golang.org/doc/install/source#environment).   
  **/
  private String osType = null;

  @ApiModelProperty(example = "x86_64", value = "Hardware architecture of the host, as returned by the Go runtime (`GOARCH`).  A full list of possible values can be found in the [Go documentation](https://golang.org/doc/install/source#environment). ")
 /**
   * Hardware architecture of the host, as returned by the Go runtime (`GOARCH`).  A full list of possible values can be found in the [Go documentation](https://golang.org/doc/install/source#environment).   
  **/
  private String architecture = null;

  @ApiModelProperty(example = "4", value = "The number of logical CPUs usable by the daemon.  The number of available CPUs is checked by querying the operating system when the daemon starts. Changes to operating system CPU allocation after the daemon is started are not reflected. ")
 /**
   * The number of logical CPUs usable by the daemon.  The number of available CPUs is checked by querying the operating system when the daemon starts. Changes to operating system CPU allocation after the daemon is started are not reflected.   
  **/
  private Integer NCPU = null;

  @ApiModelProperty(example = "2095882240", value = "Total amount of physical memory available on the host, in kilobytes (kB). ")
 /**
   * Total amount of physical memory available on the host, in kilobytes (kB).   
  **/
  private Long memTotal = null;

  @ApiModelProperty(example = "https://index.docker.io/v1/", value = "Address / URL of the index server that is used for image search, and as a default for user authentication for Docker Hub and Docker Cloud. ")
 /**
   * Address / URL of the index server that is used for image search, and as a default for user authentication for Docker Hub and Docker Cloud.   
  **/
  private String indexServerAddress = "https://index.docker.io/v1/";

  @ApiModelProperty(value = "")
  private RegistryServiceConfig registryConfig = null;

  @ApiModelProperty(value = "")
  private GenericResources genericResources = null;

  @ApiModelProperty(example = "http://xxxxx:xxxxx@proxy.corp.example.com:8080", value = "HTTP-proxy configured for the daemon. This value is obtained from the [`HTTP_PROXY`](https://www.gnu.org/software/wget/manual/html_node/Proxies.html) environment variable. Credentials ([user info component](https://tools.ietf.org/html/rfc3986#section-3.2.1)) in the proxy URL are masked in the API response.  Containers do not automatically inherit this configuration. ")
 /**
   * HTTP-proxy configured for the daemon. This value is obtained from the [`HTTP_PROXY`](https://www.gnu.org/software/wget/manual/html_node/Proxies.html) environment variable. Credentials ([user info component](https://tools.ietf.org/html/rfc3986#section-3.2.1)) in the proxy URL are masked in the API response.  Containers do not automatically inherit this configuration.   
  **/
  private String httpProxy = null;

  @ApiModelProperty(example = "https://xxxxx:xxxxx@proxy.corp.example.com:4443", value = "HTTPS-proxy configured for the daemon. This value is obtained from the [`HTTPS_PROXY`](https://www.gnu.org/software/wget/manual/html_node/Proxies.html) environment variable. Credentials ([user info component](https://tools.ietf.org/html/rfc3986#section-3.2.1)) in the proxy URL are masked in the API response.  Containers do not automatically inherit this configuration. ")
 /**
   * HTTPS-proxy configured for the daemon. This value is obtained from the [`HTTPS_PROXY`](https://www.gnu.org/software/wget/manual/html_node/Proxies.html) environment variable. Credentials ([user info component](https://tools.ietf.org/html/rfc3986#section-3.2.1)) in the proxy URL are masked in the API response.  Containers do not automatically inherit this configuration.   
  **/
  private String httpsProxy = null;

  @ApiModelProperty(example = "*.local, 169.254/16", value = "Comma-separated list of domain extensions for which no proxy should be used. This value is obtained from the [`NO_PROXY`](https://www.gnu.org/software/wget/manual/html_node/Proxies.html) environment variable.  Containers do not automatically inherit this configuration. ")
 /**
   * Comma-separated list of domain extensions for which no proxy should be used. This value is obtained from the [`NO_PROXY`](https://www.gnu.org/software/wget/manual/html_node/Proxies.html) environment variable.  Containers do not automatically inherit this configuration.   
  **/
  private String noProxy = null;

  @ApiModelProperty(example = "node5.corp.example.com", value = "Hostname of the host.")
 /**
   * Hostname of the host.  
  **/
  private String name = null;

  @ApiModelProperty(example = "[\"storage=ssd\",\"production\"]", value = "User-defined labels (key/value metadata) as set on the daemon.  <p><br /></p>  > **Note**: When part of a Swarm, nodes can both have _daemon_ labels, > set through the daemon configuration, and _node_ labels, set from a > manager node in the Swarm. Node labels are not included in this > field. Node labels can be retrieved using the `/nodes/(id)` endpoint > on a manager node in the Swarm. ")
 /**
   * User-defined labels (key/value metadata) as set on the daemon.  <p><br /></p>  > **Note**: When part of a Swarm, nodes can both have _daemon_ labels, > set through the daemon configuration, and _node_ labels, set from a > manager node in the Swarm. Node labels are not included in this > field. Node labels can be retrieved using the `/nodes/(id)` endpoint > on a manager node in the Swarm.   
  **/
  private List<String> labels = null;

  @ApiModelProperty(example = "true", value = "Indicates if experimental features are enabled on the daemon. ")
 /**
   * Indicates if experimental features are enabled on the daemon.   
  **/
  private Boolean experimentalBuild = null;

  @ApiModelProperty(example = "17.06.0-ce", value = "Version string of the daemon.  > **Note**: the [standalone Swarm API](https://docs.docker.com/swarm/swarm-api/) > returns the Swarm version instead of the daemon  version, for example > `swarm/1.2.8`. ")
 /**
   * Version string of the daemon.  > **Note**: the [standalone Swarm API](https://docs.docker.com/swarm/swarm-api/) > returns the Swarm version instead of the daemon  version, for example > `swarm/1.2.8`.   
  **/
  private String serverVersion = null;

  @ApiModelProperty(example = "consul://consul.corp.example.com:8600/some/path", value = "URL of the distributed storage backend.   The storage backend is used for multihost networking (to store network and endpoint information) and by the node discovery mechanism.  <p><br /></p>  > **Note**: This field is only propagated when using standalone Swarm > mode, and overlay networking using an external k/v store. Overlay > networks with Swarm mode enabled use the built-in raft store, and > this field will be empty. ")
 /**
   * URL of the distributed storage backend.   The storage backend is used for multihost networking (to store network and endpoint information) and by the node discovery mechanism.  <p><br /></p>  > **Note**: This field is only propagated when using standalone Swarm > mode, and overlay networking using an external k/v store. Overlay > networks with Swarm mode enabled use the built-in raft store, and > this field will be empty.   
  **/
  private String clusterStore = null;

  @ApiModelProperty(example = "node5.corp.example.com:8000", value = "The network endpoint that the Engine advertises for the purpose of node discovery. ClusterAdvertise is a `host:port` combination on which the daemon is reachable by other hosts.  <p><br /></p>  > **Note**: This field is only propagated when using standalone Swarm > mode, and overlay networking using an external k/v store. Overlay > networks with Swarm mode enabled use the built-in raft store, and > this field will be empty. ")
 /**
   * The network endpoint that the Engine advertises for the purpose of node discovery. ClusterAdvertise is a `host:port` combination on which the daemon is reachable by other hosts.  <p><br /></p>  > **Note**: This field is only propagated when using standalone Swarm > mode, and overlay networking using an external k/v store. Overlay > networks with Swarm mode enabled use the built-in raft store, and > this field will be empty.   
  **/
  private String clusterAdvertise = null;

  @ApiModelProperty(example = "{\"runc\":{\"path\":\"runc\"},\"runc-master\":{\"path\":\"/go/bin/runc\"},\"custom\":{\"path\":\"/usr/local/bin/my-oci-runtime\",\"runtimeArgs\":[\"--debug\",\"--systemd-cgroup=false\"]}}", value = "List of [OCI compliant](https://github.com/opencontainers/runtime-spec) runtimes configured on the daemon. Keys hold the \"name\" used to reference the runtime.  The Docker daemon relies on an OCI compliant runtime (invoked via the `containerd` daemon) as its interface to the Linux kernel namespaces, cgroups, and SELinux.  The default runtime is `runc`, and automatically configured. Additional runtimes can be configured by the user and will be listed here. ")
 /**
   * List of [OCI compliant](https://github.com/opencontainers/runtime-spec) runtimes configured on the daemon. Keys hold the \"name\" used to reference the runtime.  The Docker daemon relies on an OCI compliant runtime (invoked via the `containerd` daemon) as its interface to the Linux kernel namespaces, cgroups, and SELinux.  The default runtime is `runc`, and automatically configured. Additional runtimes can be configured by the user and will be listed here.   
  **/
  private Map<String, Runtime> runtimes = null;

  @ApiModelProperty(example = "runc", value = "Name of the default OCI runtime that is used when starting containers.  The default can be overridden per-container at create time. ")
 /**
   * Name of the default OCI runtime that is used when starting containers.  The default can be overridden per-container at create time.   
  **/
  private String defaultRuntime = "runc";

  @ApiModelProperty(value = "")
  private SwarmInfo swarm = null;

  @ApiModelProperty(example = "false", value = "Indicates if live restore is enabled.  If enabled, containers are kept running when the daemon is shutdown or upon daemon start if running containers are detected. ")
 /**
   * Indicates if live restore is enabled.  If enabled, containers are kept running when the daemon is shutdown or upon daemon start if running containers are detected.   
  **/
  private Boolean liveRestoreEnabled = false;


@XmlType(name="IsolationEnum")
@XmlEnum(String.class)
public enum IsolationEnum {

@XmlEnumValue("default") DEFAULT(String.valueOf("default")), @XmlEnumValue("hyperv") HYPERV(String.valueOf("hyperv")), @XmlEnumValue("process") PROCESS(String.valueOf("process"));


    private String value;

    IsolationEnum (String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static IsolationEnum fromValue(String v) {
        for (IsolationEnum b : IsolationEnum.values()) {
            if (String.valueOf(b.value).equals(v)) {
                return b;
            }
        }
        return null;
    }
}

  @ApiModelProperty(value = "Represents the isolation technology to use as a default for containers. The supported values are platform-specific.  If no isolation value is specified on daemon start, on Windows client, the default is `hyperv`, and on Windows server, the default is `process`.  This option is currently not used on other platforms. ")
 /**
   * Represents the isolation technology to use as a default for containers. The supported values are platform-specific.  If no isolation value is specified on daemon start, on Windows client, the default is `hyperv`, and on Windows server, the default is `process`.  This option is currently not used on other platforms.   
  **/
  private IsolationEnum isolation = IsolationEnum.DEFAULT;

  @ApiModelProperty(example = "docker-init", value = "Name and, optional, path of the `docker-init` binary.  If the path is omitted, the daemon searches the host's `$PATH` for the binary and uses the first result. ")
 /**
   * Name and, optional, path of the `docker-init` binary.  If the path is omitted, the daemon searches the host's `$PATH` for the binary and uses the first result.   
  **/
  private String initBinary = null;

  @ApiModelProperty(value = "")
  private Commit containerdCommit = null;

  @ApiModelProperty(value = "")
  private Commit runcCommit = null;

  @ApiModelProperty(value = "")
  private Commit initCommit = null;

  @ApiModelProperty(example = "[\"name=apparmor\",\"name=seccomp,profile=default\",\"name=selinux\",\"name=userns\"]", value = "List of security features that are enabled on the daemon, such as apparmor, seccomp, SELinux, and user-namespaces (userns).  Additional configuration options for each security feature may be present, and are included as a comma-separated list of key/value pairs. ")
 /**
   * List of security features that are enabled on the daemon, such as apparmor, seccomp, SELinux, and user-namespaces (userns).  Additional configuration options for each security feature may be present, and are included as a comma-separated list of key/value pairs.   
  **/
  private List<String> securityOptions = null;

  @ApiModelProperty(example = "Community Engine", value = "Reports a summary of the product license on the daemon.  If a commercial license has been applied to the daemon, information such as number of nodes, and expiration are included. ")
 /**
   * Reports a summary of the product license on the daemon.  If a commercial license has been applied to the daemon, information such as number of nodes, and expiration are included.   
  **/
  private String productLicense = null;

  @ApiModelProperty(example = "[\"WARNING: No memory limit support\",\"WARNING: bridge-nf-call-iptables is disabled\",\"WARNING: bridge-nf-call-ip6tables is disabled\"]", value = "List of warnings / informational messages about missing features, or issues related to the daemon configuration.  These messages can be printed by the client as information to the user. ")
 /**
   * List of warnings / informational messages about missing features, or issues related to the daemon configuration.  These messages can be printed by the client as information to the user.   
  **/
  private List<String> warnings = null;
 /**
   * Unique identifier of the daemon.  &lt;p&gt;&lt;br /&gt;&lt;/p&gt;  &gt; **Note**: The format of the ID itself is not part of the API, and &gt; should not be considered stable. 
   * @return ID
  **/
  @JsonProperty("ID")
  public String getID() {
    return ID;
  }

  public void setID(String ID) {
    this.ID = ID;
  }

  public SystemInfo ID(String ID) {
    this.ID = ID;
    return this;
  }

 /**
   * Total number of containers on the host.
   * @return containers
  **/
  @JsonProperty("Containers")
  public Integer getContainers() {
    return containers;
  }

  public void setContainers(Integer containers) {
    this.containers = containers;
  }

  public SystemInfo containers(Integer containers) {
    this.containers = containers;
    return this;
  }

 /**
   * Number of containers with status &#x60;\&quot;running\&quot;&#x60;. 
   * @return containersRunning
  **/
  @JsonProperty("ContainersRunning")
  public Integer getContainersRunning() {
    return containersRunning;
  }

  public void setContainersRunning(Integer containersRunning) {
    this.containersRunning = containersRunning;
  }

  public SystemInfo containersRunning(Integer containersRunning) {
    this.containersRunning = containersRunning;
    return this;
  }

 /**
   * Number of containers with status &#x60;\&quot;paused\&quot;&#x60;. 
   * @return containersPaused
  **/
  @JsonProperty("ContainersPaused")
  public Integer getContainersPaused() {
    return containersPaused;
  }

  public void setContainersPaused(Integer containersPaused) {
    this.containersPaused = containersPaused;
  }

  public SystemInfo containersPaused(Integer containersPaused) {
    this.containersPaused = containersPaused;
    return this;
  }

 /**
   * Number of containers with status &#x60;\&quot;stopped\&quot;&#x60;. 
   * @return containersStopped
  **/
  @JsonProperty("ContainersStopped")
  public Integer getContainersStopped() {
    return containersStopped;
  }

  public void setContainersStopped(Integer containersStopped) {
    this.containersStopped = containersStopped;
  }

  public SystemInfo containersStopped(Integer containersStopped) {
    this.containersStopped = containersStopped;
    return this;
  }

 /**
   * Total number of images on the host.  Both _tagged_ and _untagged_ (dangling) images are counted. 
   * @return images
  **/
  @JsonProperty("Images")
  public Integer getImages() {
    return images;
  }

  public void setImages(Integer images) {
    this.images = images;
  }

  public SystemInfo images(Integer images) {
    this.images = images;
    return this;
  }

 /**
   * Name of the storage driver in use.
   * @return driver
  **/
  @JsonProperty("Driver")
  public String getDriver() {
    return driver;
  }

  public void setDriver(String driver) {
    this.driver = driver;
  }

  public SystemInfo driver(String driver) {
    this.driver = driver;
    return this;
  }

 /**
   * Information specific to the storage driver, provided as \&quot;label\&quot; / \&quot;value\&quot; pairs.  This information is provided by the storage driver, and formatted in a way consistent with the output of &#x60;docker info&#x60; on the command line.  &lt;p&gt;&lt;br /&gt;&lt;/p&gt;  &gt; **Note**: The information returned in this field, including the &gt; formatting of values and labels, should not be considered stable, &gt; and may change without notice. 
   * @return driverStatus
  **/
  @JsonProperty("DriverStatus")
  public List<List<String>> getDriverStatus() {
    return driverStatus;
  }

  public void setDriverStatus(List<List<String>> driverStatus) {
    this.driverStatus = driverStatus;
  }

  public SystemInfo driverStatus(List<List<String>> driverStatus) {
    this.driverStatus = driverStatus;
    return this;
  }

  public SystemInfo addDriverStatusItem(List<String> driverStatusItem) {
    this.driverStatus.add(driverStatusItem);
    return this;
  }

 /**
   * Root directory of persistent Docker state.  Defaults to &#x60;/var/lib/docker&#x60; on Linux, and &#x60;C:\\ProgramData\\docker&#x60; on Windows. 
   * @return dockerRootDir
  **/
  @JsonProperty("DockerRootDir")
  public String getDockerRootDir() {
    return dockerRootDir;
  }

  public void setDockerRootDir(String dockerRootDir) {
    this.dockerRootDir = dockerRootDir;
  }

  public SystemInfo dockerRootDir(String dockerRootDir) {
    this.dockerRootDir = dockerRootDir;
    return this;
  }

 /**
   * Status information about this node (standalone Swarm API).  &lt;p&gt;&lt;br /&gt;&lt;/p&gt;  &gt; **Note**: The information returned in this field is only propagated &gt; by the Swarm standalone API, and is empty (&#x60;null&#x60;) when using &gt; built-in swarm mode. 
   * @return systemStatus
  **/
  @JsonProperty("SystemStatus")
  public List<List<String>> getSystemStatus() {
    return systemStatus;
  }

  public void setSystemStatus(List<List<String>> systemStatus) {
    this.systemStatus = systemStatus;
  }

  public SystemInfo systemStatus(List<List<String>> systemStatus) {
    this.systemStatus = systemStatus;
    return this;
  }

  public SystemInfo addSystemStatusItem(List<String> systemStatusItem) {
    this.systemStatus.add(systemStatusItem);
    return this;
  }

 /**
   * Get plugins
   * @return plugins
  **/
  @JsonProperty("Plugins")
  public PluginsInfo getPlugins() {
    return plugins;
  }

  public void setPlugins(PluginsInfo plugins) {
    this.plugins = plugins;
  }

  public SystemInfo plugins(PluginsInfo plugins) {
    this.plugins = plugins;
    return this;
  }

 /**
   * Indicates if the host has memory limit support enabled.
   * @return memoryLimit
  **/
  @JsonProperty("MemoryLimit")
  public Boolean isMemoryLimit() {
    return memoryLimit;
  }

  public void setMemoryLimit(Boolean memoryLimit) {
    this.memoryLimit = memoryLimit;
  }

  public SystemInfo memoryLimit(Boolean memoryLimit) {
    this.memoryLimit = memoryLimit;
    return this;
  }

 /**
   * Indicates if the host has memory swap limit support enabled.
   * @return swapLimit
  **/
  @JsonProperty("SwapLimit")
  public Boolean isSwapLimit() {
    return swapLimit;
  }

  public void setSwapLimit(Boolean swapLimit) {
    this.swapLimit = swapLimit;
  }

  public SystemInfo swapLimit(Boolean swapLimit) {
    this.swapLimit = swapLimit;
    return this;
  }

 /**
   * Indicates if the host has kernel memory limit support enabled.
   * @return kernelMemory
  **/
  @JsonProperty("KernelMemory")
  public Boolean isKernelMemory() {
    return kernelMemory;
  }

  public void setKernelMemory(Boolean kernelMemory) {
    this.kernelMemory = kernelMemory;
  }

  public SystemInfo kernelMemory(Boolean kernelMemory) {
    this.kernelMemory = kernelMemory;
    return this;
  }

 /**
   * Indicates if CPU CFS(Completely Fair Scheduler) period is supported by the host.
   * @return cpuCfsPeriod
  **/
  @JsonProperty("CpuCfsPeriod")
  public Boolean isCpuCfsPeriod() {
    return cpuCfsPeriod;
  }

  public void setCpuCfsPeriod(Boolean cpuCfsPeriod) {
    this.cpuCfsPeriod = cpuCfsPeriod;
  }

  public SystemInfo cpuCfsPeriod(Boolean cpuCfsPeriod) {
    this.cpuCfsPeriod = cpuCfsPeriod;
    return this;
  }

 /**
   * Indicates if CPU CFS(Completely Fair Scheduler) quota is supported by the host.
   * @return cpuCfsQuota
  **/
  @JsonProperty("CpuCfsQuota")
  public Boolean isCpuCfsQuota() {
    return cpuCfsQuota;
  }

  public void setCpuCfsQuota(Boolean cpuCfsQuota) {
    this.cpuCfsQuota = cpuCfsQuota;
  }

  public SystemInfo cpuCfsQuota(Boolean cpuCfsQuota) {
    this.cpuCfsQuota = cpuCfsQuota;
    return this;
  }

 /**
   * Indicates if CPU Shares limiting is supported by the host.
   * @return cpUShares
  **/
  @JsonProperty("CPUShares")
  public Boolean isCpUShares() {
    return cpUShares;
  }

  public void setCpUShares(Boolean cpUShares) {
    this.cpUShares = cpUShares;
  }

  public SystemInfo cpUShares(Boolean cpUShares) {
    this.cpUShares = cpUShares;
    return this;
  }

 /**
   * Indicates if CPUsets (cpuset.cpus, cpuset.mems) are supported by the host.  See [cpuset(7)](https://www.kernel.org/doc/Documentation/cgroup-v1/cpusets.txt) 
   * @return cpUSet
  **/
  @JsonProperty("CPUSet")
  public Boolean isCpUSet() {
    return cpUSet;
  }

  public void setCpUSet(Boolean cpUSet) {
    this.cpUSet = cpUSet;
  }

  public SystemInfo cpUSet(Boolean cpUSet) {
    this.cpUSet = cpUSet;
    return this;
  }

 /**
   * Indicates if OOM killer disable is supported on the host.
   * @return oomKillDisable
  **/
  @JsonProperty("OomKillDisable")
  public Boolean isOomKillDisable() {
    return oomKillDisable;
  }

  public void setOomKillDisable(Boolean oomKillDisable) {
    this.oomKillDisable = oomKillDisable;
  }

  public SystemInfo oomKillDisable(Boolean oomKillDisable) {
    this.oomKillDisable = oomKillDisable;
    return this;
  }

 /**
   * Indicates IPv4 forwarding is enabled.
   * @return ipv4Forwarding
  **/
  @JsonProperty("IPv4Forwarding")
  public Boolean isIpv4Forwarding() {
    return ipv4Forwarding;
  }

  public void setIpv4Forwarding(Boolean ipv4Forwarding) {
    this.ipv4Forwarding = ipv4Forwarding;
  }

  public SystemInfo ipv4Forwarding(Boolean ipv4Forwarding) {
    this.ipv4Forwarding = ipv4Forwarding;
    return this;
  }

 /**
   * Indicates if &#x60;bridge-nf-call-iptables&#x60; is available on the host.
   * @return bridgeNfIptables
  **/
  @JsonProperty("BridgeNfIptables")
  public Boolean isBridgeNfIptables() {
    return bridgeNfIptables;
  }

  public void setBridgeNfIptables(Boolean bridgeNfIptables) {
    this.bridgeNfIptables = bridgeNfIptables;
  }

  public SystemInfo bridgeNfIptables(Boolean bridgeNfIptables) {
    this.bridgeNfIptables = bridgeNfIptables;
    return this;
  }

 /**
   * Indicates if &#x60;bridge-nf-call-ip6tables&#x60; is available on the host.
   * @return bridgeNfIp6tables
  **/
  @JsonProperty("BridgeNfIp6tables")
  public Boolean isBridgeNfIp6tables() {
    return bridgeNfIp6tables;
  }

  public void setBridgeNfIp6tables(Boolean bridgeNfIp6tables) {
    this.bridgeNfIp6tables = bridgeNfIp6tables;
  }

  public SystemInfo bridgeNfIp6tables(Boolean bridgeNfIp6tables) {
    this.bridgeNfIp6tables = bridgeNfIp6tables;
    return this;
  }

 /**
   * Indicates if the daemon is running in debug-mode / with debug-level logging enabled.
   * @return debug
  **/
  @JsonProperty("Debug")
  public Boolean isDebug() {
    return debug;
  }

  public void setDebug(Boolean debug) {
    this.debug = debug;
  }

  public SystemInfo debug(Boolean debug) {
    this.debug = debug;
    return this;
  }

 /**
   * The total number of file Descriptors in use by the daemon process.  This information is only returned if debug-mode is enabled. 
   * @return nfd
  **/
  @JsonProperty("NFd")
  public Integer getNfd() {
    return nfd;
  }

  public void setNfd(Integer nfd) {
    this.nfd = nfd;
  }

  public SystemInfo nfd(Integer nfd) {
    this.nfd = nfd;
    return this;
  }

 /**
   * The  number of goroutines that currently exist.  This information is only returned if debug-mode is enabled. 
   * @return ngoroutines
  **/
  @JsonProperty("NGoroutines")
  public Integer getNgoroutines() {
    return ngoroutines;
  }

  public void setNgoroutines(Integer ngoroutines) {
    this.ngoroutines = ngoroutines;
  }

  public SystemInfo ngoroutines(Integer ngoroutines) {
    this.ngoroutines = ngoroutines;
    return this;
  }

 /**
   * Current system-time in [RFC 3339](https://www.ietf.org/rfc/rfc3339.txt) format with nano-seconds. 
   * @return systemTime
  **/
  @JsonProperty("SystemTime")
  public String getSystemTime() {
    return systemTime;
  }

  public void setSystemTime(String systemTime) {
    this.systemTime = systemTime;
  }

  public SystemInfo systemTime(String systemTime) {
    this.systemTime = systemTime;
    return this;
  }

 /**
   * The logging driver to use as a default for new containers. 
   * @return loggingDriver
  **/
  @JsonProperty("LoggingDriver")
  public String getLoggingDriver() {
    return loggingDriver;
  }

  public void setLoggingDriver(String loggingDriver) {
    this.loggingDriver = loggingDriver;
  }

  public SystemInfo loggingDriver(String loggingDriver) {
    this.loggingDriver = loggingDriver;
    return this;
  }

 /**
   * The driver to use for managing cgroups. 
   * @return cgroupDriver
  **/
  @JsonProperty("CgroupDriver")
  public String getCgroupDriver() {
    if (cgroupDriver == null) {
      return null;
    }
    return cgroupDriver.value();
  }

  public void setCgroupDriver(CgroupDriverEnum cgroupDriver) {
    this.cgroupDriver = cgroupDriver;
  }

  public SystemInfo cgroupDriver(CgroupDriverEnum cgroupDriver) {
    this.cgroupDriver = cgroupDriver;
    return this;
  }

 /**
   * Number of event listeners subscribed.
   * @return neventsListener
  **/
  @JsonProperty("NEventsListener")
  public Integer getNeventsListener() {
    return neventsListener;
  }

  public void setNeventsListener(Integer neventsListener) {
    this.neventsListener = neventsListener;
  }

  public SystemInfo neventsListener(Integer neventsListener) {
    this.neventsListener = neventsListener;
    return this;
  }

 /**
   * Kernel version of the host.  On Linux, this information obtained from &#x60;uname&#x60;. On Windows this information is queried from the &lt;kbd&gt;HKEY_LOCAL_MACHINE\\\\SOFTWARE\\\\Microsoft\\\\Windows NT\\\\CurrentVersion\\\\&lt;/kbd&gt; registry value, for example _\&quot;10.0 14393 (14393.1198.amd64fre.rs1_release_sec.170427-1353)\&quot;_. 
   * @return kernelVersion
  **/
  @JsonProperty("KernelVersion")
  public String getKernelVersion() {
    return kernelVersion;
  }

  public void setKernelVersion(String kernelVersion) {
    this.kernelVersion = kernelVersion;
  }

  public SystemInfo kernelVersion(String kernelVersion) {
    this.kernelVersion = kernelVersion;
    return this;
  }

 /**
   * Name of the host&#39;s operating system, for example: \&quot;Ubuntu 16.04.2 LTS\&quot; or \&quot;Windows Server 2016 Datacenter\&quot; 
   * @return operatingSystem
  **/
  @JsonProperty("OperatingSystem")
  public String getOperatingSystem() {
    return operatingSystem;
  }

  public void setOperatingSystem(String operatingSystem) {
    this.operatingSystem = operatingSystem;
  }

  public SystemInfo operatingSystem(String operatingSystem) {
    this.operatingSystem = operatingSystem;
    return this;
  }

 /**
   * Generic type of the operating system of the host, as returned by the Go runtime (&#x60;GOOS&#x60;).  Currently returned values are \&quot;linux\&quot; and \&quot;windows\&quot;. A full list of possible values can be found in the [Go documentation](https://golang.org/doc/install/source#environment). 
   * @return osType
  **/
  @JsonProperty("OSType")
  public String getOsType() {
    return osType;
  }

  public void setOsType(String osType) {
    this.osType = osType;
  }

  public SystemInfo osType(String osType) {
    this.osType = osType;
    return this;
  }

 /**
   * Hardware architecture of the host, as returned by the Go runtime (&#x60;GOARCH&#x60;).  A full list of possible values can be found in the [Go documentation](https://golang.org/doc/install/source#environment). 
   * @return architecture
  **/
  @JsonProperty("Architecture")
  public String getArchitecture() {
    return architecture;
  }

  public void setArchitecture(String architecture) {
    this.architecture = architecture;
  }

  public SystemInfo architecture(String architecture) {
    this.architecture = architecture;
    return this;
  }

 /**
   * The number of logical CPUs usable by the daemon.  The number of available CPUs is checked by querying the operating system when the daemon starts. Changes to operating system CPU allocation after the daemon is started are not reflected. 
   * @return NCPU
  **/
  @JsonProperty("NCPU")
  public Integer getNCPU() {
    return NCPU;
  }

  public void setNCPU(Integer NCPU) {
    this.NCPU = NCPU;
  }

  public SystemInfo NCPU(Integer NCPU) {
    this.NCPU = NCPU;
    return this;
  }

 /**
   * Total amount of physical memory available on the host, in kilobytes (kB). 
   * @return memTotal
  **/
  @JsonProperty("MemTotal")
  public Long getMemTotal() {
    return memTotal;
  }

  public void setMemTotal(Long memTotal) {
    this.memTotal = memTotal;
  }

  public SystemInfo memTotal(Long memTotal) {
    this.memTotal = memTotal;
    return this;
  }

 /**
   * Address / URL of the index server that is used for image search, and as a default for user authentication for Docker Hub and Docker Cloud. 
   * @return indexServerAddress
  **/
  @JsonProperty("IndexServerAddress")
  public String getIndexServerAddress() {
    return indexServerAddress;
  }

  public void setIndexServerAddress(String indexServerAddress) {
    this.indexServerAddress = indexServerAddress;
  }

  public SystemInfo indexServerAddress(String indexServerAddress) {
    this.indexServerAddress = indexServerAddress;
    return this;
  }

 /**
   * Get registryConfig
   * @return registryConfig
  **/
  @JsonProperty("RegistryConfig")
  public RegistryServiceConfig getRegistryConfig() {
    return registryConfig;
  }

  public void setRegistryConfig(RegistryServiceConfig registryConfig) {
    this.registryConfig = registryConfig;
  }

  public SystemInfo registryConfig(RegistryServiceConfig registryConfig) {
    this.registryConfig = registryConfig;
    return this;
  }

 /**
   * Get genericResources
   * @return genericResources
  **/
  @JsonProperty("GenericResources")
  public GenericResources getGenericResources() {
    return genericResources;
  }

  public void setGenericResources(GenericResources genericResources) {
    this.genericResources = genericResources;
  }

  public SystemInfo genericResources(GenericResources genericResources) {
    this.genericResources = genericResources;
    return this;
  }

 /**
   * HTTP-proxy configured for the daemon. This value is obtained from the [&#x60;HTTP_PROXY&#x60;](https://www.gnu.org/software/wget/manual/html_node/Proxies.html) environment variable. Credentials ([user info component](https://tools.ietf.org/html/rfc3986#section-3.2.1)) in the proxy URL are masked in the API response.  Containers do not automatically inherit this configuration. 
   * @return httpProxy
  **/
  @JsonProperty("HttpProxy")
  public String getHttpProxy() {
    return httpProxy;
  }

  public void setHttpProxy(String httpProxy) {
    this.httpProxy = httpProxy;
  }

  public SystemInfo httpProxy(String httpProxy) {
    this.httpProxy = httpProxy;
    return this;
  }

 /**
   * HTTPS-proxy configured for the daemon. This value is obtained from the [&#x60;HTTPS_PROXY&#x60;](https://www.gnu.org/software/wget/manual/html_node/Proxies.html) environment variable. Credentials ([user info component](https://tools.ietf.org/html/rfc3986#section-3.2.1)) in the proxy URL are masked in the API response.  Containers do not automatically inherit this configuration. 
   * @return httpsProxy
  **/
  @JsonProperty("HttpsProxy")
  public String getHttpsProxy() {
    return httpsProxy;
  }

  public void setHttpsProxy(String httpsProxy) {
    this.httpsProxy = httpsProxy;
  }

  public SystemInfo httpsProxy(String httpsProxy) {
    this.httpsProxy = httpsProxy;
    return this;
  }

 /**
   * Comma-separated list of domain extensions for which no proxy should be used. This value is obtained from the [&#x60;NO_PROXY&#x60;](https://www.gnu.org/software/wget/manual/html_node/Proxies.html) environment variable.  Containers do not automatically inherit this configuration. 
   * @return noProxy
  **/
  @JsonProperty("NoProxy")
  public String getNoProxy() {
    return noProxy;
  }

  public void setNoProxy(String noProxy) {
    this.noProxy = noProxy;
  }

  public SystemInfo noProxy(String noProxy) {
    this.noProxy = noProxy;
    return this;
  }

 /**
   * Hostname of the host.
   * @return name
  **/
  @JsonProperty("Name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public SystemInfo name(String name) {
    this.name = name;
    return this;
  }

 /**
   * User-defined labels (key/value metadata) as set on the daemon.  &lt;p&gt;&lt;br /&gt;&lt;/p&gt;  &gt; **Note**: When part of a Swarm, nodes can both have _daemon_ labels, &gt; set through the daemon configuration, and _node_ labels, set from a &gt; manager node in the Swarm. Node labels are not included in this &gt; field. Node labels can be retrieved using the &#x60;/nodes/(id)&#x60; endpoint &gt; on a manager node in the Swarm. 
   * @return labels
  **/
  @JsonProperty("Labels")
  public List<String> getLabels() {
    return labels;
  }

  public void setLabels(List<String> labels) {
    this.labels = labels;
  }

  public SystemInfo labels(List<String> labels) {
    this.labels = labels;
    return this;
  }

  public SystemInfo addLabelsItem(String labelsItem) {
    this.labels.add(labelsItem);
    return this;
  }

 /**
   * Indicates if experimental features are enabled on the daemon. 
   * @return experimentalBuild
  **/
  @JsonProperty("ExperimentalBuild")
  public Boolean isExperimentalBuild() {
    return experimentalBuild;
  }

  public void setExperimentalBuild(Boolean experimentalBuild) {
    this.experimentalBuild = experimentalBuild;
  }

  public SystemInfo experimentalBuild(Boolean experimentalBuild) {
    this.experimentalBuild = experimentalBuild;
    return this;
  }

 /**
   * Version string of the daemon.  &gt; **Note**: the [standalone Swarm API](https://docs.docker.com/swarm/swarm-api/) &gt; returns the Swarm version instead of the daemon  version, for example &gt; &#x60;swarm/1.2.8&#x60;. 
   * @return serverVersion
  **/
  @JsonProperty("ServerVersion")
  public String getServerVersion() {
    return serverVersion;
  }

  public void setServerVersion(String serverVersion) {
    this.serverVersion = serverVersion;
  }

  public SystemInfo serverVersion(String serverVersion) {
    this.serverVersion = serverVersion;
    return this;
  }

 /**
   * URL of the distributed storage backend.   The storage backend is used for multihost networking (to store network and endpoint information) and by the node discovery mechanism.  &lt;p&gt;&lt;br /&gt;&lt;/p&gt;  &gt; **Note**: This field is only propagated when using standalone Swarm &gt; mode, and overlay networking using an external k/v store. Overlay &gt; networks with Swarm mode enabled use the built-in raft store, and &gt; this field will be empty. 
   * @return clusterStore
  **/
  @JsonProperty("ClusterStore")
  public String getClusterStore() {
    return clusterStore;
  }

  public void setClusterStore(String clusterStore) {
    this.clusterStore = clusterStore;
  }

  public SystemInfo clusterStore(String clusterStore) {
    this.clusterStore = clusterStore;
    return this;
  }

 /**
   * The network endpoint that the Engine advertises for the purpose of node discovery. ClusterAdvertise is a &#x60;host:port&#x60; combination on which the daemon is reachable by other hosts.  &lt;p&gt;&lt;br /&gt;&lt;/p&gt;  &gt; **Note**: This field is only propagated when using standalone Swarm &gt; mode, and overlay networking using an external k/v store. Overlay &gt; networks with Swarm mode enabled use the built-in raft store, and &gt; this field will be empty. 
   * @return clusterAdvertise
  **/
  @JsonProperty("ClusterAdvertise")
  public String getClusterAdvertise() {
    return clusterAdvertise;
  }

  public void setClusterAdvertise(String clusterAdvertise) {
    this.clusterAdvertise = clusterAdvertise;
  }

  public SystemInfo clusterAdvertise(String clusterAdvertise) {
    this.clusterAdvertise = clusterAdvertise;
    return this;
  }

 /**
   * List of [OCI compliant](https://github.com/opencontainers/runtime-spec) runtimes configured on the daemon. Keys hold the \&quot;name\&quot; used to reference the runtime.  The Docker daemon relies on an OCI compliant runtime (invoked via the &#x60;containerd&#x60; daemon) as its interface to the Linux kernel namespaces, cgroups, and SELinux.  The default runtime is &#x60;runc&#x60;, and automatically configured. Additional runtimes can be configured by the user and will be listed here. 
   * @return runtimes
  **/
  @JsonProperty("Runtimes")
  public Map<String, Runtime> getRuntimes() {
    return runtimes;
  }

  public void setRuntimes(Map<String, Runtime> runtimes) {
    this.runtimes = runtimes;
  }

  public SystemInfo runtimes(Map<String, Runtime> runtimes) {
    this.runtimes = runtimes;
    return this;
  }

  public SystemInfo putRuntimesItem(String key, Runtime runtimesItem) {
    this.runtimes.put(key, runtimesItem);
    return this;
  }

 /**
   * Name of the default OCI runtime that is used when starting containers.  The default can be overridden per-container at create time. 
   * @return defaultRuntime
  **/
  @JsonProperty("DefaultRuntime")
  public String getDefaultRuntime() {
    return defaultRuntime;
  }

  public void setDefaultRuntime(String defaultRuntime) {
    this.defaultRuntime = defaultRuntime;
  }

  public SystemInfo defaultRuntime(String defaultRuntime) {
    this.defaultRuntime = defaultRuntime;
    return this;
  }

 /**
   * Get swarm
   * @return swarm
  **/
  @JsonProperty("Swarm")
  public SwarmInfo getSwarm() {
    return swarm;
  }

  public void setSwarm(SwarmInfo swarm) {
    this.swarm = swarm;
  }

  public SystemInfo swarm(SwarmInfo swarm) {
    this.swarm = swarm;
    return this;
  }

 /**
   * Indicates if live restore is enabled.  If enabled, containers are kept running when the daemon is shutdown or upon daemon start if running containers are detected. 
   * @return liveRestoreEnabled
  **/
  @JsonProperty("LiveRestoreEnabled")
  public Boolean isLiveRestoreEnabled() {
    return liveRestoreEnabled;
  }

  public void setLiveRestoreEnabled(Boolean liveRestoreEnabled) {
    this.liveRestoreEnabled = liveRestoreEnabled;
  }

  public SystemInfo liveRestoreEnabled(Boolean liveRestoreEnabled) {
    this.liveRestoreEnabled = liveRestoreEnabled;
    return this;
  }

 /**
   * Represents the isolation technology to use as a default for containers. The supported values are platform-specific.  If no isolation value is specified on daemon start, on Windows client, the default is &#x60;hyperv&#x60;, and on Windows server, the default is &#x60;process&#x60;.  This option is currently not used on other platforms. 
   * @return isolation
  **/
  @JsonProperty("Isolation")
  public String getIsolation() {
    if (isolation == null) {
      return null;
    }
    return isolation.value();
  }

  public void setIsolation(IsolationEnum isolation) {
    this.isolation = isolation;
  }

  public SystemInfo isolation(IsolationEnum isolation) {
    this.isolation = isolation;
    return this;
  }

 /**
   * Name and, optional, path of the &#x60;docker-init&#x60; binary.  If the path is omitted, the daemon searches the host&#39;s &#x60;$PATH&#x60; for the binary and uses the first result. 
   * @return initBinary
  **/
  @JsonProperty("InitBinary")
  public String getInitBinary() {
    return initBinary;
  }

  public void setInitBinary(String initBinary) {
    this.initBinary = initBinary;
  }

  public SystemInfo initBinary(String initBinary) {
    this.initBinary = initBinary;
    return this;
  }

 /**
   * Get containerdCommit
   * @return containerdCommit
  **/
  @JsonProperty("ContainerdCommit")
  public Commit getContainerdCommit() {
    return containerdCommit;
  }

  public void setContainerdCommit(Commit containerdCommit) {
    this.containerdCommit = containerdCommit;
  }

  public SystemInfo containerdCommit(Commit containerdCommit) {
    this.containerdCommit = containerdCommit;
    return this;
  }

 /**
   * Get runcCommit
   * @return runcCommit
  **/
  @JsonProperty("RuncCommit")
  public Commit getRuncCommit() {
    return runcCommit;
  }

  public void setRuncCommit(Commit runcCommit) {
    this.runcCommit = runcCommit;
  }

  public SystemInfo runcCommit(Commit runcCommit) {
    this.runcCommit = runcCommit;
    return this;
  }

 /**
   * Get initCommit
   * @return initCommit
  **/
  @JsonProperty("InitCommit")
  public Commit getInitCommit() {
    return initCommit;
  }

  public void setInitCommit(Commit initCommit) {
    this.initCommit = initCommit;
  }

  public SystemInfo initCommit(Commit initCommit) {
    this.initCommit = initCommit;
    return this;
  }

 /**
   * List of security features that are enabled on the daemon, such as apparmor, seccomp, SELinux, and user-namespaces (userns).  Additional configuration options for each security feature may be present, and are included as a comma-separated list of key/value pairs. 
   * @return securityOptions
  **/
  @JsonProperty("SecurityOptions")
  public List<String> getSecurityOptions() {
    return securityOptions;
  }

  public void setSecurityOptions(List<String> securityOptions) {
    this.securityOptions = securityOptions;
  }

  public SystemInfo securityOptions(List<String> securityOptions) {
    this.securityOptions = securityOptions;
    return this;
  }

  public SystemInfo addSecurityOptionsItem(String securityOptionsItem) {
    this.securityOptions.add(securityOptionsItem);
    return this;
  }

 /**
   * Reports a summary of the product license on the daemon.  If a commercial license has been applied to the daemon, information such as number of nodes, and expiration are included. 
   * @return productLicense
  **/
  @JsonProperty("ProductLicense")
  public String getProductLicense() {
    return productLicense;
  }

  public void setProductLicense(String productLicense) {
    this.productLicense = productLicense;
  }

  public SystemInfo productLicense(String productLicense) {
    this.productLicense = productLicense;
    return this;
  }

 /**
   * List of warnings / informational messages about missing features, or issues related to the daemon configuration.  These messages can be printed by the client as information to the user. 
   * @return warnings
  **/
  @JsonProperty("Warnings")
  public List<String> getWarnings() {
    return warnings;
  }

  public void setWarnings(List<String> warnings) {
    this.warnings = warnings;
  }

  public SystemInfo warnings(List<String> warnings) {
    this.warnings = warnings;
    return this;
  }

  public SystemInfo addWarningsItem(String warningsItem) {
    this.warnings.add(warningsItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SystemInfo {\n");
    
    sb.append("    ID: ").append(toIndentedString(ID)).append("\n");
    sb.append("    containers: ").append(toIndentedString(containers)).append("\n");
    sb.append("    containersRunning: ").append(toIndentedString(containersRunning)).append("\n");
    sb.append("    containersPaused: ").append(toIndentedString(containersPaused)).append("\n");
    sb.append("    containersStopped: ").append(toIndentedString(containersStopped)).append("\n");
    sb.append("    images: ").append(toIndentedString(images)).append("\n");
    sb.append("    driver: ").append(toIndentedString(driver)).append("\n");
    sb.append("    driverStatus: ").append(toIndentedString(driverStatus)).append("\n");
    sb.append("    dockerRootDir: ").append(toIndentedString(dockerRootDir)).append("\n");
    sb.append("    systemStatus: ").append(toIndentedString(systemStatus)).append("\n");
    sb.append("    plugins: ").append(toIndentedString(plugins)).append("\n");
    sb.append("    memoryLimit: ").append(toIndentedString(memoryLimit)).append("\n");
    sb.append("    swapLimit: ").append(toIndentedString(swapLimit)).append("\n");
    sb.append("    kernelMemory: ").append(toIndentedString(kernelMemory)).append("\n");
    sb.append("    cpuCfsPeriod: ").append(toIndentedString(cpuCfsPeriod)).append("\n");
    sb.append("    cpuCfsQuota: ").append(toIndentedString(cpuCfsQuota)).append("\n");
    sb.append("    cpUShares: ").append(toIndentedString(cpUShares)).append("\n");
    sb.append("    cpUSet: ").append(toIndentedString(cpUSet)).append("\n");
    sb.append("    oomKillDisable: ").append(toIndentedString(oomKillDisable)).append("\n");
    sb.append("    ipv4Forwarding: ").append(toIndentedString(ipv4Forwarding)).append("\n");
    sb.append("    bridgeNfIptables: ").append(toIndentedString(bridgeNfIptables)).append("\n");
    sb.append("    bridgeNfIp6tables: ").append(toIndentedString(bridgeNfIp6tables)).append("\n");
    sb.append("    debug: ").append(toIndentedString(debug)).append("\n");
    sb.append("    nfd: ").append(toIndentedString(nfd)).append("\n");
    sb.append("    ngoroutines: ").append(toIndentedString(ngoroutines)).append("\n");
    sb.append("    systemTime: ").append(toIndentedString(systemTime)).append("\n");
    sb.append("    loggingDriver: ").append(toIndentedString(loggingDriver)).append("\n");
    sb.append("    cgroupDriver: ").append(toIndentedString(cgroupDriver)).append("\n");
    sb.append("    neventsListener: ").append(toIndentedString(neventsListener)).append("\n");
    sb.append("    kernelVersion: ").append(toIndentedString(kernelVersion)).append("\n");
    sb.append("    operatingSystem: ").append(toIndentedString(operatingSystem)).append("\n");
    sb.append("    osType: ").append(toIndentedString(osType)).append("\n");
    sb.append("    architecture: ").append(toIndentedString(architecture)).append("\n");
    sb.append("    NCPU: ").append(toIndentedString(NCPU)).append("\n");
    sb.append("    memTotal: ").append(toIndentedString(memTotal)).append("\n");
    sb.append("    indexServerAddress: ").append(toIndentedString(indexServerAddress)).append("\n");
    sb.append("    registryConfig: ").append(toIndentedString(registryConfig)).append("\n");
    sb.append("    genericResources: ").append(toIndentedString(genericResources)).append("\n");
    sb.append("    httpProxy: ").append(toIndentedString(httpProxy)).append("\n");
    sb.append("    httpsProxy: ").append(toIndentedString(httpsProxy)).append("\n");
    sb.append("    noProxy: ").append(toIndentedString(noProxy)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    labels: ").append(toIndentedString(labels)).append("\n");
    sb.append("    experimentalBuild: ").append(toIndentedString(experimentalBuild)).append("\n");
    sb.append("    serverVersion: ").append(toIndentedString(serverVersion)).append("\n");
    sb.append("    clusterStore: ").append(toIndentedString(clusterStore)).append("\n");
    sb.append("    clusterAdvertise: ").append(toIndentedString(clusterAdvertise)).append("\n");
    sb.append("    runtimes: ").append(toIndentedString(runtimes)).append("\n");
    sb.append("    defaultRuntime: ").append(toIndentedString(defaultRuntime)).append("\n");
    sb.append("    swarm: ").append(toIndentedString(swarm)).append("\n");
    sb.append("    liveRestoreEnabled: ").append(toIndentedString(liveRestoreEnabled)).append("\n");
    sb.append("    isolation: ").append(toIndentedString(isolation)).append("\n");
    sb.append("    initBinary: ").append(toIndentedString(initBinary)).append("\n");
    sb.append("    containerdCommit: ").append(toIndentedString(containerdCommit)).append("\n");
    sb.append("    runcCommit: ").append(toIndentedString(runcCommit)).append("\n");
    sb.append("    initCommit: ").append(toIndentedString(initCommit)).append("\n");
    sb.append("    securityOptions: ").append(toIndentedString(securityOptions)).append("\n");
    sb.append("    productLicense: ").append(toIndentedString(productLicense)).append("\n");
    sb.append("    warnings: ").append(toIndentedString(warnings)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

