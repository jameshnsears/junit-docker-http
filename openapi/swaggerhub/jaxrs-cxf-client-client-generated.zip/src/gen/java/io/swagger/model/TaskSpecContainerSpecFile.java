package io.swagger.model;

import io.swagger.annotations.ApiModel;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
  * File represents a specific target that is backed by a file.
 **/
@ApiModel(description="File represents a specific target that is backed by a file.")
public class TaskSpecContainerSpecFile  {
  
  @ApiModelProperty(value = "Name represents the final filename in the filesystem.")
 /**
   * Name represents the final filename in the filesystem.  
  **/
  private String name = null;

  @ApiModelProperty(value = "UID represents the file UID.")
 /**
   * UID represents the file UID.  
  **/
  private String UID = null;

  @ApiModelProperty(value = "GID represents the file GID.")
 /**
   * GID represents the file GID.  
  **/
  private String GID = null;

  @ApiModelProperty(value = "Mode represents the FileMode of the file.")
 /**
   * Mode represents the FileMode of the file.  
  **/
  private Integer mode = null;
 /**
   * Name represents the final filename in the filesystem.
   * @return name
  **/
  @JsonProperty("Name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public TaskSpecContainerSpecFile name(String name) {
    this.name = name;
    return this;
  }

 /**
   * UID represents the file UID.
   * @return UID
  **/
  @JsonProperty("UID")
  public String getUID() {
    return UID;
  }

  public void setUID(String UID) {
    this.UID = UID;
  }

  public TaskSpecContainerSpecFile UID(String UID) {
    this.UID = UID;
    return this;
  }

 /**
   * GID represents the file GID.
   * @return GID
  **/
  @JsonProperty("GID")
  public String getGID() {
    return GID;
  }

  public void setGID(String GID) {
    this.GID = GID;
  }

  public TaskSpecContainerSpecFile GID(String GID) {
    this.GID = GID;
    return this;
  }

 /**
   * Mode represents the FileMode of the file.
   * @return mode
  **/
  @JsonProperty("Mode")
  public Integer getMode() {
    return mode;
  }

  public void setMode(Integer mode) {
    this.mode = mode;
  }

  public TaskSpecContainerSpecFile mode(Integer mode) {
    this.mode = mode;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TaskSpecContainerSpecFile {\n");
    
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    UID: ").append(toIndentedString(UID)).append("\n");
    sb.append("    GID: ").append(toIndentedString(GID)).append("\n");
    sb.append("    mode: ").append(toIndentedString(mode)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

