package io.swagger.model;

import io.swagger.model.TaskState;
import io.swagger.model.TaskStatusContainerStatus;

import io.swagger.annotations.ApiModelProperty;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;

public class TaskStatus  {
  
  @ApiModelProperty(value = "")
  private String timestamp = null;

  @ApiModelProperty(value = "")
  private TaskState state = null;

  @ApiModelProperty(value = "")
  private String message = null;

  @ApiModelProperty(value = "")
  private String err = null;

  @ApiModelProperty(value = "")
  private TaskStatusContainerStatus containerStatus = null;
 /**
   * Get timestamp
   * @return timestamp
  **/
  @JsonProperty("Timestamp")
  public String getTimestamp() {
    return timestamp;
  }

  public void setTimestamp(String timestamp) {
    this.timestamp = timestamp;
  }

  public TaskStatus timestamp(String timestamp) {
    this.timestamp = timestamp;
    return this;
  }

 /**
   * Get state
   * @return state
  **/
  @JsonProperty("State")
  public TaskState getState() {
    return state;
  }

  public void setState(TaskState state) {
    this.state = state;
  }

  public TaskStatus state(TaskState state) {
    this.state = state;
    return this;
  }

 /**
   * Get message
   * @return message
  **/
  @JsonProperty("Message")
  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public TaskStatus message(String message) {
    this.message = message;
    return this;
  }

 /**
   * Get err
   * @return err
  **/
  @JsonProperty("Err")
  public String getErr() {
    return err;
  }

  public void setErr(String err) {
    this.err = err;
  }

  public TaskStatus err(String err) {
    this.err = err;
    return this;
  }

 /**
   * Get containerStatus
   * @return containerStatus
  **/
  @JsonProperty("ContainerStatus")
  public TaskStatusContainerStatus getContainerStatus() {
    return containerStatus;
  }

  public void setContainerStatus(TaskStatusContainerStatus containerStatus) {
    this.containerStatus = containerStatus;
  }

  public TaskStatus containerStatus(TaskStatusContainerStatus containerStatus) {
    this.containerStatus = containerStatus;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TaskStatus {\n");
    
    sb.append("    timestamp: ").append(toIndentedString(timestamp)).append("\n");
    sb.append("    state: ").append(toIndentedString(state)).append("\n");
    sb.append("    message: ").append(toIndentedString(message)).append("\n");
    sb.append("    err: ").append(toIndentedString(err)).append("\n");
    sb.append("    containerStatus: ").append(toIndentedString(containerStatus)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

